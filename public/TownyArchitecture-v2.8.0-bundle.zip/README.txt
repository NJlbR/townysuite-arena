TownyArchitecture v2.8.0
========================
Release: Dynamic Obstacle Tool Holograms & Uniform HP Calculation

Installation:
1. Put TownyArchitecture-2.8.0.jar into your server's plugins/ directory.
2. Make sure Towny (0.98+) is installed.
3. Restart or reload your server.
4. Run /builds to open the architectural blueprints catalog.

Fixes in v2.8.0:
- Each block destroyed by a player, siege explosion, or environment subtracts an equal proportion of building HP.
- Fixed premature 100% completion bug when restoring partial blocks.
- Fixed disappearance of missing block holograms on other layers during partial repairs.
- Full layer synchronization and accurate HUD wireframes.
