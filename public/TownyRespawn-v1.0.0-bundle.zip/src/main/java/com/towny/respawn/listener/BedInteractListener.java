package com.towny.respawn.listener;

import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.model.PlayerBed;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.List;

public class BedInteractListener implements Listener {

    private final TownyRespawnPlugin plugin;

    public BedInteractListener(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBedEnter(PlayerBedEnterEvent event) {
        if (!plugin.getConfig().getBoolean("beds.enabled", true)) return;
        Player player = event.getPlayer();
        handleBedRegistration(player, event.getBed().getLocation());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("beds.enabled", true)) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        Material mat = block.getType();
        if (mat.name().endsWith("_BED")) {
            Player player = event.getPlayer();
            // If player shifts or interacts, register bed
            if (plugin.getConfig().getBoolean("beds.auto-register-on-interact", true)) {
                handleBedRegistration(player, block.getLocation());
            }
        }
    }

    private void handleBedRegistration(Player player, Location loc) {
        List<PlayerBed> beds = plugin.getBedManager().getBeds(player);

        // Check if already registered
        for (PlayerBed b : beds) {
            if (b.isSameBlock(loc)) {
                return;
            }
        }

        int max = plugin.getBedManager().getMaxBeds(player);
        if (beds.size() >= max) {
            String prefix = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.prefix", "&b&l[TownyRespawn]&r "));
            String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.bed-limit-reached", "&cУ вас достигнут лимит кроватей ({max})!"))
                    .replace("{max}", String.valueOf(max));
            player.sendMessage(prefix + msg);
            return;
        }

        boolean success = plugin.getBedManager().registerBed(player, loc);
        if (success) {
            int current = plugin.getBedManager().getBeds(player).size();
            String prefix = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.prefix", "&b&l[TownyRespawn]&r "));
            String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.bed-registered", "&a✔ Кровать «{name}» успешно добавлена! ({current}/{max})"))
                    .replace("{name}", "Кровать #" + current)
                    .replace("{current}", String.valueOf(current))
                    .replace("{max}", String.valueOf(max));
            player.sendMessage(prefix + msg);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!block.getType().name().endsWith("_BED")) return;

        // Cleanup destroyed bed for players
        Player player = event.getPlayer();
        plugin.getBedManager().cleanupDestroyedBeds(player);
    }
}
