package com.towny.respawn.listener;

import com.towny.respawn.TownyRespawnPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class DeathRespawnListener implements Listener {

    private final TownyRespawnPlugin plugin;

    public DeathRespawnListener(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        plugin.getRespawnManager().markPendingRespawn(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();

        // Check if player has death respawn pending
        plugin.getRespawnManager().markPendingRespawn(player.getUniqueId());

        // Temporarily put player in safe holding state
        long delay = plugin.getConfig().getLong("respawn.gui-open-delay-ticks", 2L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && plugin.getRespawnManager().isPendingRespawn(player.getUniqueId())) {
                // Freeze and protect player while viewing the map
                player.setInvulnerable(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 60, 1, false, false, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 20 * 60, 10, false, false, false));

                // Open the interactive death map GUI
                plugin.getGuiManager().openDeathRespawnGui(player);
            }
        }, delay);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getRespawnManager().clearPendingRespawn(event.getPlayer().getUniqueId());
    }
}
