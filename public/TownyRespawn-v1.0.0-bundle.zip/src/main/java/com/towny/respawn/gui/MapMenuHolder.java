package com.towny.respawn.gui;

import com.towny.respawn.model.GraphicsLevel;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class MapMenuHolder implements InventoryHolder {

    public enum Mode {
        MAP_VIEW,
        DEATH_RESPAWN
    }

    private final Mode mode;
    private final Player player;
    private int centerChunkX;
    private int centerChunkZ;
    private GraphicsLevel graphicsLevel;
    private Inventory inventory;

    public MapMenuHolder(Mode mode, Player player, int centerChunkX, int centerChunkZ, GraphicsLevel graphicsLevel) {
        this.mode = mode;
        this.player = player;
        this.centerChunkX = centerChunkX;
        this.centerChunkZ = centerChunkZ;
        this.graphicsLevel = graphicsLevel;
    }

    public Mode getMode() {
        return mode;
    }

    public Player getPlayer() {
        return player;
    }

    public int getCenterChunkX() {
        return centerChunkX;
    }

    public void setCenterChunkX(int centerChunkX) {
        this.centerChunkX = centerChunkX;
    }

    public int getCenterChunkZ() {
        return centerChunkZ;
    }

    public void setCenterChunkZ(int centerChunkZ) {
        this.centerChunkZ = centerChunkZ;
    }

    public GraphicsLevel getGraphicsLevel() {
        return graphicsLevel;
    }

    public void setGraphicsLevel(GraphicsLevel graphicsLevel) {
        this.graphicsLevel = graphicsLevel;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
