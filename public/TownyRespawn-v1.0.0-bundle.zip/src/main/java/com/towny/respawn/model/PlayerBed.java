package com.towny.respawn.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.serialization.ConfigurationSerializable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerBed implements ConfigurationSerializable {

    private final UUID id;
    private final UUID ownerUuid;
    private String name;
    private final String worldName;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;
    private final long createdAt;

    public PlayerBed(UUID ownerUuid, String name, Location loc) {
        this.id = UUID.randomUUID();
        this.ownerUuid = ownerUuid;
        this.name = name;
        this.worldName = loc.getWorld() != null ? loc.getWorld().getName() : "world";
        this.x = loc.getX();
        this.y = loc.getY();
        this.z = loc.getZ();
        this.yaw = loc.getYaw();
        this.pitch = loc.getPitch();
        this.createdAt = System.currentTimeMillis();
    }

    public PlayerBed(UUID id, UUID ownerUuid, String name, String worldName, double x, double y, double z, float yaw, float pitch, long createdAt) {
        this.id = id;
        this.ownerUuid = ownerUuid;
        this.name = name;
        this.worldName = worldName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.createdAt = createdAt;
    }

    public UUID getId() {
        return id;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorldName() {
        return worldName;
    }

    public Location getLocation() {
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, x, y, z, yaw, pitch);
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public boolean isSameBlock(Location other) {
        if (other == null || other.getWorld() == null) return false;
        if (!other.getWorld().getName().equalsIgnoreCase(worldName)) return false;
        return (int) Math.floor(x) == other.getBlockX() &&
               (int) Math.floor(y) == other.getBlockY() &&
               (int) Math.floor(z) == other.getBlockZ();
    }

    @Override
    public Map<String, Object> serialize() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id.toString());
        map.put("ownerUuid", ownerUuid.toString());
        map.put("name", name);
        map.put("worldName", worldName);
        map.put("x", x);
        map.put("y", y);
        map.put("z", z);
        map.put("yaw", (double) yaw);
        map.put("pitch", (double) pitch);
        map.put("createdAt", createdAt);
        return map;
    }

    public static PlayerBed deserialize(Map<String, Object> map) {
        UUID id = UUID.fromString((String) map.get("id"));
        UUID ownerUuid = UUID.fromString((String) map.get("ownerUuid"));
        String name = (String) map.get("name");
        String worldName = (String) map.get("worldName");
        double x = ((Number) map.get("x")).doubleValue();
        double y = ((Number) map.get("y")).doubleValue();
        double z = ((Number) map.get("z")).doubleValue();
        float yaw = ((Number) map.get("yaw")).floatValue();
        float pitch = ((Number) map.get("pitch")).floatValue();
        long createdAt = ((Number) map.getOrDefault("createdAt", System.currentTimeMillis())).longValue();
        return new PlayerBed(id, ownerUuid, name, worldName, x, y, z, yaw, pitch, createdAt);
    }
}
