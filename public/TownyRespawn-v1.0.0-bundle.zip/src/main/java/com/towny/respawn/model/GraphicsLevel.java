package com.towny.respawn.model;

import org.bukkit.ChatColor;

public enum GraphicsLevel {
    LOW("&72D Сетка (Быстрая)", "Шерстяные таймеры и границы"),
    MEDIUM("&aСредняя (Контуры)", "Терракотовые зоны городов и биомы"),
    HIGH("&eВысокая (Детальная)", "Бетонная цветовая палитра и рельеф"),
    HD("&bУльтра HD (BlueMap)", "Изометрический стиль, высоты и световые эффекты");

    private final String displayName;
    private final String description;

    GraphicsLevel(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return ChatColor.translateAlternateColorCodes('&', displayName);
    }

    public String getDescription() {
        return description;
    }

    public GraphicsLevel next() {
        GraphicsLevel[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }

    public static GraphicsLevel fromString(String name) {
        if (name == null) return HIGH;
        try {
            return GraphicsLevel.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return HIGH;
        }
    }
}
