package com.towny.respawn.manager;

import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.gui.MapMenuHolder;
import com.towny.respawn.model.GraphicsLevel;
import com.towny.respawn.model.RespawnPoint;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class GuiManager {

    private final TownyRespawnPlugin plugin;

    public GuiManager(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    public void openMapGui(Player player) {
        openGui(player, MapMenuHolder.Mode.MAP_VIEW);
    }

    public void openDeathRespawnGui(Player player) {
        openGui(player, MapMenuHolder.Mode.DEATH_RESPAWN);
    }

    public void openGui(Player player, MapMenuHolder.Mode mode) {
        if (player == null) return;

        GraphicsLevel level = plugin.getMapManager().getGraphicsLevel(player);
        int centerChunkX = player.getLocation().getBlockX() >> 4;
        int centerChunkZ = player.getLocation().getBlockZ() >> 4;

        MapMenuHolder holder = new MapMenuHolder(mode, player, centerChunkX, centerChunkZ, level);
        String titleRaw = (mode == MapMenuHolder.Mode.DEATH_RESPAWN)
                ? plugin.getConfig().getString("messages.menu-title-death", "&4&l☠ ВЫБОР ТОЧКИ ВОЗРОЖДЕНИЯ")
                : plugin.getConfig().getString("messages.menu-title-map", "&8Интерактивная карта &b/map");

        Inventory inv = Bukkit.createInventory(holder, 54, ChatColor.translateAlternateColorCodes('&', titleRaw));
        holder.setInventory(inv);

        renderGui(holder);
        player.openInventory(inv);
    }

    public void renderGui(MapMenuHolder holder) {
        Inventory inv = holder.getInventory();
        inv.clear();

        Player player = holder.getPlayer();
        GraphicsLevel level = holder.getGraphicsLevel();
        int cx = holder.getCenterChunkX();
        int cz = holder.getCenterChunkZ();

        // Fill background border
        ItemStack filler = createItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) {
            inv.setItem(i, filler);
        }

        if (holder.getMode() == MapMenuHolder.Mode.DEATH_RESPAWN) {
            renderDeathRespawnMode(holder, inv, player, level, cx, cz);
        } else {
            renderMapOverviewMode(holder, inv, player, level, cx, cz);
        }
    }

    private void renderDeathRespawnMode(MapMenuHolder holder, Inventory inv, Player player, GraphicsLevel level, int cx, int cz) {
        // Top 2 rows: 7x2 chunk map preview centered on death/player
        // Slots 10..16, 19..25
        int[] mapSlots = {
                10, 11, 12, 13, 14, 15, 16,
                19, 20, 21, 22, 23, 24, 25
        };

        int idx = 0;
        for (int dz = -1; dz <= 0; dz++) {
            for (int dx = -3; dx <= 3; dx++) {
                if (idx < mapSlots.length) {
                    ItemStack tile = plugin.getMapManager().createMapTile(player, cx, cz, cx + dx, cz + dz, level);
                    inv.setItem(mapSlots[idx++], tile);
                }
            }
        }

        // Header label at slot 4
        inv.setItem(4, createItem(Material.SKELETON_SKULL, "§4§lВЫ ПОГИБЛИ!",
                "§7Выберите безопасную точку для возрождения ниже.",
                "§7На карте сверху отображена территория вокруг вас.",
                "§eГорода и осады отмечены цветом."));

        // Row 3 (slots 28..34): Player Available Beds & Town/Nation Spawns
        List<RespawnPoint> points = plugin.getRespawnManager().getAvailableRespawnPoints(player);
        int bedSlot = 28;
        for (RespawnPoint rp : points) {
            if (rp.getType() == RespawnPoint.Type.BED ||
                rp.getType() == RespawnPoint.Type.TOWN_SPAWN ||
                rp.getType() == RespawnPoint.Type.NATION_SPAWN) {
                if (bedSlot <= 34) {
                    inv.setItem(bedSlot++, createRespawnItem(rp));
                }
            }
        }

        // Bottom row (slots 45..53): Primary Action Buttons
        // Slot 46: Vanilla Respawn
        RespawnPoint vanillaPoint = points.stream()
                .filter(p -> p.getType() == RespawnPoint.Type.VANILLA_RANDOM)
                .findFirst().orElse(null);
        if (vanillaPoint != null) {
            inv.setItem(46, createRespawnItem(vanillaPoint));
        }

        // Slot 49: Graphics setting toggle
        inv.setItem(49, createGraphicsToggleItem(level));

        // Slot 52: Server Spawn
        RespawnPoint serverPoint = points.stream()
                .filter(p -> p.getType() == RespawnPoint.Type.SERVER_SPAWN)
                .findFirst().orElse(null);
        if (serverPoint != null) {
            inv.setItem(52, createRespawnItem(serverPoint));
        }
    }

    private void renderMapOverviewMode(MapMenuHolder holder, Inventory inv, Player player, GraphicsLevel level, int cx, int cz) {
        // 5x5 chunk grid in center:
        // Rows:
        // Slot 11..15
        // Slot 20..24
        // Slot 29..33
        // Slot 38..42
        int[] rows = {11, 20, 29, 38};
        for (int r = 0; r < 4; r++) {
            int dz = r - 1;
            int startSlot = rows[r];
            for (int dx = -2; dx <= 2; dx++) {
                int slot = startSlot + (dx + 2);
                ItemStack tile = plugin.getMapManager().createMapTile(player, cx, cz, cx + dx, cz + dz, level);
                inv.setItem(slot, tile);
            }
        }

        // Panning controls on edges
        inv.setItem(2, createItem(Material.ARROW, "§a▲ Сместить на Север (Z-)", "§7Нажмите для перемещения карты на 1 чанк севернее"));
        inv.setItem(47, createItem(Material.ARROW, "§a▼ Сместить на Юг (Z+)", "§7Нажмите для перемещения карты на 1 чанк южнее"));
        inv.setItem(18, createItem(Material.ARROW, "§a◀ Сместить на Запад (X-)", "§7Нажмите для перемещения карты на 1 чанк западнее"));
        inv.setItem(26, createItem(Material.ARROW, "§a▶ Сместить на Восток (X+)", "§7Нажмите для перемещения карты на 1 чанк восточнее"));

        // Slot 0: Center on player
        inv.setItem(0, createItem(Material.COMPASS, "§eЦентрировать на мне", "§7Вернуть центр карты к вашей текущей позиции"));

        // Slot 49: Graphics level toggle
        inv.setItem(49, createGraphicsToggleItem(level));

        // Slot 8: Respawn points shortcut
        inv.setItem(8, createItem(Material.RED_BED, "§bМои кровати и спавны", "§7Просмотр привязанных точек возрождения"));
    }

    public ItemStack createGraphicsToggleItem(GraphicsLevel level) {
        Material mat;
        switch (level) {
            case LOW: mat = Material.WHITE_WOOL; break;
            case MEDIUM: mat = Material.TERRACOTTA; break;
            case HIGH: mat = Material.CYAN_CONCRETE; break;
            case HD: default: mat = Material.ENDER_EYE; break;
        }

        return createItem(mat, "§e⚙ Графика карты: " + level.getDisplayName(),
                "§7Текущий стиль: §f" + level.getDescription(),
                "§8Доступно: Низкая -> Средняя -> Высокая -> HD",
                "§e▸ Нажмите ЛКМ для переключения уровня!");
    }

    private ItemStack createRespawnItem(RespawnPoint rp) {
        ItemStack item = new ItemStack(rp.getIcon());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(rp.getTitle());
            List<String> lore = new ArrayList<>(rp.getLore());
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createItem(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (loreLines != null && loreLines.length > 0) {
                List<String> lore = new ArrayList<>();
                for (String line : loreLines) {
                    lore.add(line);
                }
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
