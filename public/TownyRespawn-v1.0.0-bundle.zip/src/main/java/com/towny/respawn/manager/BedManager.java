package com.towny.respawn.manager;

import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.model.PlayerBed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BedManager {

    private final TownyRespawnPlugin plugin;
    private final File dataFile;
    private final Map<UUID, List<PlayerBed>> playerBeds = new ConcurrentHashMap<>();

    public BedManager(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "player_beds.yml");
    }

    public void load() {
        playerBeds.clear();
        if (!dataFile.exists()) return;

        FileConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root = config.getConfigurationSection("players");
        if (root == null) return;

        for (String uuidStr : root.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                List<?> rawList = root.getList(uuidStr);
                if (rawList != null) {
                    List<PlayerBed> beds = new ArrayList<>();
                    for (Object obj : rawList) {
                        if (obj instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> map = (Map<String, Object>) obj;
                            beds.add(PlayerBed.deserialize(map));
                        } else if (obj instanceof PlayerBed) {
                            beds.add((PlayerBed) obj);
                        }
                    }
                    playerBeds.put(uuid, beds);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Could not load beds for UUID " + uuidStr + ": " + e.getMessage());
            }
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, List<PlayerBed>> entry : playerBeds.entrySet()) {
            List<Map<String, Object>> serialized = new ArrayList<>();
            for (PlayerBed bed : entry.getValue()) {
                serialized.add(bed.serialize());
            }
            config.set("players." + entry.getKey().toString(), serialized);
        }

        try {
            config.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save player_beds.yml: " + e.getMessage());
        }
    }

    public List<PlayerBed> getBeds(Player player) {
        if (player == null) return Collections.emptyList();
        return getBeds(player.getUniqueId());
    }

    public List<PlayerBed> getBeds(UUID uuid) {
        return playerBeds.computeIfAbsent(uuid, k -> new ArrayList<>());
    }

    public int getMaxBeds(Player player) {
        if (player == null) return plugin.getConfig().getInt("beds.max-beds-default", 3);
        if (player.hasPermission("townyrespawn.beds.unlimited") || player.isOp()) {
            return 20;
        }

        int max = plugin.getConfig().getInt("beds.max-beds-default", 3);
        if (!plugin.getConfig().getBoolean("beds.use-permission-limits", true)) {
            return max;
        }

        for (PermissionAttachmentInfo pai : player.getEffectivePermissions()) {
            String perm = pai.getPermission().toLowerCase();
            if (perm.startsWith("townyrespawn.beds.") && pai.getValue()) {
                String suffix = perm.substring("townyrespawn.beds.".length());
                try {
                    int val = Integer.parseInt(suffix);
                    if (val > max) {
                        max = val;
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        return max;
    }

    public boolean registerBed(Player player, Location loc) {
        if (player == null || loc == null) return false;

        List<PlayerBed> beds = getBeds(player);

        // Check if player already registered this exact bed block
        for (PlayerBed existing : beds) {
            if (existing.isSameBlock(loc)) {
                return true;
            }
        }

        int maxAllowed = getMaxBeds(player);
        if (beds.size() >= maxAllowed) {
            return false;
        }

        int nextIndex = beds.size() + 1;
        String format = plugin.getConfig().getString("beds.default-bed-name-format", "Кровать #{number}");
        String name = format.replace("{number}", String.valueOf(nextIndex));

        PlayerBed newBed = new PlayerBed(player.getUniqueId(), name, loc);
        beds.add(newBed);
        save();
        return true;
    }

    public boolean removeBed(Player player, PlayerBed bed) {
        if (player == null || bed == null) return false;
        List<PlayerBed> beds = getBeds(player);
        boolean removed = beds.removeIf(b -> b.getId().equals(bed.getId()));
        if (removed) {
            save();
        }
        return removed;
    }

    public boolean isBedPhysicallyValid(PlayerBed bed) {
        if (bed == null) return false;
        if (!plugin.getConfig().getBoolean("beds.verify-bed-block-exists", true)) {
            return true;
        }

        Location loc = bed.getLocation();
        if (loc == null || loc.getWorld() == null) return false;

        Block block = loc.getBlock();
        Material mat = block.getType();
        return mat.name().endsWith("_BED");
    }

    public void cleanupDestroyedBeds(Player player) {
        if (player == null) return;
        List<PlayerBed> beds = getBeds(player);
        boolean changed = false;
        Iterator<PlayerBed> it = beds.iterator();
        while (it.hasNext()) {
            PlayerBed bed = it.next();
            if (!isBedPhysicallyValid(bed)) {
                it.remove();
                changed = true;
            }
        }
        if (changed) {
            save();
        }
    }
}
