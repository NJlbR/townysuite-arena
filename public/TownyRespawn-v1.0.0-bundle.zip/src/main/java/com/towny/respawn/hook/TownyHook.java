package com.towny.respawn.hook;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.Collections;

public class TownyHook {

    private final boolean townyPresent;

    public TownyHook() {
        this.townyPresent = Bukkit.getPluginManager().getPlugin("Towny") != null;
    }

    public boolean isTownyAvailable() {
        return townyPresent && TownyAPI.getInstance() != null;
    }

    public Town getPlayerTown(Player player) {
        if (!isTownyAvailable() || player == null) return null;
        try {
            Resident resident = TownyAPI.getInstance().getResident(player);
            return (resident != null && resident.hasTown()) ? resident.getTownOrNull() : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String getPlayerTownName(Player player) {
        Town town = getPlayerTown(player);
        return town != null ? town.getName() : null;
    }

    public Nation getPlayerNation(Player player) {
        if (!isTownyAvailable() || player == null) return null;
        try {
            Resident resident = TownyAPI.getInstance().getResident(player);
            return (resident != null && resident.hasNation()) ? resident.getNationOrNull() : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String getPlayerNationName(Player player) {
        Nation nation = getPlayerNation(player);
        return nation != null ? nation.getName() : null;
    }

    public Location getTownSpawn(Town town) {
        if (town == null) return null;
        try {
            return town.getSpawn();
        } catch (Exception ignored) {
            return null;
        }
    }

    public Location getNationSpawn(Nation nation) {
        if (nation == null) return null;
        try {
            Town capital = nation.getCapital();
            return capital != null ? capital.getSpawn() : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String getTownNameAt(Location loc) {
        if (!isTownyAvailable() || loc == null) return null;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            return (tb != null && tb.hasTown()) ? tb.getTownOrNull().getName() : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public Town getTownAt(Location loc) {
        if (!isTownyAvailable() || loc == null) return null;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            return (tb != null && tb.hasTown()) ? tb.getTownOrNull() : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public Collection<Town> getAllTowns() {
        if (!isTownyAvailable()) return Collections.emptyList();
        try {
            return TownyAPI.getInstance().getTowns();
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }
}
