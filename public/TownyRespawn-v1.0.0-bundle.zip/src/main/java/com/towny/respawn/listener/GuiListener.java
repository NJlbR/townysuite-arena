package com.towny.respawn.listener;

import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.gui.MapMenuHolder;
import com.towny.respawn.model.GraphicsLevel;
import com.towny.respawn.model.RespawnPoint;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;

import java.util.List;

public class GuiListener implements Listener {

    private final TownyRespawnPlugin plugin;

    public GuiListener(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory inv = event.getInventory();
        if (!(inv.getHolder() instanceof MapMenuHolder)) return;

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        MapMenuHolder holder = (MapMenuHolder) inv.getHolder();

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= inv.getSize()) return;

        // Slot 49: Graphics Toggle Button
        if (slot == 49) {
            GraphicsLevel next = plugin.getMapManager().cycleGraphicsLevel(player);
            holder.setGraphicsLevel(next);
            plugin.getGuiManager().renderGui(holder);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);

            String prefix = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.prefix", "&b&l[TownyRespawn]&r "));
            String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.graphics-changed", "&eУровень графики изменен на: {level}"))
                    .replace("{level}", next.getDisplayName());
            player.sendMessage(prefix + msg);
            return;
        }

        // Panning controls in MAP_VIEW mode
        if (holder.getMode() == MapMenuHolder.Mode.MAP_VIEW) {
            if (slot == 2) { // North
                holder.setCenterChunkZ(holder.getCenterChunkZ() - 1);
                plugin.getGuiManager().renderGui(holder);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.4f);
                return;
            } else if (slot == 47) { // South
                holder.setCenterChunkZ(holder.getCenterChunkZ() + 1);
                plugin.getGuiManager().renderGui(holder);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.4f);
                return;
            } else if (slot == 18) { // West
                holder.setCenterChunkX(holder.getCenterChunkX() - 1);
                plugin.getGuiManager().renderGui(holder);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.4f);
                return;
            } else if (slot == 26) { // East
                holder.setCenterChunkX(holder.getCenterChunkX() + 1);
                plugin.getGuiManager().renderGui(holder);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.4f);
                return;
            } else if (slot == 0) { // Recenter
                int px = player.getLocation().getBlockX() >> 4;
                int pz = player.getLocation().getBlockZ() >> 4;
                holder.setCenterChunkX(px);
                holder.setCenterChunkZ(pz);
                plugin.getGuiManager().renderGui(holder);
                player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 0.8f, 1.0f);
                return;
            }
        }

        // Respawn selection clicks (either in DEATH_RESPAWN mode or via /beds)
        List<RespawnPoint> points = plugin.getRespawnManager().getAvailableRespawnPoints(player);

        // Vanilla respawn
        if (slot == 46) {
            RespawnPoint vanilla = points.stream().filter(p -> p.getType() == RespawnPoint.Type.VANILLA_RANDOM).findFirst().orElse(null);
            if (vanilla != null) {
                player.closeInventory();
                plugin.getRespawnManager().executeRespawn(player, vanilla);
                return;
            }
        }

        // Server spawn
        if (slot == 52) {
            RespawnPoint serverSpawn = points.stream().filter(p -> p.getType() == RespawnPoint.Type.SERVER_SPAWN).findFirst().orElse(null);
            if (serverSpawn != null) {
                player.closeInventory();
                plugin.getRespawnManager().executeRespawn(player, serverSpawn);
                return;
            }
        }

        // Custom beds & Town / Nation spawns (slots 28..34)
        if (slot >= 28 && slot <= 34) {
            int bedIndex = slot - 28;
            List<RespawnPoint> validPoints = points.stream()
                    .filter(p -> p.getType() == RespawnPoint.Type.BED ||
                                 p.getType() == RespawnPoint.Type.TOWN_SPAWN ||
                                 p.getType() == RespawnPoint.Type.NATION_SPAWN)
                    .toList();

            if (bedIndex < validPoints.size()) {
                RespawnPoint chosen = validPoints.get(bedIndex);
                if (chosen.isAvailable()) {
                    player.closeInventory();
                    plugin.getRespawnManager().executeRespawn(player, chosen);
                } else {
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
                    player.sendMessage(ChatColor.RED + "[TownyRespawn] Эта точка возрождения недоступна: " + chosen.getUnavailableReason());
                }
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof MapMenuHolder)) return;
        MapMenuHolder holder = (MapMenuHolder) event.getInventory().getHolder();

        if (holder.getMode() == MapMenuHolder.Mode.DEATH_RESPAWN) {
            Player player = (Player) event.getPlayer();
            // If player closed window while death respawn was still pending, re-open or execute default
            if (player.isOnline() && plugin.getRespawnManager().isPendingRespawn(player.getUniqueId())) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline() && plugin.getRespawnManager().isPendingRespawn(player.getUniqueId())) {
                        plugin.getGuiManager().openDeathRespawnGui(player);
                    }
                }, 5L);
            }
        }
    }
}
