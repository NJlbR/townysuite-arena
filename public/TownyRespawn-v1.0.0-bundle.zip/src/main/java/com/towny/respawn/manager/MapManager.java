package com.towny.respawn.manager;

import com.palmergames.bukkit.towny.object.Town;
import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.model.GraphicsLevel;
import com.towny.respawn.model.PlayerBed;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class MapManager {

    private final TownyRespawnPlugin plugin;
    private final File dataFile;
    private final Map<UUID, GraphicsLevel> playerGraphics = new ConcurrentHashMap<>();

    public MapManager(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "player_graphics.yml");
    }

    public void load() {
        playerGraphics.clear();
        if (!dataFile.exists()) return;

        FileConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String uuidStr : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                String lvlStr = config.getString(uuidStr);
                playerGraphics.put(uuid, GraphicsLevel.fromString(lvlStr));
            } catch (Exception ignored) {}
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, GraphicsLevel> entry : playerGraphics.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue().name());
        }

        try {
            config.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save player_graphics.yml: " + e.getMessage());
        }
    }

    public GraphicsLevel getGraphicsLevel(Player player) {
        if (player == null) return GraphicsLevel.HIGH;
        return playerGraphics.computeIfAbsent(player.getUniqueId(), k -> {
            String def = plugin.getConfig().getString("map.default-graphics", "HIGH");
            return GraphicsLevel.fromString(def);
        });
    }

    public void setGraphicsLevel(Player player, GraphicsLevel level) {
        if (player == null || level == null) return;
        playerGraphics.put(player.getUniqueId(), level);
        save();
    }

    public GraphicsLevel cycleGraphicsLevel(Player player) {
        GraphicsLevel current = getGraphicsLevel(player);
        GraphicsLevel next = current.next();
        setGraphicsLevel(player, next);
        return next;
    }

    /**
     * Creates an interactive map item tile representing a chunk on the grid
     */
    public ItemStack createMapTile(Player viewer, int centerChunkX, int centerChunkZ, int chunkX, int chunkZ, GraphicsLevel level) {
        Location sampleLoc = new Location(viewer.getWorld(), (chunkX << 4) + 8, 64, (chunkZ << 4) + 8);
        String townName = plugin.getTownyHook().getTownNameAt(sampleLoc);
        Town town = plugin.getTownyHook().getTownAt(sampleLoc);
        boolean isUnderActiveSiege = townName != null && plugin.getTownySiegesHook().isTownUnderActiveSiege(townName);
        boolean isSiegeLocation = plugin.getTownySiegesHook().isLocationUnderActiveSiege(sampleLoc);

        // Check if player has a bed in this chunk
        PlayerBed bedInChunk = null;
        for (PlayerBed bed : plugin.getBedManager().getBeds(viewer)) {
            Location bLoc = bed.getLocation();
            if (bLoc != null && (bLoc.getBlockX() >> 4) == chunkX && (bLoc.getBlockZ() >> 4) == chunkZ) {
                bedInChunk = bed;
                break;
            }
        }

        boolean isPlayerCenter = (chunkX == (viewer.getLocation().getBlockX() >> 4)) &&
                                 (chunkZ == (viewer.getLocation().getBlockZ() >> 4));

        Material tileMaterial = resolveTileMaterial(level, townName, isUnderActiveSiege, isSiegeLocation, bedInChunk != null, isPlayerCenter);
        ItemStack item = new ItemStack(tileMaterial);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Title
        String title;
        if (isPlayerCenter) {
            title = "§e📍 Ваша позиция §7[Чанк " + chunkX + ", " + chunkZ + "]";
        } else if (bedInChunk != null) {
            title = "§b🛏 " + bedInChunk.getName() + " §7[Чанк " + chunkX + ", " + chunkZ + "]";
        } else if (isUnderActiveSiege) {
            title = "§4⚡ ОСАДА: Город " + townName + " §7[Чанк " + chunkX + ", " + chunkZ + "]";
        } else if (townName != null) {
            title = "§6🏛 Город «" + townName + "» §7[Чанк " + chunkX + ", " + chunkZ + "]";
        } else {
            title = "§7🌲 Дикая природа §8[Чанк " + chunkX + ", " + chunkZ + "]";
        }
        meta.setDisplayName(title);

        // Lore
        List<String> lore = new ArrayList<>();
        lore.add("§8Координаты мира: §fX: " + (chunkX << 4) + " .. " + ((chunkX << 4) + 15) + " §8| §fZ: " + (chunkZ << 4) + " .. " + ((chunkZ << 4) + 15));

        if (town != null) {
            lore.add("§7Мэр: §e" + (town.getMayor() != null ? town.getMayor().getName() : "Неизвестно"));
            lore.add("§7Жителей: §a" + town.getNumResidents() + " §7| Чанков: §a" + town.getNumTownBlocks());
            if (town.hasNation()) {
                lore.add("§7Нация: §6" + town.getNationOrNull().getName());
            }
        }

        if (isUnderActiveSiege || isSiegeLocation) {
            lore.add("§c⚔ Внимание! В этом секторе ведутся активные боевые действия!");
            lore.add("§4⚡ Орудийный огонь и осадные снаряды активны!");
        }

        if (bedInChunk != null) {
            lore.add("§a✔ Здесь установлена ваша точка возрождения!");
        }

        lore.add("§8Уровень графики: " + level.getDisplayName());
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    private Material resolveTileMaterial(GraphicsLevel level, String townName, boolean isUnderSiege, boolean isSiegeLocation, boolean hasBed, boolean isCenter) {
        if (hasBed) return Material.RED_BED;
        if (isCenter) return Material.PLAYER_HEAD;

        if (level == GraphicsLevel.LOW) {
            if (isUnderSiege || isSiegeLocation) return Material.RED_WOOL;
            if (townName != null) return Material.LIME_WOOL;
            return Material.WHITE_WOOL;
        } else if (level == GraphicsLevel.MEDIUM) {
            if (isUnderSiege || isSiegeLocation) return Material.RED_TERRACOTTA;
            if (townName != null) return Material.LIME_TERRACOTTA;
            return Material.GREEN_TERRACOTTA;
        } else if (level == GraphicsLevel.HIGH) {
            if (isUnderSiege || isSiegeLocation) return Material.RED_CONCRETE;
            if (townName != null) return Material.LIME_CONCRETE;
            return Material.CYAN_CONCRETE;
        } else {
            // HD (BlueMap Style)
            if (isUnderSiege || isSiegeLocation) return Material.MAGMA_BLOCK;
            if (townName != null) return Material.EMERALD_BLOCK;
            return Material.MOSS_BLOCK;
        }
    }
}
