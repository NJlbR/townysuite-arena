package com.towny.respawn.manager;

import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Town;
import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.model.PlayerBed;
import com.towny.respawn.model.RespawnPoint;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class RespawnManager {

    private final TownyRespawnPlugin plugin;
    private final Set<UUID> pendingRespawnPlayers = Collections.synchronizedSet(new HashSet<>());

    public RespawnManager(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    public void markPendingRespawn(UUID uuid) {
        pendingRespawnPlayers.add(uuid);
    }

    public void clearPendingRespawn(UUID uuid) {
        pendingRespawnPlayers.remove(uuid);
    }

    public boolean isPendingRespawn(UUID uuid) {
        return pendingRespawnPlayers.contains(uuid);
    }

    public List<RespawnPoint> getAvailableRespawnPoints(Player player) {
        List<RespawnPoint> points = new ArrayList<>();
        if (player == null) return points;

        // 1. Player multi-beds
        if (plugin.getConfig().getBoolean("beds.enabled", true)) {
            List<PlayerBed> beds = plugin.getBedManager().getBeds(player);
            for (PlayerBed bed : beds) {
                boolean physicalValid = plugin.getBedManager().isBedPhysicallyValid(bed);
                Location loc = bed.getLocation();

                List<String> lore = new ArrayList<>();
                lore.add("§7Мир: §e" + bed.getWorldName());
                lore.add("§7Координаты: §fX: " + (int) loc.getX() + " Y: " + (int) loc.getY() + " Z: " + (int) loc.getZ());
                if (physicalValid) {
                    lore.add("§a✔ Кровать цела и готова к возрождению");
                    lore.add("§e▸ Нажмите для возрождения");
                } else {
                    lore.add("§c✖ Кровать уничтожена или недоступна!");
                }

                points.add(new RespawnPoint(
                        RespawnPoint.Type.BED,
                        "bed_" + bed.getId(),
                        "§b🛏 " + bed.getName(),
                        lore,
                        physicalValid ? Material.RED_BED : Material.BARRIER,
                        loc,
                        physicalValid,
                        physicalValid ? null : "Кровать разрушена"
                ));
            }
        }

        // 2. Town spawn
        if (plugin.getConfig().getBoolean("respawn.allow-town-spawn", true) && plugin.getTownyHook().isTownyAvailable()) {
            Town town = plugin.getTownyHook().getPlayerTown(player);
            if (town != null) {
                Location tSpawn = plugin.getTownyHook().getTownSpawn(town);
                boolean underSiege = plugin.getTownySiegesHook().isTownUnderActiveSiege(town.getName());
                boolean blockedBySiege = underSiege && plugin.getConfig().getBoolean("respawn.block-spawn-if-under-siege", false);

                boolean valid = tSpawn != null && !blockedBySiege;
                List<String> lore = new ArrayList<>();
                lore.add("§7Город: §6" + town.getName());
                if (underSiege) {
                    lore.add("§4⚡ ГОРОД ПОД АКТИВНЫМ ШТУРМОМ!");
                }
                if (blockedBySiege) {
                    lore.add("§c✖ Спавн заблокирован осадным положением!");
                } else {
                    lore.add("§a✔ Ратуша города открыта для жителей");
                    lore.add("§e▸ Нажмите для возрождения в ратуше");
                }

                points.add(new RespawnPoint(
                        RespawnPoint.Type.TOWN_SPAWN,
                        "town_spawn",
                        "§6🏛 Спавн Города (" + town.getName() + ")",
                        lore,
                        valid ? Material.GOLD_BLOCK : Material.COPPER_BLOCK,
                        tSpawn,
                        valid,
                        blockedBySiege ? "Город осажден" : (tSpawn == null ? "Спавн не установлен" : null)
                ));
            }
        }

        // 3. Nation spawn
        if (plugin.getConfig().getBoolean("respawn.allow-nation-spawn", true) && plugin.getTownyHook().isTownyAvailable()) {
            Nation nation = plugin.getTownyHook().getPlayerNation(player);
            if (nation != null) {
                Location nSpawn = plugin.getTownyHook().getNationSpawn(nation);
                boolean valid = nSpawn != null;

                List<String> lore = new ArrayList<>();
                lore.add("§7Нация: §e" + nation.getName());
                if (nation.getCapital() != null) {
                    lore.add("§7Столица: §f" + nation.getCapital().getName());
                }
                if (valid) {
                    lore.add("§a✔ Столица нации готова принять союзников");
                    lore.add("§e▸ Нажмите для возрождения в столице");
                } else {
                    lore.add("§c✖ Спавн столицы нации недоступен");
                }

                points.add(new RespawnPoint(
                        RespawnPoint.Type.NATION_SPAWN,
                        "nation_spawn",
                        "§e👑 Спавн Столицы Нации (" + nation.getName() + ")",
                        lore,
                        valid ? Material.EMERALD_BLOCK : Material.IRON_BLOCK,
                        nSpawn,
                        valid,
                        valid ? null : "Спавн нации недоступен"
                ));
            }
        }

        // 4. Vanilla respawn (Random / Wilderness)
        if (plugin.getConfig().getBoolean("respawn.vanilla-respawn.enabled", true)) {
            List<String> rawLore = plugin.getConfig().getStringList("respawn.vanilla-respawn.description");
            List<String> lore = new ArrayList<>();
            for (String line : rawLore) {
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }

            points.add(new RespawnPoint(
                    RespawnPoint.Type.VANILLA_RANDOM,
                    "vanilla_respawn",
                    ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("respawn.vanilla-respawn.label", "&a&l🌲 Ванильный респавн")),
                    lore,
                    Material.COMPASS,
                    getSafeWildernessLocation(player.getWorld()),
                    true,
                    null
            ));
        }

        // 5. Server spawn
        if (plugin.getConfig().getBoolean("respawn.server-spawn.enabled", true)) {
            List<String> rawLore = plugin.getConfig().getStringList("respawn.server-spawn.description");
            List<String> lore = new ArrayList<>();
            for (String line : rawLore) {
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }

            Location serverSpawn = getServerSpawnLocation(player.getWorld());
            points.add(new RespawnPoint(
                    RespawnPoint.Type.SERVER_SPAWN,
                    "server_spawn",
                    ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("respawn.server-spawn.label", "&6&l🏛 На спавн сервера")),
                    lore,
                    Material.BEACON,
                    serverSpawn,
                    true,
                    null
            ));
        }

        return points;
    }

    public Location getServerSpawnLocation(World defaultWorld) {
        if (plugin.getConfig().getBoolean("respawn.server-spawn.custom-coords.enabled", false)) {
            String wName = plugin.getConfig().getString("respawn.server-spawn.custom-coords.world", "world");
            World w = Bukkit.getWorld(wName);
            if (w == null) w = defaultWorld;
            double x = plugin.getConfig().getDouble("respawn.server-spawn.custom-coords.x", 0.5);
            double y = plugin.getConfig().getDouble("respawn.server-spawn.custom-coords.y", 70.0);
            double z = plugin.getConfig().getDouble("respawn.server-spawn.custom-coords.z", 0.5);
            float yaw = (float) plugin.getConfig().getDouble("respawn.server-spawn.custom-coords.yaw", 0.0);
            float pitch = (float) plugin.getConfig().getDouble("respawn.server-spawn.custom-coords.pitch", 0.0);
            return new Location(w, x, y, z, yaw, pitch);
        }

        if (defaultWorld != null) {
            return defaultWorld.getSpawnLocation().add(0.5, 0.1, 0.5);
        }
        World mainWorld = Bukkit.getWorlds().get(0);
        return mainWorld.getSpawnLocation().add(0.5, 0.1, 0.5);
    }

    public Location getSafeWildernessLocation(World world) {
        if (world == null) world = Bukkit.getWorlds().get(0);

        int minR = plugin.getConfig().getInt("respawn.vanilla-respawn.wild-radius-min", 200);
        int maxR = plugin.getConfig().getInt("respawn.vanilla-respawn.wild-radius-max", 1500);

        Random rnd = new Random();
        double angle = rnd.nextDouble() * 2 * Math.PI;
        double dist = minR + rnd.nextDouble() * (maxR - minR);

        int targetX = (int) (Math.cos(angle) * dist);
        int targetZ = (int) (Math.sin(angle) * dist);

        int targetY = world.getHighestBlockYAt(targetX, targetZ);
        if (targetY < 5) targetY = 70;

        return new Location(world, targetX + 0.5, targetY + 1.0, targetZ + 0.5);
    }

    public void executeRespawn(Player player, RespawnPoint point) {
        if (player == null || point == null) return;

        clearPendingRespawn(player.getUniqueId());

        Location target = point.getLocation();
        if (target == null || target.getWorld() == null) {
            target = getServerSpawnLocation(player.getWorld());
        }

        // Ensure safe ground
        World w = target.getWorld();
        Block feet = target.getBlock();
        Block below = w.getBlockAt(target.getBlockX(), target.getBlockY() - 1, target.getBlockZ());
        if (below.isPassable() && target.getBlockY() > 1) {
            int highest = w.getHighestBlockYAt(target.getBlockX(), target.getBlockZ());
            target.setY(highest + 1.0);
        }

        player.setGameMode(GameMode.SURVIVAL);
        player.teleport(target);
        player.setFallDistance(0.0f);
        player.setFireTicks(0);

        // Apply invulnerability
        int invulSec = plugin.getConfig().getInt("respawn.effects.invulnerability-seconds", 5);
        if (invulSec > 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, invulSec * 20, 4, false, false, true));
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, invulSec * 20, 2, false, false, true));
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, invulSec * 20, 0, false, false, true));
        }

        // Sounds & effects
        if (plugin.getConfig().getBoolean("respawn.effects.play-sound", true)) {
            String sName = plugin.getConfig().getString("respawn.effects.sound-name", "ITEM_TOTEM_USE");
            try {
                Sound sound = Sound.valueOf(sName.toUpperCase());
                player.playSound(target, sound, 1.0f, 1.0f);
            } catch (Exception ignored) {
                player.playSound(target, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
        }

        if (plugin.getConfig().getBoolean("respawn.effects.spawn-particles", true)) {
            player.spawnParticle(Particle.TOTEM, target.clone().add(0, 1.0, 0), 30, 0.5, 0.8, 0.5, 0.1);
        }

        String prefix = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.prefix", "&b&l[TownyRespawn]&r "));
        String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.respawn-selected", "&aВы успешно возродились: &f{location}&a!"))
                .replace("{location}", point.getTitle());
        player.sendMessage(prefix + msg);
    }
}
