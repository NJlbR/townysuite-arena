package com.towny.respawn.command;

import com.towny.respawn.TownyRespawnPlugin;
import com.towny.respawn.gui.MapMenuHolder;
import com.towny.respawn.model.GraphicsLevel;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MapCommand implements CommandExecutor, TabCompleter {

    private final TownyRespawnPlugin plugin;

    public MapCommand(TownyRespawnPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmdName = command.getName().toLowerCase();

        // Admin command /townyrespawn
        if (cmdName.equals("townyrespawn")) {
            if (!sender.hasPermission("townyrespawn.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownyRespawn] У вас нет прав для выполнения этой команды.");
                return true;
            }

            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                plugin.reloadConfig();
                plugin.getBedManager().load();
                plugin.getMapManager().load();
                sender.sendMessage(ChatColor.GREEN + "[TownyRespawn] Конфигурация, точки кроватей и настройки графики перезагружены!");
                return true;
            }

            sender.sendMessage(ChatColor.AQUA + "--- TownyRespawn v1.0.0 ---");
            sender.sendMessage(ChatColor.YELLOW + "/map " + ChatColor.GRAY + "- Открыть интерактивную карту мира");
            sender.sendMessage(ChatColor.YELLOW + "/map graphics <уровень> " + ChatColor.GRAY + "- Сменить уровень графики карты");
            sender.sendMessage(ChatColor.YELLOW + "/respawn " + ChatColor.GRAY + "- Открыть меню выбора точек возрождения");
            sender.sendMessage(ChatColor.YELLOW + "/townyrespawn reload " + ChatColor.GRAY + "- Перезагрузить плагин");
            return true;
        }

        // /respawn or /beds
        if (cmdName.equals("respawn")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Команда доступна только игрокам.");
                return true;
            }
            Player player = (Player) sender;
            plugin.getGuiManager().openDeathRespawnGui(player);
            return true;
        }

        // /map command
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Команда доступна только игрокам.");
            return true;
        }
        Player player = (Player) sender;

        if (args.length >= 2 && args[0].equalsIgnoreCase("graphics")) {
            GraphicsLevel level = GraphicsLevel.fromString(args[1]);
            plugin.getMapManager().setGraphicsLevel(player, level);
            String prefix = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.prefix", "&b&l[TownyRespawn]&r "));
            String msg = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("messages.graphics-changed", "&eУровень графики изменен на: {level}"))
                    .replace("{level}", level.getDisplayName());
            player.sendMessage(prefix + msg);
            return true;
        }

        // Open map GUI
        plugin.getGuiManager().openMapGui(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        String cmdName = command.getName().toLowerCase();

        if (cmdName.equals("map")) {
            if (args.length == 1) {
                completions.add("graphics");
            } else if (args.length == 2 && args[0].equalsIgnoreCase("graphics")) {
                completions.addAll(Arrays.stream(GraphicsLevel.values())
                        .map(Enum::name)
                        .collect(Collectors.toList()));
            }
        } else if (cmdName.equals("townyrespawn")) {
            if (args.length == 1) {
                completions.add("reload");
            }
        }

        String last = args.length > 0 ? args[args.length - 1].toLowerCase() : "";
        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(last))
                .collect(Collectors.toList());
    }
}
