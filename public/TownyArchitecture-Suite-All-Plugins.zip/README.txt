Towny Architecture & War Suite:
- TownyArchitecture.jar (Модульные постройки, чертежи, щиты)
- TownySieges.jar (Осады, осадные лагеря, осадные орудия с механикой сидения и прицельной стрельбы)
- TownyRespawn.jar (Управление возрождением)
- TownyExplosionUnblocker.jar (Снятие ограничений взрывов в активной фазе)
