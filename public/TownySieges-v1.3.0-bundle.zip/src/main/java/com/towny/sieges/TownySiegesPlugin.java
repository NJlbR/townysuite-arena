package com.towny.sieges;

import com.towny.sieges.bossbar.SiegeBossBarManager;
import com.towny.sieges.cannon.SiegeCannonManager;
import com.towny.sieges.command.SiegeCommand;
import com.towny.sieges.hook.TownyHook;
import com.towny.sieges.listener.SiegeProtectionListener;
import com.towny.sieges.manager.SiegeManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public class TownySiegesPlugin extends JavaPlugin {

    private static TownySiegesPlugin instance;

    private TownyHook townyHook;
    private SiegeManager siegeManager;
    private SiegeBossBarManager bossBarManager;
    private SiegeCannonManager cannonManager;

    private BukkitTask tickerTask;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        townyHook = new TownyHook();
        siegeManager = new SiegeManager(this);
        bossBarManager = new SiegeBossBarManager(this);
        cannonManager = new SiegeCannonManager(this);

        siegeManager.loadData();

        SiegeCommand cmd = new SiegeCommand(this);
        if (getCommand("siege") != null) {
            getCommand("siege").setExecutor(cmd);
            getCommand("siege").setTabCompleter(cmd);
        }

        cannonManager.registerRecipes();

        getServer().getPluginManager().registerEvents(new SiegeProtectionListener(this), this);

        // Register Towny notification interceptor to prevent '~ Wilderness' from overriding siege camps
        if (townyHook != null && townyHook.isTownyEnabled()) {
            try {
                Class.forName("com.palmergames.bukkit.towny.event.ChunkNotificationEvent");
                getServer().getPluginManager().registerEvents(new com.towny.sieges.listener.TownyNotificationListener(this), this);
                getLogger().info("[TownySieges] TownyNotificationListener зарегистрирован: перехват Wilderness -> Осадный лагерь активен.");
            } catch (Throwable t) {
                getLogger().warning("[TownySieges] Towny notification interception skipped: " + t.getMessage());
            }
        }

        // 1 second tick loop for siege state changes and bossbar countdowns
        tickerTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            siegeManager.tick();
        }, 20L, 20L);

        getLogger().info("[TownySieges] Плагин осад и осадных лагерей успешно запущен!");
    }

    @Override
    public void onDisable() {
        if (tickerTask != null) {
            tickerTask.cancel();
        }
        if (siegeManager != null) {
            siegeManager.saveData();
        }
        if (bossBarManager != null) {
            bossBarManager.clearAll();
        }
        if (cannonManager != null) {
            cannonManager.clearAll();
        }
        getLogger().info("[TownySieges] Плагин выключен. Данные сохранены.");
    }

    public static TownySiegesPlugin getInstance() {
        return instance;
    }

    public TownyHook getTownyHook() {
        return townyHook;
    }

    public SiegeManager getSiegeManager() {
        return siegeManager;
    }

    public SiegeBossBarManager getBossBarManager() {
        return bossBarManager;
    }

    public SiegeCannonManager getCannonManager() {
        return cannonManager;
    }

    /**
     * Static API for TownyExplosionUnblocker and TownyArchitecture:
     * Checks if a town is currently in the active 2-hour assault phase.
     */
    public static boolean isTownUnderActiveSiege(String townName) {
        if (instance == null || instance.getSiegeManager() == null) return false;
        return instance.getSiegeManager().isTownUnderActiveSiege(townName);
    }

    /**
     * Static API: Checks if a location belongs to a town that is currently under active 2-hour siege.
     */
    public static boolean isLocationUnderActiveSiege(Location loc) {
        if (instance == null || instance.getSiegeManager() == null) return false;
        return instance.getSiegeManager().isLocationUnderActiveSiege(loc);
    }
}
