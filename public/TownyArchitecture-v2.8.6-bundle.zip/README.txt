TownyArchitecture v2.8.6
========================
Release: Final Bundle Sync & Shield Integration (v2.8.6)

Installation:
1. Put TownyArchitecture-2.8.6.jar into your server's plugins/ directory.
2. Make sure Towny (0.98+) is installed.
3. Restart or reload your server.
4. Run /builds to open the architectural blueprints catalog.

Fixes in v2.8.6:
- Integrated Town Hall Shield with TownySieges for capture protection.
- Fixed blueprint IDs in Shield Manager (town_hall, city_wall).
- Added Town Hall and City Wall to the catalog.
- Modern GUI background restored.
