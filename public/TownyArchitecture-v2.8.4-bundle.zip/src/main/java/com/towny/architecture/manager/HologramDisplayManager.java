package com.towny.architecture.manager;

import com.towny.architecture.TownyArchitecturePlugin;
import com.towny.architecture.model.ActiveBuilding;
import com.towny.architecture.model.BuildingSchematic;
import com.towny.architecture.model.SchematicBlock;
import org.bukkit.*;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HologramDisplayManager {
    public static final Color GLOW_BLUE = Color.fromRGB(0, 180, 255); // Blue/Cyan outline for clear ghost blocks
    public static final Color GLOW_RED = Color.fromRGB(255, 30, 30);  // Red outline for obstacle / damaged blocks

    private final TownyArchitecturePlugin plugin;
    private final NamespacedKey hologramKey;
    private final NamespacedKey blockCoordKey;

    // Map: instanceId -> Map<"dx,dy,dz", BlockDisplay>
    private final Map<String, Map<String, BlockDisplay>> activeDisplays = new ConcurrentHashMap<>();

    public HologramDisplayManager(TownyArchitecturePlugin plugin) {
        this.plugin = plugin;
        this.hologramKey = new NamespacedKey(plugin, "hologram_instance");
        this.blockCoordKey = new NamespacedKey(plugin, "hologram_coord");
    }

    private Display.Brightness getConfiguredBrightness() {
        int b = plugin.getConfig().getInt("settings.hologram.brightness-block", 15);
        int s = plugin.getConfig().getInt("settings.hologram.brightness-sky", 15);
        b = Math.max(0, Math.min(15, b));
        s = Math.max(0, Math.min(15, s));
        return new Display.Brightness(b, s);
    }

    /**
     * Creates transformation with exact offset and scale to guarantee complete 3D outlines
     * along all 6 faces and 12 edges of every block, preventing glow merging between adjacent blocks.
     */
    public Transformation createBlockTransformation() {
        return new Transformation(
                new Vector3f(-0.004f, -0.004f, -0.004f),
                new AxisAngle4f(),
                new Vector3f(1.008f, 1.008f, 1.008f),
                new AxisAngle4f()
        );
    }

    /**
     * Initializes holograms for an active building (spawns the current active layer)
     */
    public void initHologramsForBuilding(ActiveBuilding bld) {
        clearHologramsForBuilding(bld.getInstanceId());
        if (bld.getStatus() != ActiveBuilding.Status.CONSTRUCTING) {
            return; // Never show holograms for completed or non-constructing buildings!
        }
        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return;

        World world = Bukkit.getWorld(bld.getWorldName());
        if (world == null) return;

        int targetLayer = bld.getCurrentLayer();
        while (targetLayer <= schem.getMaxLayer()) {
            List<SchematicBlock> lBlocks = schem.getBlocksAtLayer(targetLayer);
            if (lBlocks != null && !lBlocks.isEmpty()) {
                boolean hasUncompleted = false;
                for (SchematicBlock sb : lBlocks) {
                    if (!bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                        hasUncompleted = true;
                        break;
                    }
                }
                if (hasUncompleted) {
                    break;
                }
            }
            targetLayer++;
        }

        if (targetLayer > schem.getMaxLayer()) {
            return;
        }
        bld.setCurrentLayer(targetLayer);
        spawnLayerHolograms(bld, schem, world, targetLayer);
    }

    /**
     * Spawns holograms for a specific layer that haven't been completed yet
     */
    public void spawnLayerHolograms(ActiveBuilding bld, BuildingSchematic schem, World world, int layerY) {
        Map<String, BlockDisplay> buildingMap = activeDisplays.computeIfAbsent(bld.getInstanceId(), k -> new ConcurrentHashMap<>());

        List<SchematicBlock> layerBlocks = schem.getBlocksAtLayer(layerY);
        for (SchematicBlock sb : layerBlocks) {
            String coordKey = sb.getKey();
            if (bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                continue; // Already placed in world!
            }
            if (buildingMap.containsKey(coordKey)) {
                BlockDisplay old = buildingMap.get(coordKey);
                if (old != null && old.isValid() && !old.isDead()) {
                    continue; // Already has valid display entity
                }
            }

            int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
            Location spawnLoc = new Location(world, 
                    bld.getOriginX() + rPos[0],
                    bld.getOriginY() + sb.getDy(),
                    bld.getOriginZ() + rPos[1]);

            // If block is already completed or already physically placed in world, mark and skip
            if (BuildingManager.isMaterialMatch(world.getBlockAt(spawnLoc).getType(), sb.getMaterial())) {
                bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                bld.addPlacedBlock(sb.getMaterial());
                continue;
            }

            try {
                org.bukkit.block.Block worldBlock = world.getBlockAt(spawnLoc);
                Material worldMat = worldBlock.getType();
                boolean isObstacle = !worldMat.isAir() && !(worldMat == Material.WATER || worldMat == Material.LAVA) && !BuildingManager.isMaterialMatch(worldMat, sb.getMaterial());

                BlockDisplay display = world.spawn(spawnLoc, BlockDisplay.class, entity -> {
                    if (isObstacle) {
                        entity.setBlock(worldBlock.getBlockData());
                        entity.setGlowColorOverride(GLOW_RED);
                    } else {
                        entity.setBlock(sb.getMaterial().createBlockData());
                        entity.setGlowColorOverride(GLOW_BLUE);
                    }
                    entity.setBrightness(getConfiguredBrightness());
                    entity.setShadowRadius(0f);
                    entity.setShadowStrength(0f);
                    entity.setInterpolationDuration(0);
                    entity.setTeleportDuration(0);
                    
                    entity.setTransformation(createBlockTransformation());
                    entity.setGlowing(true);
                    entity.setInvulnerable(true);
                    
                    entity.getPersistentDataContainer().set(hologramKey, PersistentDataType.STRING, bld.getInstanceId());
                    entity.getPersistentDataContainer().set(blockCoordKey, PersistentDataType.STRING, coordKey);
                    entity.setPersistent(false);
                });
                buildingMap.put(coordKey, display);
            } catch (Exception e) {
                plugin.getLogger().warning("Ошибка спавна BlockDisplay в " + spawnLoc + ": " + e.getMessage());
            }
        }
    }

    /**
     * Checks if all blocks of the current layer are finished (both in memory and in the physical world)
     * and advances the building to subsequent layers if complete.
     */
    public boolean checkAndAdvanceLayer(ActiveBuilding bld, BuildingSchematic schem, World world) {
        if (bld == null || schem == null || world == null) return false;

        int currentLayer = bld.getCurrentLayer();
        boolean layerDone = true;
        List<SchematicBlock> layerBlocks = schem.getBlocksAtLayer(currentLayer);

        for (SchematicBlock sb : layerBlocks) {
            if (bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                continue;
            }
            // Verify physical world block at calculated coordinate
            int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
            int wx = bld.getOriginX() + rPos[0];
            int wy = bld.getOriginY() + sb.getDy();
            int wz = bld.getOriginZ() + rPos[1];

            if (wy >= world.getMinHeight() && wy < world.getMaxHeight()) {
                Material wm = world.getBlockAt(wx, wy, wz).getType();
                if (BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
                    bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                    bld.addPlacedBlock(sb.getMaterial());
                    continue;
                }
            }
            layerDone = false;
            break;
        }

        if (!layerDone) {
            return false;
        }

        // Layer is complete! Advance forward!
        clearHologramsForBuilding(bld.getInstanceId());

        while (layerDone && currentLayer < schem.getMaxLayer()) {
            currentLayer++;
            bld.setCurrentLayer(currentLayer);

            layerDone = true;
            for (SchematicBlock sb : schem.getBlocksAtLayer(currentLayer)) {
                if (bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                    continue;
                }
                int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
                int wx = bld.getOriginX() + rPos[0];
                int wy = bld.getOriginY() + sb.getDy();
                int wz = bld.getOriginZ() + rPos[1];
                if (wy >= world.getMinHeight() && wy < world.getMaxHeight()) {
                    Material wm = world.getBlockAt(wx, wy, wz).getType();
                    if (BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
                        bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                        bld.addPlacedBlock(sb.getMaterial());
                        continue;
                    }
                }
                layerDone = false;
                break;
            }

            if (!layerDone) {
                spawnLayerHolograms(bld, schem, world, currentLayer);
                Location loc = new Location(world,
                        bld.getOriginX() + (schem.getWidthX() / 2),
                        bld.getOriginY() + currentLayer,
                        bld.getOriginZ() + (schem.getLengthZ() / 2));
                world.playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.3f);
                return true; // Successfully advanced to next layer!
            }
        }

        if (layerDone && currentLayer >= schem.getMaxLayer()) {
            clearHologramsForBuilding(bld.getInstanceId());
            return true;
        }
        return false;
    }

    /**
     * Handles when a correct block was placed: removes the single hologram and checks layer progression
     */
    public boolean handleBlockPlaced(ActiveBuilding bld, int dx, int dy, int dz) {
        String coordKey = dx + "," + dy + "," + dz;
        Map<String, BlockDisplay> map = activeDisplays.get(bld.getInstanceId());
        if (map != null) {
            BlockDisplay display = map.remove(coordKey);
            if (display != null && display.isValid()) {
                display.remove();
            }
        }

        if (bld.getStatus() != ActiveBuilding.Status.CONSTRUCTING) {
            // When repairing damaged/active building, placing the block only removes that single hologram.
            // Do NOT call checkAndAdvanceLayer which would wipe holograms of other layers!
            return false;
        }

        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return false;

        World world = Bukkit.getWorld(bld.getWorldName());
        boolean advanced = checkAndAdvanceLayer(bld, schem, world);
        healOrRefreshLayerHolograms(bld);
        return advanced;
    }

    /**
     * Called when a block is placed or broken anywhere within an active building plot:
     * instantly updates hologram glow color (Red <-> Blue) or respawns if missing.
     */
    public void onWorldBlockChanged(ActiveBuilding bld, Location loc) {
        if (bld == null || loc == null) return;
        if (bld.getStatus() != ActiveBuilding.Status.CONSTRUCTING && bld.getStatus() != ActiveBuilding.Status.DAMAGED) return;
        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return;

        int rx = loc.getBlockX() - bld.getOriginX();
        int dy = loc.getBlockY() - bld.getOriginY();
        int rz = loc.getBlockZ() - bld.getOriginZ();

        int[] unrot = BuildingManager.unrotateRelativeCoords(rx, rz, bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
        int dx = unrot[0];
        int dz = unrot[1];

        if (bld.getStatus() == ActiveBuilding.Status.CONSTRUCTING && dy != bld.getCurrentLayer()) return; // only current layer has active holograms in construction

        SchematicBlock sb = schem.getBlock(dx, dy, dz);
        if (sb == null) return;

        Map<String, BlockDisplay> map = activeDisplays.get(bld.getInstanceId());
        World world = loc.getWorld();
        if (world == null) return;

        org.bukkit.block.Block worldBlock = world.getBlockAt(loc);
        Material wm = worldBlock.getType();
        if (BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
            // Block was placed correctly and matches schematic!
            bld.markBlockCompleted(dx, dy, dz);
            bld.addPlacedBlock(sb.getMaterial());
            if (map != null) {
                BlockDisplay display = map.remove(sb.getKey());
                if (display != null && display.isValid()) {
                    display.remove();
                }
            }
            if (bld.getStatus() == ActiveBuilding.Status.CONSTRUCTING) {
                checkAndAdvanceLayer(bld, schem, world);
            }
            return;
        }

        // Not completed: determine if obstacle exists
        boolean isObstacle = !wm.isAir() && !(wm == Material.WATER || wm == Material.LAVA);
        if (map != null && map.containsKey(sb.getKey())) {
            BlockDisplay disp = map.get(sb.getKey());
            if (disp != null && disp.isValid() && !disp.isDead()) {
                try {
                    if (isObstacle) {
                        disp.setBlock(worldBlock.getBlockData());
                        disp.setGlowColorOverride(GLOW_RED);
                    } else {
                        disp.setBlock(sb.getMaterial().createBlockData());
                        disp.setGlowColorOverride(GLOW_BLUE);
                    }
                    disp.setTransformation(createBlockTransformation());
                } catch (Throwable ignored) {}
                return;
            }
        }

        // If display was missing, respawn it
        respawnHologramForMissingBlock(bld, dx, dy, dz, sb.getMaterial());
    }

    /**
     * Self-healing watchdog: checks if any holograms for the current layer of a constructing building
     * have been destroyed, despawned, or unloaded, dynamically updates their Red/Blue glowing outlines,
     * and safely respawns them if the chunk is loaded.
     */
    public int healOrRefreshLayerHolograms(ActiveBuilding bld) {
        if (bld == null || bld.getStatus() != ActiveBuilding.Status.CONSTRUCTING) return 0;
        World world = Bukkit.getWorld(bld.getWorldName());
        if (world == null) return 0;

        // Ensure chunks are currently loaded in world so we do not force-load distant chunks
        boolean chunkLoaded = false;
        if (bld.getAssignedChunks() != null && !bld.getAssignedChunks().isEmpty()) {
            for (com.towny.architecture.model.ChunkCoord cc : bld.getAssignedChunks()) {
                if (world.isChunkLoaded(cc.getX(), cc.getZ())) {
                    chunkLoaded = true;
                    break;
                }
            }
        } else {
            chunkLoaded = world.isChunkLoaded(bld.getOriginX() >> 4, bld.getOriginZ() >> 4);
        }
        if (!chunkLoaded) return 0;

        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return 0;

        int targetLayer = bld.getCurrentLayer();
        List<SchematicBlock> layerBlocks = schem.getBlocksAtLayer(targetLayer);
        if (layerBlocks == null || layerBlocks.isEmpty()) return 0;

        Map<String, BlockDisplay> buildingMap = activeDisplays.computeIfAbsent(bld.getInstanceId(), k -> new ConcurrentHashMap<>());
        buildingMap.entrySet().removeIf(e -> e.getValue() == null || !e.getValue().isValid() || e.getValue().isDead());

        int healed = 0;
        for (SchematicBlock sb : layerBlocks) {
            if (bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                continue;
            }

            int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
            int wx = bld.getOriginX() + rPos[0];
            int wy = bld.getOriginY() + sb.getDy();
            int wz = bld.getOriginZ() + rPos[1];

            // If block is already physically placed in world, mark and skip
            org.bukkit.block.Block worldBlock = world.getBlockAt(wx, wy, wz);
            Material wm = worldBlock.getType();
            if (BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
                bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                bld.addPlacedBlock(sb.getMaterial());
                BlockDisplay oldDisp = buildingMap.remove(sb.getKey());
                if (oldDisp != null && oldDisp.isValid()) {
                    oldDisp.remove();
                }
                continue;
            }

            boolean isObstacle = !wm.isAir() && !(wm == Material.WATER || wm == Material.LAVA);
            String coordKey = sb.getKey();
            BlockDisplay existing = buildingMap.get(coordKey);
            if (existing == null || !existing.isValid() || existing.isDead()) {
                respawnHologramForMissingBlock(bld, sb.getDx(), sb.getDy(), sb.getDz(), sb.getMaterial());
                healed++;
            } else {
                // Dynamically ensure exact block data & glow color (Red with obstacle block data for Obstacle, Blue with schematic block data for Clean Ghost)
                try {
                    if (isObstacle) {
                        existing.setBlock(worldBlock.getBlockData());
                        existing.setGlowColorOverride(GLOW_RED);
                    } else {
                        existing.setBlock(sb.getMaterial().createBlockData());
                        existing.setGlowColorOverride(GLOW_BLUE);
                    }
                    existing.setTransformation(createBlockTransformation());
                } catch (Throwable ignored) {}
            }
        }
        return healed;
    }

    public void respawnHologramForMissingBlock(ActiveBuilding bld, int dx, int dy, int dz, Material mat) {
        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return;

        SchematicBlock sb = schem.getBlock(dx, dy, dz);
        if (sb == null) return; // Not part of blueprint!

        // If building is still constructing, NEVER spawn holograms for future layers!
        if (bld.getStatus() == ActiveBuilding.Status.CONSTRUCTING && sb.getDy() > bld.getCurrentLayer()) {
            return;
        }

        World world = Bukkit.getWorld(bld.getWorldName());
        if (world == null) return;

        String coordKey = dx + "," + dy + "," + dz;
        Map<String, BlockDisplay> buildingMap = activeDisplays.computeIfAbsent(bld.getInstanceId(), k -> new ConcurrentHashMap<>());

        int[] rPos = BuildingManager.rotateRelativeCoords(dx, dz, bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
        Location spawnLoc = new Location(world, bld.getOriginX() + rPos[0], bld.getOriginY() + dy, bld.getOriginZ() + rPos[1]);

        org.bukkit.block.Block worldBlock = world.getBlockAt(spawnLoc);
        Material worldMat = worldBlock.getType();

        // If the block is physically present and matches the blueprint, it is NOT missing!
        // Immediately remove any ghost hologram and mark completed.
        if (BuildingManager.isMaterialMatch(worldMat, sb.getMaterial())) {
            bld.markBlockCompleted(dx, dy, dz);
            BlockDisplay existing = buildingMap.remove(coordKey);
            if (existing != null && existing.isValid()) {
                existing.remove();
            }
            return;
        }

        if (buildingMap.containsKey(coordKey)) {
            BlockDisplay existing = buildingMap.get(coordKey);
            if (existing != null && existing.isValid() && !existing.isDead()) {
                try {
                    boolean isObstacle = !worldMat.isAir() && !(worldMat == Material.WATER || worldMat == Material.LAVA) && !BuildingManager.isMaterialMatch(worldMat, sb.getMaterial());
                    if (isObstacle) {
                        existing.setBlock(worldBlock.getBlockData());
                        existing.setGlowColorOverride(GLOW_RED);
                    } else {
                        existing.setBlock(sb.getMaterial().createBlockData());
                        existing.setGlowColorOverride(GLOW_BLUE);
                    }
                    existing.setTransformation(createBlockTransformation());
                } catch (Throwable ignored) {}
                return;
            } else {
                buildingMap.remove(coordKey);
            }
        }
        
        try {
            boolean isObstacle = !worldMat.isAir() && !(worldMat == Material.WATER || worldMat == Material.LAVA) && !BuildingManager.isMaterialMatch(worldMat, sb.getMaterial());

            BlockDisplay display = world.spawn(spawnLoc, BlockDisplay.class, entity -> {
                if (isObstacle) {
                    entity.setBlock(worldBlock.getBlockData());
                    entity.setGlowColorOverride(GLOW_RED);
                } else {
                    entity.setBlock(sb.getMaterial().createBlockData());
                    entity.setGlowColorOverride(GLOW_BLUE);
                }
                entity.setBrightness(getConfiguredBrightness());
                entity.setShadowRadius(0f);
                entity.setShadowStrength(0f);
                entity.setInterpolationDuration(0);
                entity.setTeleportDuration(0);
                
                entity.setTransformation(createBlockTransformation());
                entity.setGlowing(true);
                entity.setInvulnerable(true);
                
                entity.getPersistentDataContainer().set(hologramKey, PersistentDataType.STRING, bld.getInstanceId());
                entity.getPersistentDataContainer().set(blockCoordKey, PersistentDataType.STRING, coordKey);
                entity.setPersistent(false);
            });
            buildingMap.put(coordKey, display);
        } catch (Exception ignored) {}
    }

    public void clearHologramsForBuilding(String instanceId) {
        Map<String, BlockDisplay> map = activeDisplays.remove(instanceId);
        if (map != null) {
            for (BlockDisplay d : map.values()) {
                if (d != null && d.isValid()) {
                    d.remove();
                }
            }
            map.clear();
        }
    }

    public void clearAll() {
        for (Map<String, BlockDisplay> map : activeDisplays.values()) {
            for (BlockDisplay d : map.values()) {
                if (d != null && d.isValid()) {
                    d.remove();
                }
            }
            map.clear();
        }
        activeDisplays.clear();

        // Also sweep loaded worlds to purge any leftover tagged BlockDisplays
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntitiesByClass(BlockDisplay.class)) {
                if (entity.getPersistentDataContainer().has(hologramKey, PersistentDataType.STRING)) {
                    entity.remove();
                }
            }
        }
    }

    public NamespacedKey getHologramKey() { return hologramKey; }
    public NamespacedKey getBlockCoordKey() { return blockCoordKey; }
}
