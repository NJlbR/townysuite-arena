package com.towny.architecture.manager;

import com.towny.architecture.TownyArchitecturePlugin;
import com.towny.architecture.model.ActiveBuilding;
import com.towny.architecture.model.BuildingSchematic;
import com.towny.architecture.model.SchematicBlock;
import com.towny.architecture.model.BuildingBlueprint;
import com.towny.architecture.model.ChunkCoord;
import com.towny.architecture.util.RussianTranslator;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.util.*;

public class BuildingHudManager {
    private final TownyArchitecturePlugin plugin;
    private final Map<UUID, BossBar> playerBossBars = new HashMap<>();
    private final Map<UUID, Integer> playerCycleIndex = new HashMap<>();
    private final Map<UUID, Integer> playerTicksHeld = new HashMap<>();
    private final Set<UUID> playersParticlesDisabled = new HashSet<>();
    private final Set<UUID> playersEffectParticlesDisabled = new HashSet<>();

    private static Particle dustParticle;
    static {
        for (String pName : new String[]{"DUST", "REDSTONE", "END_ROD", "FLAME"}) {
            try {
                dustParticle = Particle.valueOf(pName);
                break;
            } catch (Throwable ignored) {}
        }
    }

    public BuildingHudManager(TownyArchitecturePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean hasParticlesEnabled(Player player) {
        return player != null && !playersParticlesDisabled.contains(player.getUniqueId());
    }

    public boolean hasEffectParticlesEnabled(Player player) {
        return player != null && !playersEffectParticlesDisabled.contains(player.getUniqueId());
    }

    public boolean toggleParticles(Player player) {
        if (player == null) return false;
        UUID uuid = player.getUniqueId();
        if (playersParticlesDisabled.contains(uuid)) {
            playersParticlesDisabled.remove(uuid);
            return true;
        } else {
            playersParticlesDisabled.add(uuid);
            return false;
        }
    }

    public boolean toggleEffectParticles(Player player) {
        if (player == null) return false;
        UUID uuid = player.getUniqueId();
        if (playersEffectParticlesDisabled.contains(uuid)) {
            playersEffectParticlesDisabled.remove(uuid);
            return true;
        } else {
            playersEffectParticlesDisabled.add(uuid);
            return false;
        }
    }

    public void setParticlesEnabled(Player player, boolean enabled) {
        if (player == null) return;
        if (enabled) {
            playersParticlesDisabled.remove(player.getUniqueId());
        } else {
            playersParticlesDisabled.add(player.getUniqueId());
        }
    }

    public void renderParticles() {
        if (!plugin.getConfig().getBoolean("settings.particles-enabled", true)) return;

        int radiusChunks = plugin.getConfig().getInt("settings.buff-1x1-chunk-radius", 2);

        Particle.DustOptions ghostCyanDust = new Particle.DustOptions(Color.fromRGB(0, 220, 255), 1.5f);
        Particle.DustOptions obstacleRedDust = new Particle.DustOptions(Color.fromRGB(255, 30, 40), 1.7f);
        Particle.DustOptions plotAquaDust = new Particle.DustOptions(Color.fromRGB(0, 180, 255), 1.8f);
        Particle.DustOptions footprintCyanDust = new Particle.DustOptions(Color.fromRGB(0, 230, 255), 1.8f);

        for (Player player : Bukkit.getOnlinePlayers()) {
            boolean showBorders = hasParticlesEnabled(player);
            boolean showEffects = hasEffectParticlesEnabled(player);
            if (!showBorders && !showEffects) continue;

            Location pLoc = player.getLocation();
            World pWorld = pLoc.getWorld();
            if (pWorld == null) continue;

            double pX = pLoc.getX();
            double pY = pLoc.getY();
            double pZ = pLoc.getZ();

            // 1. Render active building boundaries, effect zones, and ghost/obstacle block group wireframes
            for (ActiveBuilding bld : plugin.getBuildingManager().getActiveBuildings()) {
                if (!bld.getWorldName().equals(pWorld.getName())) continue;
                if (bld.getAssignedChunks().isEmpty()) continue;

                BuildingBlueprint bp = plugin.getBuildingManager().getBlueprint(bld.getBlueprintId());
                if (bp == null) continue;

                int minCX = Integer.MAX_VALUE, maxCX = Integer.MIN_VALUE;
                int minCZ = Integer.MAX_VALUE, maxCZ = Integer.MIN_VALUE;
                for (ChunkCoord c : bld.getAssignedChunks()) {
                    minCX = Math.min(minCX, c.getX());
                    maxCX = Math.max(maxCX, c.getX());
                    minCZ = Math.min(minCZ, c.getZ());
                    maxCZ = Math.max(maxCZ, c.getZ());
                }

                double bMinX = minCX << 4;
                double bMaxX = (maxCX + 1) << 4;
                double bMinZ = minCZ << 4;
                double bMaxZ = (maxCZ + 1) << 4;

                // Footprint boundary line along plot perimeter
                if (showBorders && pX >= bMinX - 50 && pX <= bMaxX + 50 && pZ >= bMinZ - 50 && pZ <= bMaxZ + 50) {
                    renderSolidLine(player, pWorld, bMinX, bMaxX, bMinZ, bMaxZ, pX, pY, pZ, footprintCyanDust);
                    renderLayerBlockWireframes(player, pWorld, bld, pX, pY, pZ, ghostCyanDust, obstacleRedDust);
                }

                // C. Buff Zone boundary for 1x1 buildings (Clean, thin, continuous glowing line)
                if (showEffects && bp.getChunkWidth() == 1 && bp.getChunkLength() == 1) {
                    double effMinX = (minCX - radiusChunks) << 4;
                    double effMaxX = (maxCX + radiusChunks + 1) << 4;
                    double effMinZ = (minCZ - radiusChunks) << 4;
                    double effMaxZ = (maxCZ + radiusChunks + 1) << 4;

                    if (pX >= effMinX - 50 && pX <= effMaxX + 50 && pZ >= effMinZ - 50 && pZ <= effMaxZ + 50) {
                        Color buffColor;
                        String bpId = bld.getBlueprintId().toLowerCase();
                        if (bpId.contains("hospital") || bpId.contains("infirmary") || bpId.contains("barracks")) {
                            buffColor = Color.fromRGB(255, 35, 65); // Vivid Crimson Red
                        } else {
                            buffColor = Color.fromRGB(0, 200, 255); // Vivid Electric Cyan
                        }
                        Particle.DustOptions effectDust = new Particle.DustOptions(buffColor, 1.8f);
                        renderSolidLine(player, pWorld, effMinX, effMaxX, effMinZ, effMaxZ, pX, pY, pZ, effectDust);
                    }
                }
            }

            // 2. Render designated town build plots (Vivid Aqua / Sky Blue - NO yellow!)
            if (showBorders) {
                String playerTown = plugin.getTownyHook().getPlayerTownName(player);
                if (playerTown != null) {
                    Set<ChunkCoord> plots = plugin.getBuildingManager().getTownBuildPlots(playerTown);
                    if (!plots.isEmpty()) {
                        for (ChunkCoord cc : plots) {
                            if (plugin.getBuildingManager().isChunkOccupiedByBuilding(cc)) continue;
                            double minX = cc.getX() << 4;
                            double maxX = (cc.getX() + 1) << 4;
                            double minZ = cc.getZ() << 4;
                            double maxZ = (cc.getZ() + 1) << 4;

                            if (pX >= minX - 50 && pX <= maxX + 50 && pZ >= minZ - 50 && pZ <= maxZ + 50) {
                                renderSolidLine(player, pWorld, minX, maxX, minZ, maxZ, pX, pY, pZ, plotAquaDust);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Renders crisp 3D outer boundary edges for groups of connected blocks in the active layer:
     * - Adjacent blocks of the same status (Ghost Blueprint OR Obstacle) have NO internal edges between them
     * - Outer perimeter boundary edges of each group are highlighted with vivid particles
     */
    private void renderLayerBlockWireframes(Player player, World world, ActiveBuilding bld, 
                                           double pX, double pY, double pZ,
                                           Particle.DustOptions cyanDust, Particle.DustOptions redDust) {
        BuildingSchematic schem = plugin.getSchematicManager().getSchematic(bld.getBlueprintId());
        if (schem == null) return;

        int currentLayer = (bld.getStatus() == ActiveBuilding.Status.CONSTRUCTING) ? bld.getCurrentLayer() : 0;
        int maxLayer = schem.getMaxLayer();
        List<SchematicBlock> layerBlocks = null;

        // Automatically locate the first layer that has uncompleted blocks
        while (currentLayer <= maxLayer) {
            List<SchematicBlock> candidate = schem.getBlocksAtLayer(currentLayer);
            boolean hasUncompleted = false;
            if (candidate != null && !candidate.isEmpty()) {
                for (SchematicBlock sb : candidate) {
                    if (!bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) {
                        int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
                        int wx = bld.getOriginX() + rPos[0];
                        int wy = bld.getOriginY() + sb.getDy();
                        int wz = bld.getOriginZ() + rPos[1];
                        if (wy >= world.getMinHeight() && wy < world.getMaxHeight()) {
                            Material wm = world.getBlockAt(wx, wy, wz).getType();
                            if (!BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
                                hasUncompleted = true;
                                break;
                            } else {
                                bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                            }
                        }
                    }
                }
            }
            if (hasUncompleted) {
                bld.setCurrentLayer(currentLayer);
                layerBlocks = candidate;
                break;
            }
            currentLayer++;
        }

        if (layerBlocks == null || layerBlocks.isEmpty()) return;

        // Classify all uncompleted positions in current layer into GHOST and OBSTACLE sets
        Set<Long> ghostBlocks = new HashSet<>();
        Set<Long> obstacleBlocks = new HashSet<>();

        for (SchematicBlock sb : layerBlocks) {
            if (bld.isBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz())) continue;

            int[] rPos = BuildingManager.rotateRelativeCoords(sb.getDx(), sb.getDz(), bld.getRotationDeg(), schem.getWidthX(), schem.getLengthZ());
            int wx = bld.getOriginX() + rPos[0];
            int wy = bld.getOriginY() + sb.getDy();
            int wz = bld.getOriginZ() + rPos[1];

            // Player distance check (64 blocks radius)
            if (Math.abs(wx - pX) > 64.0 || Math.abs(wz - pZ) > 64.0 || Math.abs(wy - pY) > 64.0) continue;

            Material wm = world.getBlockAt(wx, wy, wz).getType();
            if (BuildingManager.isMaterialMatch(wm, sb.getMaterial())) {
                bld.markBlockCompleted(sb.getDx(), sb.getDy(), sb.getDz());
                continue; // Physically completed in world
            }

            boolean isObstacle = !wm.isAir() && !(wm == Material.WATER || wm == Material.LAVA);
            long posKey = encodePos(wx, wy, wz);
            if (isObstacle) {
                obstacleBlocks.add(posKey);
            } else {
                ghostBlocks.add(posKey);
            }
        }

        // Render outer group boundaries for Ghost Blueprint blocks (Electric Cyan)
        renderGroupBoundaryEdges(player, ghostBlocks, cyanDust);

        // Render outer group boundaries for Obstacle blocks (Vivid Ruby Red)
        renderGroupBoundaryEdges(player, obstacleBlocks, redDust);
    }

    private static long encodePos(int x, int y, int z) {
        return (((long) x & 0x3FFFFFF) << 38) | (((long) y & 0xFFF) << 26) | ((long) z & 0x3FFFFFF);
    }

    private static boolean containsPos(Set<Long> set, int x, int y, int z) {
        return set.contains(encodePos(x, y, z));
    }

    /**
     * Computes and renders all exterior boundary edges of the 3D union of unit blocks in the given group set.
     * Adjacent blocks of the same status share internal edges which are suppressed, creating a clean unified outline.
     */
    private void renderGroupBoundaryEdges(Player player, Set<Long> group, Particle.DustOptions dust) {
        if (group.isEmpty()) return;

        Set<Long> drawnXEdges = new HashSet<>();
        Set<Long> drawnYEdges = new HashSet<>();
        Set<Long> drawnZEdges = new HashSet<>();

        for (long posKey : group) {
            int x = (int) (posKey >> 38);
            if (x >= 0x2000000) x -= 0x4000000;
            int y = (int) ((posKey >> 26) & 0xFFF);
            if (y >= 0x800) y -= 0x1000;
            int z = (int) (posKey & 0x3FFFFFF);
            if (z >= 0x2000000) z -= 0x4000000;

            // 1. Four X-aligned edges around unit cube [x, x+1] x [y, y+1] x [z, z+1]
            for (int dy = 0; dy <= 1; dy++) {
                for (int dz = 0; dz <= 1; dz++) {
                    int ey = y + dy;
                    int ez = z + dz;
                    long edgeKey = encodePos(x, ey, ez);
                    if (drawnXEdges.add(edgeKey)) {
                        boolean A = containsPos(group, x, ey - 1, ez - 1);
                        boolean B = containsPos(group, x, ey - 1, ez);
                        boolean C = containsPos(group, x, ey, ez - 1);
                        boolean D = containsPos(group, x, ey, ez);
                        int k = (A ? 1 : 0) + (B ? 1 : 0) + (C ? 1 : 0) + (D ? 1 : 0);
                        if (k == 1 || k == 3 || (k == 2 && ((A && D) || (B && C)))) {
                            renderSegment(player, x, ey, ez, x + 1.0, ey, ez, dust);
                        }
                    }
                }
            }

            // 2. Four Y-aligned edges
            for (int dx = 0; dx <= 1; dx++) {
                for (int dz = 0; dz <= 1; dz++) {
                    int ex = x + dx;
                    int ez = z + dz;
                    long edgeKey = encodePos(ex, y, ez);
                    if (drawnYEdges.add(edgeKey)) {
                        boolean A = containsPos(group, ex - 1, y, ez - 1);
                        boolean B = containsPos(group, ex - 1, y, ez);
                        boolean C = containsPos(group, ex, y, ez - 1);
                        boolean D = containsPos(group, ex, y, ez);
                        int k = (A ? 1 : 0) + (B ? 1 : 0) + (C ? 1 : 0) + (D ? 1 : 0);
                        if (k == 1 || k == 3 || (k == 2 && ((A && D) || (B && C)))) {
                            renderSegment(player, ex, y, ez, ex, y + 1.0, ez, dust);
                        }
                    }
                }
            }

            // 3. Four Z-aligned edges
            for (int dx = 0; dx <= 1; dx++) {
                for (int dy = 0; dy <= 1; dy++) {
                    int ex = x + dx;
                    int ey = y + dy;
                    long edgeKey = encodePos(ex, ey, z);
                    if (drawnZEdges.add(edgeKey)) {
                        boolean A = containsPos(group, ex - 1, ey - 1, z);
                        boolean B = containsPos(group, ex - 1, ey, z);
                        boolean C = containsPos(group, ex, ey - 1, z);
                        boolean D = containsPos(group, ex, ey, z);
                        int k = (A ? 1 : 0) + (B ? 1 : 0) + (C ? 1 : 0) + (D ? 1 : 0);
                        if (k == 1 || k == 3 || (k == 2 && ((A && D) || (B && C)))) {
                            renderSegment(player, ex, ey, z, ex, ey, z + 1.0, dust);
                        }
                    }
                }
            }
        }
    }

    private void renderSegment(Player player, double x1, double y1, double z1, double x2, double y2, double z2, Particle.DustOptions dust) {
        if (player == null || dustParticle == null) return;
        try {
            boolean supportsDust = (dustParticle.name().equals("DUST") || dustParticle.name().equals("REDSTONE"));
            Object data = supportsDust ? dust : null;
            player.spawnParticle(dustParticle, x1, y1, z1, 1, 0, 0, 0, 0, data);
            player.spawnParticle(dustParticle, (x1 + x2) * 0.5, (y1 + y2) * 0.5, (z1 + z2) * 0.5, 1, 0, 0, 0, 0, data);
            player.spawnParticle(dustParticle, x2, y2, z2, 1, 0, 0, 0, 0, data);
        } catch (Throwable ignored) {}
    }

    /**
     * Renders a smooth, dense, continuous solid perimeter line at terrain ground level
     */
    private void renderSolidLine(Player player, World world, double minX, double maxX, double minZ, double maxZ,
                                 double pX, double pY, double pZ, Particle.DustOptions dust) {
        double maxDist = 64.0;
        if (pX < minX - maxDist || pX > maxX + maxDist || pZ < minZ - maxDist || pZ > maxZ + maxDist) {
            return;
        }

        double startX = Math.max(minX, pX - 32.0);
        double endX = Math.min(maxX, pX + 32.0);
        double startZ = Math.max(minZ, pZ - 32.0);
        double endZ = Math.min(maxZ, pZ + 32.0);

        // North edge (Z = minZ)
        for (double x = startX; x <= endX; x += 0.35) {
            spawnVisibleParticle(player, world, x, minZ, pY, dust);
        }

        // South edge (Z = maxZ)
        for (double x = startX; x <= endX; x += 0.35) {
            spawnVisibleParticle(player, world, x, maxZ, pY, dust);
        }

        // West edge (X = minX)
        for (double z = startZ; z <= endZ; z += 0.35) {
            spawnVisibleParticle(player, world, minX, z, pY, dust);
        }

        // East edge (X = maxX)
        for (double z = startZ; z <= endZ; z += 0.35) {
            spawnVisibleParticle(player, world, maxX, z, pY, dust);
        }
    }

    private double findGroundY(World world, double x, double z, double playerY) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) return -1000;

        int py = (int) Math.floor(playerY);
        int startY = Math.min(py + 6, world.getMaxHeight() - 1);
        int minY = Math.max(py - 10, world.getMinHeight());

        for (int y = startY; y >= minY; y--) {
            org.bukkit.block.Block b = world.getBlockAt(bx, y, bz);
            Material m = b.getType();
            if (m.isSolid() && isTrueTerrainGround(m)) {
                return y + 1.05;
            }
        }
        return playerY + 0.1;
    }

    private boolean isTrueTerrainGround(Material m) {
        if (m == null || m.isAir()) return false;
        String name = m.name();
        if (name.contains("LEAVES") || name.contains("FENCE") || name.contains("GLASS") ||
            name.contains("SCAFFOLD") || name.contains("BANNER") || name.contains("CARPET") ||
            name.contains("CHAIN") || name.contains("LANTERN") || name.contains("TORCH") ||
            name.contains("WALL") || name.contains("STAIR") || name.contains("DOOR") ||
            name.contains("SLAB") || name.contains("FENCE_GATE") || name.contains("SIGN") ||
            name.contains("PRESSURE_PLATE") || name.contains("BUTTON") || name.contains("TRAPDOOR")) {
            return false;
        }
        return true;
    }

    private void spawnVisibleParticle(Player player, World world, double x, double z, double playerY, Particle.DustOptions dust) {
        double gy = findGroundY(world, x, z, playerY);
        if (gy < -500) return;
        player.spawnParticle(dustParticle, x, gy, z, 1, 0, 0, 0, 0, dust);
    }

    public void updateHud() {
        int cycleIntervalSeconds = plugin.getConfig().getInt("settings.hud-material-cycle-interval-seconds", 5);
        if (cycleIntervalSeconds < 1) cycleIntervalSeconds = 5;

        for (Player player : Bukkit.getOnlinePlayers()) {
            ActiveBuilding building = plugin.getBuildingManager().getBuildingAt(player.getLocation());
            if (building != null && !building.isFullyBuilt()) {
                BuildingBlueprint bp = plugin.getBuildingManager().getBlueprint(building.getBlueprintId());
                String bpName = bp != null ? bp.getNameRu() : building.getBlueprintId();
                int percent = building.getProgressPercent();

                // Clean Blue/Cyan BossBar instead of Yellow
                BossBar bar = playerBossBars.computeIfAbsent(player.getUniqueId(), k -> {
                    BossBar b = Bukkit.createBossBar(
                            "",
                            BarColor.BLUE,
                            BarStyle.SEGMENTED_10
                    );
                    b.addPlayer(player);
                    return b;
                });

                bar.setProgress(Math.max(0.0, Math.min(1.0, percent / 100.0)));
                bar.setVisible(true);

                StringBuilder reqStr = new StringBuilder();
                Map<Material, Integer> required = building.getRequiredMaterials();
                
                List<Map.Entry<Material, Integer>> uncompleted = new ArrayList<>();
                List<Map.Entry<Material, Integer>> completed = new ArrayList<>();
                for (Map.Entry<Material, Integer> entry : required.entrySet()) {
                    int placed = building.getPlacedCount(entry.getKey());
                    int need = entry.getValue();
                    if (placed < need) {
                        uncompleted.add(entry);
                    } else {
                        completed.add(entry);
                    }
                }
                
                List<Map.Entry<Material, Integer>> sortedList = new ArrayList<>(uncompleted);
                sortedList.addAll(completed);

                if (!sortedList.isEmpty()) {
                    int currentCycle = playerCycleIndex.getOrDefault(player.getUniqueId(), 0);
                    int ticksHeld = playerTicksHeld.getOrDefault(player.getUniqueId(), 0) + 1;
                    
                    if (ticksHeld >= cycleIntervalSeconds) {
                        ticksHeld = 0;
                        currentCycle = (currentCycle + 1) % sortedList.size();
                        playerCycleIndex.put(player.getUniqueId(), currentCycle);
                    }
                    playerTicksHeld.put(player.getUniqueId(), ticksHeld);
                    
                    int idx1 = currentCycle % sortedList.size();
                    Map.Entry<Material, Integer> e1 = sortedList.get(idx1);
                    int placed1 = building.getPlacedCount(e1.getKey());
                    int need1 = e1.getValue();
                    boolean done1 = placed1 >= need1;
                    
                    reqStr.append(done1 ? "§a✔ " : "§b■ ")
                          .append("§f").append(RussianTranslator.getShortMaterialRu(e1.getKey())).append(": ")
                          .append(done1 ? "§a" : "§b").append(placed1).append("§7/§a").append(need1);
                          
                    if (sortedList.size() > 1) {
                        int idx2 = (idx1 + 1) % sortedList.size();
                        Map.Entry<Material, Integer> e2 = sortedList.get(idx2);
                        int placed2 = building.getPlacedCount(e2.getKey());
                        int need2 = e2.getValue();
                        boolean done2 = placed2 >= need2;
                        
                        reqStr.append(" §8| ")
                              .append(done2 ? "§a✔ " : "§b■ ")
                              .append("§f").append(RussianTranslator.getShortMaterialRu(e2.getKey())).append(": ")
                              .append(done2 ? "§a" : "§b").append(placed2).append("§7/§a").append(need2);
                    }
                }

                // Crisp Aqua & White formatting - Zero Yellow!
                String layerInfo = (building.getStatus() == ActiveBuilding.Status.CONSTRUCTING) ? 
                        ("§bСлой " + (building.getCurrentLayer() + 1) + ChatColor.DARK_GRAY + " | ") : "";
                String prefix = ChatColor.AQUA + "⚡ [" + building.getTownName() + "] " + ChatColor.WHITE + bpName + ChatColor.DARK_GRAY + " | " + layerInfo;
                if (reqStr.length() > 0) {
                    bar.setTitle(prefix + reqStr.toString() + " §8| §a" + percent + "%");
                } else {
                    bar.setTitle(prefix + "§a" + percent + "%");
                }
            } else {
                BossBar bar = playerBossBars.remove(player.getUniqueId());
                if (bar != null) {
                    bar.removePlayer(player);
                    bar.setVisible(false);
                }
                playerTicksHeld.remove(player.getUniqueId());
            }
        }
    }

    public void removePlayer(Player player) {
        BossBar bar = playerBossBars.remove(player.getUniqueId());
        if (bar != null) {
            bar.removePlayer(player);
            bar.setVisible(false);
        }
        playerCycleIndex.remove(player.getUniqueId());
        playerTicksHeld.remove(player.getUniqueId());
        playersParticlesDisabled.remove(player.getUniqueId());
        playersEffectParticlesDisabled.remove(player.getUniqueId());
    }

    public void clearAll() {
        for (BossBar bar : playerBossBars.values()) {
            bar.removeAll();
            bar.setVisible(false);
        }
        playerBossBars.clear();
        playerCycleIndex.clear();
        playerTicksHeld.clear();
        playersParticlesDisabled.clear();
        playersEffectParticlesDisabled.clear();
    }
}
