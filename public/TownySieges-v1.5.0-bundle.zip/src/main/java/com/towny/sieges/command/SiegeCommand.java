package com.towny.sieges.command;

import com.towny.sieges.TownySiegesPlugin;
import com.towny.sieges.model.ChunkCoord;
import com.towny.sieges.model.NationWar;
import com.towny.sieges.model.PreviousChunkStatus;
import com.towny.sieges.model.SiegeCamp;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class SiegeCommand implements CommandExecutor, TabCompleter {

    private final TownySiegesPlugin plugin;

    public SiegeCommand(TownySiegesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "══════ TownySieges v" + plugin.getDescription().getVersion() + " ══════");
            sender.sendMessage(ChatColor.YELLOW + "/siege camp <Город> " + ChatColor.GRAY + "- Поставить осадный лагерь");
            sender.sendMessage(ChatColor.YELLOW + "/siege expand " + ChatColor.GRAY + "- Расширить осадный лагерь на соседний чанк");
            sender.sendMessage(ChatColor.YELLOW + "/siege disband " + ChatColor.RED + "[Мэр] " + ChatColor.GRAY + "- Уничтожить лагерь и вернуть чанки в исходный статус!");
            sender.sendMessage(ChatColor.YELLOW + "/siege banner give [игрок] " + ChatColor.GRAY + "- Выдать Штурмовой Флаг (Захват чанков)");
            sender.sendMessage(ChatColor.YELLOW + "/siege capture status " + ChatColor.GRAY + "- Статус активных почанковых захватов");
            sender.sendMessage(ChatColor.YELLOW + "/siege unclaim " + ChatColor.GRAY + "- Расприватить один чанк лагеря");
            sender.sendMessage(ChatColor.YELLOW + "/siege cannon give [игрок] " + ChatColor.GRAY + "- Выдать осадную мортиру");
            sender.sendMessage(ChatColor.YELLOW + "/siege ammo give <regular|ap> [кол-во] [игрок] " + ChatColor.GRAY + "- Выдать ядра");
            sender.sendMessage(ChatColor.YELLOW + "/siege ammo recipes " + ChatColor.GRAY + "- Рецепты мортир, ядер и штурмового флага");
            sender.sendMessage(ChatColor.YELLOW + "/siege nationwar declare <Нация> " + ChatColor.GRAY + "- Объявить войну нации");
            sender.sendMessage(ChatColor.YELLOW + "/siege nationwar status " + ChatColor.GRAY + "- Статус войн наций и единых таймеров");
            sender.sendMessage(ChatColor.AQUA + "/siege admin skip-prep [город|нация] " + ChatColor.GRAY + "- Пропустить подготовку и начать 2ч штурм");
            sender.sendMessage(ChatColor.AQUA + "/siege admin end [город|нация] " + ChatColor.GRAY + "- Завершить осаду с возвратом всех чанков");
            sender.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════");
            return true;
        }

        // /siege disband / /siege cancel / /siege destroy
        if (args[0].equalsIgnoreCase("disband") || args[0].equalsIgnoreCase("destroy") ||
            args[0].equalsIgnoreCase("cancel") || args[0].equalsIgnoreCase("расформировать") ||
            args[0].equalsIgnoreCase("уничтожить") || args[0].equalsIgnoreCase("stop")) {
            
            if (args.length >= 2 && sender.hasPermission("townysieges.admin")) {
                plugin.getSiegeManager().endSiegeAdmin(args[1], sender);
                return true;
            }
            if (!(sender instanceof Player)) {
                if (args.length >= 2) {
                    plugin.getSiegeManager().endSiegeAdmin(args[1], sender);
                } else {
                    sender.sendMessage(ChatColor.RED + "Использование из консоли: /siege cancel <Город|Нация>");
                }
                return true;
            }
            Player player = (Player) sender;
            plugin.getSiegeManager().disbandCampByMayor(player);
            return true;
        }

        // /siege skip-prep / /siege skip / /siege assault
        if (args[0].equalsIgnoreCase("skip-prep") || args[0].equalsIgnoreCase("skipprep") ||
            args[0].equalsIgnoreCase("skip") || args[0].equalsIgnoreCase("fastforward")) {
            if (!sender.hasPermission("townysieges.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав администратора!");
                return true;
            }
            String target = args.length >= 2 ? args[1] : null;
            plugin.getSiegeManager().skipPreparation(target, sender);
            return true;
        }

        // /siege admin ... (Единые команды админского управления)
        if (args[0].equalsIgnoreCase("admin")) {
            if (!sender.hasPermission("townysieges.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав администратора!");
                return true;
            }

            if (args.length < 2 || args[1].equalsIgnoreCase("help")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Команды Администратора Осад ══════");
                sender.sendMessage(ChatColor.AQUA + "/siege admin skip-prep [город|нация] " + ChatColor.GRAY + "- Пропустить 24ч подготовку и мгновенно начать 2ч штурм");
                sender.sendMessage(ChatColor.AQUA + "/siege admin end [город|нация] " + ChatColor.GRAY + "- Завершить осаду и восстановить чанки");
                sender.sendMessage(ChatColor.AQUA + "/siege admin status " + ChatColor.GRAY + "- Подробный статус всех осад и исходных чанков");
                sender.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════");
                return true;
            }

            String sub = args[1].toLowerCase();

            // Пропустить подготовку к штурму: /siege admin skip-prep [город|нация]
            if (sub.equals("skip-prep") || sub.equals("skipprep") || sub.equals("skip") ||
                sub.equals("assault") || sub.equals("fastforward") || sub.equals("штурм")) {
                String target = args.length >= 3 ? args[2] : null;
                plugin.getSiegeManager().skipPreparation(target, sender);
                return true;
            }

            // Завершить осаду: /siege admin end [город|нация]
            if (sub.equals("end") || sub.equals("stop") || sub.equals("cancel") || sub.equals("стоп")) {
                String target = args.length >= 3 ? args[2] : null;
                plugin.getSiegeManager().endSiegeAdmin(target, sender);
                return true;
            }

            // Статус осад и исходных статусов чанков
            if (sub.equals("status") || sub.equals("list") || sub.equals("инфо")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Подробный Статус Осад и Чанков ══════");
                Collection<SiegeCamp> sieges = plugin.getSiegeManager().getAllSieges();
                if (sieges.isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "Активных осад нет.");
                } else {
                    for (SiegeCamp c : sieges) {
                        sender.sendMessage(ChatColor.YELLOW + "• " + c.getAttackingTown() + " ➔ " + c.getDefendingTown() +
                                " [" + c.getStatus() + "] Чанков: " + c.getClaimedChunks().size());
                        for (ChunkCoord coord : c.getClaimedChunks()) {
                            PreviousChunkStatus prev = c.getInitialStatus(coord);
                            sender.sendMessage(ChatColor.GRAY + "   - Чанк [" + coord.getX() + ", " + coord.getZ() + "] ➔ Исходно: " +
                                    ChatColor.AQUA + prev.getTitleRu());
                        }
                    }
                }
                sender.sendMessage(ChatColor.GOLD + "═══════════════════════════════════════════");
                return true;
            }

            sender.sendMessage(ChatColor.RED + "Неизвестная подкоманда admin. Введите /siege admin help");
            return true;
        }

        // /siege cannon [give] [player]
        if (args[0].equalsIgnoreCase("cannon") || args[0].equalsIgnoreCase("pushka") ||
            args[0].equalsIgnoreCase("getcannon") || args[0].equalsIgnoreCase("mortar")) {
            if (!sender.hasPermission("townysieges.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав администратора для выдачи осадных орудий!");
                return true;
            }
            Player target = sender instanceof Player ? (Player) sender : null;
            if (args.length >= 2 && !args[1].equalsIgnoreCase("give")) {
                target = Bukkit.getPlayer(args[1]);
            } else if (args.length >= 3) {
                target = Bukkit.getPlayer(args[2]);
            }
            if (target == null || !target.isOnline()) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] Игрок не найден или не в сети!");
                return true;
            }
            target.getInventory().addItem(plugin.getCannonManager().getCannonItem());
            target.sendMessage(ChatColor.GREEN + "[TownySieges] Вам выдана кастомная осадная мортира (Nexo/Oraxen Model)!");
            target.sendMessage(ChatColor.YELLOW + "Разместите орудие на землю правой кнопкой мыши. Нажмите ПКМ по мортире, чтобы сесть наводчиком.");
            if (sender != target) {
                sender.sendMessage(ChatColor.GREEN + "[TownySieges] Мортира успешно выдана игроку " + target.getName() + ".");
            }
            return true;
        }

        // /siege ammo [recipes/give] ...
        if (args[0].equalsIgnoreCase("ammo") || args[0].equalsIgnoreCase("yadra") || args[0].equalsIgnoreCase("снаряды")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("recipes")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Рецепты Осадного Вооружения (TownySieges) ══════");
                sender.sendMessage(ChatColor.YELLOW + "1. Осадная Мортира (Верстак 3x3):");
                sender.sendMessage(ChatColor.WHITE + "   [Блок железа] [Раздатчик]   [Блок железа]");
                sender.sendMessage(ChatColor.WHITE + "   [Гладкий камень] [Котёл]    [Гладкий камень]");
                sender.sendMessage(ChatColor.WHITE + "   [Бревно дуба] [Бревно дуба] [Бревно дуба]");
                sender.sendMessage("");
                sender.sendMessage(ChatColor.YELLOW + "2. ⚪ Обычное Осадное Ядро:");
                sender.sendMessage(ChatColor.WHITE + "   [Железо] [Железо]  [Железо]");
                sender.sendMessage(ChatColor.WHITE + "   [Железо] [Порох]   [Железо]");
                sender.sendMessage(ChatColor.WHITE + "   [Уголь]  [Порох]   [Уголь]");
                sender.sendMessage("");
                sender.sendMessage(ChatColor.LIGHT_PURPLE + "3. 🟣 Бронебойное Ядро (Пробитие Обсидиана):");
                sender.sendMessage(ChatColor.WHITE + "   [Алмаз]    [Обсидиан] [Алмаз]");
                sender.sendMessage(ChatColor.WHITE + "   [Незерит]  [ТНТ]      [Обсидиан]");
                sender.sendMessage(ChatColor.WHITE + "   [Алмаз]    [Порох]    [Алмаз]");
                sender.sendMessage("");
                sender.sendMessage(ChatColor.RED + "4. ⚔ Штурмовой Флаг Осады (Почанковый Захват):");
                sender.sendMessage(ChatColor.WHITE + "   [Золото]    [ТНТ]             [Золото]");
                sender.sendMessage(ChatColor.WHITE + "   [Золото]    [Красный Флаг]    [Золото]");
                sender.sendMessage(ChatColor.WHITE + "   [Воздух]    [Стержень Блейза] [Воздух]");
                sender.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════════════════════");
                return true;
            }

            if (args.length >= 2 && args[1].equalsIgnoreCase("give")) {
                if (!sender.hasPermission("townysieges.admin")) {
                    sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав для выдачи боеприпасов!");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /siege ammo give <regular|ap> [кол-во] [игрок]");
                    return true;
                }
                String typeStr = args[2].toLowerCase();
                int count = 1;
                if (args.length >= 4) {
                    try {
                        count = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
                    } catch (NumberFormatException ignored) {}
                }
                Player target = sender instanceof Player ? (Player) sender : null;
                if (args.length >= 5) {
                    target = Bukkit.getPlayer(args[4]);
                }
                if (target == null || !target.isOnline()) {
                    sender.sendMessage(ChatColor.RED + "[TownySieges] Игрок не найден!");
                    return true;
                }

                boolean isAp = typeStr.equalsIgnoreCase("ap") || typeStr.equalsIgnoreCase("armor") || typeStr.equalsIgnoreCase("бронебойный");
                for (int i = 0; i < count; i++) {
                    target.getInventory().addItem(plugin.getCannonManager().createAmmoItem(isAp));
                }
                String typeName = isAp ? ChatColor.LIGHT_PURPLE + "🟣 Бронебойные (Обсидиановые)" : ChatColor.WHITE + "⚪ Обычные фугасные";
                target.sendMessage(ChatColor.GREEN + "[TownySieges] Вам выданы осадные ядра (" + count + " шт.): " + typeName);
                if (sender != target) {
                    sender.sendMessage(ChatColor.GREEN + "[TownySieges] Выдано " + count + " ядер игроку " + target.getName() + ".");
                }
                return true;
            }

            sender.sendMessage(ChatColor.YELLOW + "Использование: /siege ammo <recipes|give <regular|ap> [кол-во] [игрок]>");
            return true;
        }

        // /siege banner [give] [player]
        if (args[0].equalsIgnoreCase("banner") || args[0].equalsIgnoreCase("flag") || args[0].equalsIgnoreCase("флаг")) {
            if (!sender.hasPermission("townysieges.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав для выдачи штурмовых флагов!");
                return true;
            }
            Player target = sender instanceof Player ? (Player) sender : null;
            if (args.length >= 2 && !args[1].equalsIgnoreCase("give")) {
                target = Bukkit.getPlayer(args[1]);
            } else if (args.length >= 3) {
                target = Bukkit.getPlayer(args[2]);
            }
            if (target == null || !target.isOnline()) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] Игрок не найден или не в сети!");
                return true;
            }
            target.getInventory().addItem(plugin.getCaptureManager().getAssaultBannerItem());
            target.sendMessage(ChatColor.GREEN + "[TownySieges] Вам выдан кастомный ⚔ Штурмовой Флаг Осады (Assault Banner)!");
            target.sendMessage(ChatColor.YELLOW + "Установите его на чанк, граничащий с вашим осадным лагерем, во время активного штурма!");
            if (sender != target) {
                sender.sendMessage(ChatColor.GREEN + "[TownySieges] Штурмовой флаг выдан игроку " + target.getName() + ".");
            }
            return true;
        }

        // /siege capture status
        if (args[0].equalsIgnoreCase("capture") || args[0].equalsIgnoreCase("захват")) {
            sender.sendMessage(ChatColor.GOLD + "══════ Активные Штурмовые Захваты Чанков ══════");
            if (plugin.getCaptureManager().getActiveCaptures().isEmpty()) {
                sender.sendMessage(ChatColor.GRAY + "В данный момент нет активных штурмовых флагов.");
            } else {
                for (com.towny.sieges.model.SiegeBannerCapture cap : plugin.getCaptureManager().getActiveCaptures()) {
                    ChunkCoord c = cap.getChunk();
                    sender.sendMessage(ChatColor.YELLOW + "• Чанк [" + c.getX() + ", " + c.getZ() + "] " +
                            ChatColor.WHITE + cap.getAttackingTown() + " ➔ " + cap.getDefendingTown() +
                            ChatColor.GRAY + " | Прогресс: " + ChatColor.AQUA + cap.getFormattedProgress() +
                            ChatColor.GRAY + " | Атак.: " + ChatColor.RED + cap.getCurrentAttackers() +
                            ChatColor.GRAY + " vs Защит.: " + ChatColor.BLUE + cap.getCurrentDefenders());
                }
            }
            sender.sendMessage(ChatColor.GOLD + "════════════════════════════════════════════════");
            return true;
        }

        // /siege switch
        if (args[0].equalsIgnoreCase("switch") || args[0].equalsIgnoreCase("toggle")) {
            if (sender instanceof Player) {
                Player p = (Player) sender;
                if (plugin.getCannonManager().isMounted(p)) {
                    plugin.getCannonManager().cycleAmmo(p);
                    return true;
                }
            }
            sender.sendMessage(ChatColor.GOLD + "[TownySieges] Смена боеприпасов: нажмите клавишу смены руки [F] сидя за орудием!");
            return true;
        }

        // /siege camp <DefendingTown>
        if (args[0].equalsIgnoreCase("camp") || args[0].equalsIgnoreCase("lager")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("disband")) {
                if (sender instanceof Player) {
                    plugin.getSiegeManager().disbandCampByMayor((Player) sender);
                }
                return true;
            }
            if (!(sender instanceof Player)) {
                sender.sendMessage("Только игрок может ставить осадный лагерь!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length < 2) {
                player.sendMessage(ChatColor.RED + "Использование: /siege camp <Город-цель>");
                return true;
            }
            String defendingTown = args[1];
            plugin.getSiegeManager().createSiegeCamp(player, defendingTown, player.getLocation());
            return true;
        }

        // /siege expand
        if (args[0].equalsIgnoreCase("expand") || args[0].equalsIgnoreCase("rasshirit")) {
            if (!(sender instanceof Player)) return true;
            Player player = (Player) sender;
            plugin.getSiegeManager().expandSiegeCamp(player, player.getLocation());
            return true;
        }

        // /siege unclaim
        if (args[0].equalsIgnoreCase("unclaim") || args[0].equalsIgnoreCase("udalit")) {
            if (!(sender instanceof Player)) return true;
            Player player = (Player) sender;
            plugin.getSiegeManager().unclaimSiegeChunk(player, player.getLocation());
            return true;
        }

        // /siege nationwar
        if (args[0].equalsIgnoreCase("nationwar") || args[0].equalsIgnoreCase("war") || args[0].equalsIgnoreCase("война")) {
            if (args.length < 2 || args[1].equalsIgnoreCase("status")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Активные Войны Наций ══════");
                if (plugin.getSiegeManager().getAllNationWars().isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "В данный момент нет активных войн наций.");
                } else {
                    for (NationWar nw : plugin.getSiegeManager().getAllNationWars()) {
                        sender.sendMessage(ChatColor.YELLOW + "• " + nw.getAttackerNation() + " ➔ " + nw.getDefenderNation() +
                                " [" + nw.getStatus() + "] Осталось: " + nw.getFormattedRemainingTime());
                    }
                }
                sender.sendMessage(ChatColor.GOLD + "══════════════════════════════════");
                return true;
            }

            if (args[1].equalsIgnoreCase("declare")) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Только глава нации может объявить войну.");
                    return true;
                }
                Player player = (Player) sender;
                if (args.length < 3) {
                    player.sendMessage(ChatColor.RED + "Использование: /siege nationwar declare <Нация-Цель>");
                    return true;
                }
                String targetNat = args[2];
                plugin.getSiegeManager().declareNationWar(player, targetNat);
                return true;
            }
        }

        sender.sendMessage(ChatColor.RED + "Неизвестная команда. Введите /siege help");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = Arrays.asList("camp", "expand", "disband", "cancel", "skip-prep", "unclaim", "banner", "capture", "cannon", "ammo", "switch", "nationwar", "admin", "help");
            String input = args[0].toLowerCase();
            for (String s : subs) {
                if (s.startsWith(input)) completions.add(s);
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("admin")) {
                List<String> subs = Arrays.asList("skip-prep", "end", "status");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("nationwar") || args[0].equalsIgnoreCase("war")) {
                List<String> subs = Arrays.asList("declare", "status");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("cannon")) {
                List<String> subs = Arrays.asList("give");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("ammo")) {
                List<String> subs = Arrays.asList("recipes", "switch", "give");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("banner") || args[0].equalsIgnoreCase("flag")) {
                List<String> subs = Arrays.asList("give", "recipes");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("camp")) {
                List<String> subs = Arrays.asList("disband");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("ammo") && args[1].equalsIgnoreCase("give")) {
                List<String> subs = Arrays.asList("regular", "ap");
                String input = args[2].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            }
        }
        return completions;
    }
}
