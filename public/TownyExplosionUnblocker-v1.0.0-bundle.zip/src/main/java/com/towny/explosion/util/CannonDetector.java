package com.towny.explosion.util;

import com.towny.explosion.TownyExplosionUnblockerPlugin;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class CannonDetector {

    private final TownyExplosionUnblockerPlugin plugin;
    private final Set<UUID> trackedCannonTnts = ConcurrentHashMap.newKeySet();

    public CannonDetector(TownyExplosionUnblockerPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers a TNT entity at spawn time if it has cannon-like trajectory or custom properties.
     */
    public void trackSpawnedEntity(Entity entity) {
        if (!(entity instanceof TNTPrimed)) return;
        TNTPrimed tnt = (TNTPrimed) entity;
        Vector vel = tnt.getVelocity();
        double horizontalSpeed = (vel != null) ? Math.hypot(vel.getX(), vel.getZ()) : 0.0;

        if (horizontalSpeed > 0.08 || isCustomProjectileTraits(tnt)) {
            trackedCannonTnts.add(tnt.getUniqueId());
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[DEBUG-SPAWN] Tracked cannon projectile UUID=" + tnt.getUniqueId() + 
                        " (speed=" + String.format("%.2f", horizontalSpeed) + ", name=" + tnt.getCustomName() + ")");
            }
        }
    }

    /**
     * Cleans up tracked TNT UUID after detonation.
     */
    public void untrack(UUID uuid) {
        trackedCannonTnts.remove(uuid);
    }

    /**
     * Determines whether an exploding entity is a non-vanilla cannon projectile / custom ammo.
     * Uses Blacklist approach:
     * - Vanilla creepers, crystals, withers, beds, and hand-placed zero-velocity player TNTs are BLOCKED (returns false).
     * - Any non-vanilla projectile (cannon shots, siege artillery, custom PDC/tags/names/velocity) is UNBLOCKED (returns true).
     */
    public boolean isCannonProjectile(Entity entity) {
        if (entity == null) {
            // Null entity = Bed in Nether/End, Respawn Anchor, or custom block explosion
            // Keep blocked by Towny as vanilla bed/anchor exploit!
            return false;
        }

        EntityType type = entity.getType();

        // 1. Strict Vanilla Blacklist: These entities are ALWAYS blocked in towns
        if (isBlacklistedVanillaEntity(type)) {
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[DEBUG] Blocked explosion: vanilla entity type " + type.name());
            }
            return false;
        }

        // Only TNT-like primed entities can be cannon projectiles
        if (!(entity instanceof TNTPrimed)) {
            // If it's another non-vanilla entity, check custom traits
            return isCustomProjectileTraits(entity);
        }

        TNTPrimed tnt = (TNTPrimed) entity;
        UUID uuid = tnt.getUniqueId();

        // 2. Check if tracked at spawn time as cannon projectile
        if (trackedCannonTnts.contains(uuid)) {
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[DEBUG] Allowed explosion: matched tracked cannon TNT UUID=" + uuid);
            }
            return true;
        }

        // 3. Check Custom Traits (PDC, Metadata, Tags, CustomName)
        if (isCustomProjectileTraits(tnt)) {
            return true;
        }

        // 4. Check Velocity / Trajectory (Cannon-fired TNT has horizontal velocity)
        Vector vel = tnt.getVelocity();
        if (vel != null) {
            double hSpeed = Math.hypot(vel.getX(), vel.getZ());
            double minSpeed = plugin.getConfig().getDouble("detection.min-cannon-launch-speed", 0.08);
            if (hSpeed >= minSpeed) {
                if (plugin.isDebugEnabled()) {
                    plugin.getLogger().info("[DEBUG] Allowed explosion: cannon velocity detected (hSpeed=" + String.format("%.2f", hSpeed) + ")");
                }
                return true;
            }
        }

        // 5. In 'blacklist' mode:
        // If it lacks ALL custom traits, lacks velocity, and has standard vanilla fuse -> it's vanilla player TNT.
        String mode = plugin.getConfig().getString("detection.mode", "blacklist");
        if ("blacklist".equalsIgnoreCase(mode)) {
            // Vanilla player TNT: no tags, no PDC, no custom name, zero horizontal speed
            return false;
        }

        return false;
    }

    /**
     * Checks if the entity has ANY non-vanilla markers.
     */
    public boolean isCustomProjectileTraits(Entity entity) {
        if (entity == null) return false;

        // A. Check Custom Name (e.g. "⚡ Осадный TNT", "Cannonball", "Пушечный снаряд")
        if (entity.getCustomName() != null && !entity.getCustomName().isEmpty()) {
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[DEBUG] Detected custom name: " + entity.getCustomName());
            }
            return true;
        }

        // B. Check Scoreboard Tags
        Set<String> tags = entity.getScoreboardTags();
        if (tags != null && !tags.isEmpty()) {
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[DEBUG] Detected scoreboard tags: " + tags);
            }
            return true;
        }

        // C. Check PersistentDataContainer (PDC)
        try {
            PersistentDataContainer pdc = entity.getPersistentDataContainer();
            Set<NamespacedKey> pdcKeys = pdc.getKeys();
            if (pdcKeys != null && !pdcKeys.isEmpty()) {
                if (plugin.isDebugEnabled()) {
                    plugin.getLogger().info("[DEBUG] Detected PDC keys count=" + pdcKeys.size());
                }
                return true;
            }
        } catch (Throwable ignored) {}

        // D. Check Custom Metadata
        try {
            List<String> metaKeys = plugin.getConfig().getStringList("detection.metadata-keys");
            for (String key : metaKeys) {
                if (entity.hasMetadata(key)) {
                    if (plugin.isDebugEnabled()) {
                        plugin.getLogger().info("[DEBUG] Detected metadata key: " + key);
                    }
                    return true;
                }
            }
        } catch (Throwable ignored) {}

        return false;
    }

    /**
     * Vanilla explosion entities that should ALWAYS remain blocked by Towny inside towns.
     */
    private boolean isBlacklistedVanillaEntity(EntityType type) {
        if (type == null) return true;
        String name = type.name();
        return name.equals("CREEPER") ||
               name.equals("ENDER_CRYSTAL") ||
               name.equals("END_CRYSTAL") ||
               name.equals("WITHER") ||
               name.equals("WITHER_SKULL") ||
               name.equals("FIREBALL") ||
               name.equals("SMALL_FIREBALL") ||
               name.equals("DRAGON_FIREBALL") ||
               name.equals("WIND_CHARGE") ||
               name.equals("BREEZE_WIND_CHARGE");
    }
}
