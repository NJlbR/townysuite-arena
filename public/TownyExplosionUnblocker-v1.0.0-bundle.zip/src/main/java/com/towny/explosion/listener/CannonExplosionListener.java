package com.towny.explosion.listener;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.towny.explosion.TownyExplosionUnblockerPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class CannonExplosionListener implements Listener {

    private final TownyExplosionUnblockerPlugin plugin;
    private final Map<UUID, List<Block>> capturedBlastBlocks = new ConcurrentHashMap<>();
    private final Map<UUID, Float> capturedYield = new ConcurrentHashMap<>();

    public CannonExplosionListener(TownyExplosionUnblockerPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Track newly spawned TNT entities to register cannon trajectories.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntitySpawn(EntitySpawnEvent event) {
        if (!plugin.isUnblockerEnabled()) return;
        Entity entity = event.getEntity();
        if (entity instanceof TNTPrimed) {
            plugin.getCannonDetector().trackSpawnedEntity(entity);
        }
    }

    /**
     * Phase 1 (LOWEST Priority):
     * Runs BEFORE Towny or other protection plugins can cancel or clear the blockList.
     * Captures the full vanilla explosion blast blocks for cannon projectiles.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onExplosionEarly(EntityExplodeEvent event) {
        if (!plugin.isUnblockerEnabled()) return;

        Entity entity = event.getEntity();
        if (entity == null || !plugin.getCannonDetector().isCannonProjectile(entity)) {
            return; // Vanilla TNT / Creeper / Crystal / Wither -> ignore, let Towny protect!
        }

        UUID entityId = entity.getUniqueId();
        if (event.blockList() != null && !event.blockList().isEmpty()) {
            capturedBlastBlocks.put(entityId, new ArrayList<>(event.blockList()));
            capturedYield.put(entityId, event.getYield());
        }

        if (plugin.isDebugEnabled()) {
            plugin.getLogger().info("[LOWEST] Captured " + (event.blockList() != null ? event.blockList().size() : 0) + 
                    " blast blocks for cannon entity " + entityId);
        }
    }

    /**
     * Phase 2 (HIGHEST Priority):
     * Runs AFTER Towny. Overrides Towny cancellation and restores all removed/filtered blocks.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onExplosionLate(EntityExplodeEvent event) {
        if (!plugin.isUnblockerEnabled()) return;

        Entity entity = event.getEntity();
        if (entity == null || !plugin.getCannonDetector().isCannonProjectile(entity)) {
            return; // Vanilla TNT / Creeper / Crystal -> do nothing!
        }

        UUID entityId = entity.getUniqueId();
        List<Block> savedBlocks = capturedBlastBlocks.remove(entityId);
        Float savedYield = capturedYield.remove(entityId);
        plugin.getCannonDetector().untrack(entityId);

        Location loc = event.getLocation();
        boolean inTown = isLocationInTown(loc);

        if (plugin.isDebugEnabled()) {
            plugin.getLogger().info("[HIGHEST] Cannon explosion at " + loc + " (inTown=" + inTown + ", wasCancelled=" + event.isCancelled() + 
                    ", currentBlocks=" + event.blockList().size() + ", savedBlocks=" + (savedBlocks != null ? savedBlocks.size() : 0) + ")");
        }

        // 1. Force UN-CANCEL the explosion for siege cannon projectiles!
        if (event.isCancelled()) {
            event.setCancelled(false);
            if (plugin.isDebugEnabled()) {
                plugin.getLogger().info("[HIGHEST] Successfully UN-CANCELLED cannon explosion in Towny territory!");
            }
        }

        // 2. RESTORE AND MERGE ALL BLOCKS THAT TOWNY FILTERED OUT
        // We do NOT only check isEmpty() — Towny could have kept 1 wild block and filtered 50 city blocks.
        // We ensure every single blast block from the full explosion is present!
        final List<Block> targetBlocksToBreak = new ArrayList<>();

        if (savedBlocks != null && !savedBlocks.isEmpty()) {
            for (Block b : savedBlocks) {
                if (!event.blockList().contains(b)) {
                    event.blockList().add(b);
                }
                targetBlocksToBreak.add(b);
            }
        }

        // If savedBlocks was empty or incomplete, compute realistic vanilla blast raycast
        if (event.blockList().isEmpty() || event.blockList().size() < 4) {
            float power = (float) plugin.getConfig().getDouble("explosion.default-cannon-power", 4.0);
            List<Block> calculated = computeRealisticBlast(loc, power);
            for (Block b : calculated) {
                if (!event.blockList().contains(b)) {
                    event.blockList().add(b);
                }
                if (!targetBlocksToBreak.contains(b)) {
                    targetBlocksToBreak.add(b);
                }
            }
        }

        // 3. Restore Full Yield
        float configuredYield = (float) plugin.getConfig().getDouble("explosion.yield", 1.0);
        event.setYield(savedYield != null && savedYield > 0f ? savedYield : configuredYield);

        // 4. Guaranteed Post-Explosion Physical Destruction
        // If Towny or another plugin attempts to rollback blocks on MONITOR,
        // we schedule an immediate 0-tick fallback to guarantee equal destruction strength in town!
        if (plugin.getConfig().getBoolean("explosion.guaranteed-destruction", true) && !targetBlocksToBreak.isEmpty()) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (Block b : targetBlocksToBreak) {
                    if (b != null && !b.getType().isAir() && !isIndestructible(b.getType())) {
                        b.breakNaturally();
                    }
                }
            });
        }

        // 5. Notify town residents if configured
        if (inTown && plugin.getConfig().getBoolean("explosion.notify-town-residents", true)) {
            alertTownResidents(loc);
        }
    }

    /**
     * Realistic Vanilla Minecraft Explosion Raycasting Algorithm.
     * Computes the exact 3D crater based on block blast resistance and ray attenuation.
     */
    private List<Block> computeRealisticBlast(Location center, float power) {
        Set<Block> blocks = new HashSet<>();
        World world = center.getWorld();
        if (world == null || power <= 0.1f) return new ArrayList<>(blocks);

        int rays = 16;
        for (int i = 0; i < rays; i++) {
            for (int j = 0; j < rays; j++) {
                for (int k = 0; k < rays; k++) {
                    if (i == 0 || i == rays - 1 || j == 0 || j == rays - 1 || k == 0 || k == rays - 1) {
                        double dX = (double) i / (rays - 1) * 2.0 - 1.0;
                        double dY = (double) j / (rays - 1) * 2.0 - 1.0;
                        double dZ = (double) k / (rays - 1) * 2.0 - 1.0;
                        double distance = Math.sqrt(dX * dX + dY * dY + dZ * dZ);
                        dX /= distance;
                        dY /= distance;
                        dZ /= distance;

                        float rayPower = power * (0.7f + ThreadLocalRandom.current().nextFloat() * 0.6f);
                        double curX = center.getX();
                        double curY = center.getY();
                        double curZ = center.getZ();

                        while (rayPower > 0.0f) {
                            int bX = (int) Math.floor(curX);
                            int bY = (int) Math.floor(curY);
                            int bZ = (int) Math.floor(curZ);

                            Block b = world.getBlockAt(bX, bY, bZ);
                            Material mat = b.getType();

                            if (!mat.isAir() && !isIndestructible(mat)) {
                                float resistance = getBlockBlastResistance(mat);
                                rayPower -= (resistance / 5.0f + 0.3f) * 0.3f;
                                if (rayPower > 0.0f) {
                                    blocks.add(b);
                                }
                            } else {
                                rayPower -= 0.3f * 0.75f;
                            }

                            curX += dX * 0.3;
                            curY += dY * 0.3;
                            curZ += dZ * 0.3;
                        }
                    }
                }
            }
        }
        return new ArrayList<>(blocks);
    }

    private boolean isIndestructible(Material mat) {
        return mat == Material.BEDROCK ||
               mat == Material.BARRIER ||
               mat == Material.END_PORTAL ||
               mat == Material.END_PORTAL_FRAME ||
               mat == Material.NETHER_PORTAL ||
               mat == Material.STRUCTURE_BLOCK;
    }

    private float getBlockBlastResistance(Material mat) {
        if (mat == null) return 0f;
        String name = mat.name();
        if (name.contains("OBSIDIAN") || name.contains("ANVIL") || name.contains("RESPAWN_ANCHOR") || name.contains("NETHERITE_BLOCK")) {
            return 1200.0f;
        }
        if (name.contains("STONE") || name.contains("BRICK") || name.contains("COBBLE") || name.contains("PRISMARINE") || name.contains("IRON_BLOCK")) {
            return 6.0f;
        }
        if (name.contains("WOOD") || name.contains("LOG") || name.contains("PLANK") || name.contains("FENCE") || name.contains("SLAB")) {
            return 2.0f;
        }
        if (name.contains("DIRT") || name.contains("SAND") || name.contains("GRAVEL") || name.contains("GRASS")) {
            return 0.5f;
        }
        if (name.contains("GLASS") || name.contains("LEAVES") || name.contains("WOOL") || name.contains("CARPET")) {
            return 0.2f;
        }
        return 1.5f;
    }

    private boolean isLocationInTown(Location loc) {
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            return tb != null && tb.hasTown();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void alertTownResidents(Location loc) {
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            if (tb == null || !tb.hasTown()) return;

            Town town = tb.getTown();
            if (town == null) return;

            String alertMsg = ChatColor.translateAlternateColorCodes('&', 
                    plugin.getConfig().getString("explosion.resident-alert-message", "&c[!] &6Осадное орудие пробило укрепления на территории города!"));

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (town.hasResident(p.getName())) {
                    p.sendMessage(alertMsg);
                }
            }
        } catch (Throwable ignored) {}
    }
}
