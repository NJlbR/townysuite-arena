package com.towny.sieges.command;

import com.towny.sieges.TownySiegesPlugin;
import com.towny.sieges.model.ChunkCoord;
import com.towny.sieges.model.NationWar;
import com.towny.sieges.model.SiegeCamp;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class SiegeCommand implements CommandExecutor, TabCompleter {

    private final TownySiegesPlugin plugin;

    public SiegeCommand(TownySiegesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmdName = command.getName().toLowerCase();
        
        // 1. Handle TOP-LEVEL commands from plugin.yml
        if (cmdName.equals("disband") || cmdName.equals("cancel") || cmdName.equals("destroy") || cmdName.equals("stop")) {
            return handleDisband(sender, args);
        }
        
        if (cmdName.equals("skip-prep") || cmdName.equals("skip") || cmdName.equals("assault")) {
            return handleSkipPrep(sender, args);
        }

        // 2. Handle /siege <subcommand>
        if (cmdName.equals("siege") || cmdName.equals("sieges") || cmdName.equals("townysieges") || cmdName.equals("osada")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                sendHelp(sender);
                return true;
            }

            String sub = args[0].toLowerCase();
            String[] subArgs = args.length > 1 ? Arrays.copyOfRange(args, 1, args.length) : new String[0];

            switch (sub) {
                case "disband":
                case "cancel":
                case "destroy":
                case "stop":
                case "расформировать":
                case "уничтожить":
                    return handleDisband(sender, subArgs);
                case "skip-prep":
                case "skipprep":
                case "skip":
                case "fastforward":
                case "штурм":
                    return handleSkipPrep(sender, subArgs);
                case "admin":
                    return handleAdmin(sender, subArgs);
                case "camp":
                case "lager":
                    return handleCamp(sender, subArgs);
                case "expand":
                case "rasshirit":
                    return handleExpand(sender, subArgs);
                case "unclaim":
                case "udalit":
                    return handleUnclaim(sender, subArgs);
                case "banner":
                case "flag":
                case "флаг":
                    return handleBanner(sender, subArgs);
                case "capture":
                case "захват":
                    return handleCaptureStatus(sender);
                case "cannon":
                case "pushka":
                case "mortar":
                    return handleCannon(sender, subArgs);
                case "ammo":
                case "yadra":
                    return handleAmmo(sender, subArgs);
                case "nationwar":
                case "war":
                case "война":
                    return handleNationWar(sender, subArgs);
                case "switch":
                case "toggle":
                    return handleSwitch(sender);
                default:
                    sender.sendMessage(ChatColor.RED + "Неизвестная команда. Введите /siege help");
                    return true;
            }
        }
        return true;
    }

    private boolean handleDisband(CommandSender sender, String[] args) {
        if (args.length >= 1 && sender.hasPermission("townysieges.admin")) {
            plugin.getSiegeManager().endSiegeAdmin(args[0], sender);
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Использование: /disband <Город|Нация>");
            return true;
        }
        plugin.getSiegeManager().disbandCampByMayor((Player) sender);
        return true;
    }

    private boolean handleSkipPrep(CommandSender sender, String[] args) {
        if (!sender.hasPermission("townysieges.admin")) {
            sender.sendMessage(ChatColor.RED + "Нет прав!");
            return true;
        }
        String target = args.length >= 1 ? args[0] : null;
        plugin.getSiegeManager().skipPreparation(target, sender);
        return true;
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("townysieges.admin")) {
            sender.sendMessage(ChatColor.RED + "Нет прав!");
            return true;
        }
        if (args.length < 1 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "══════ Админ-команды ══════");
            sender.sendMessage(ChatColor.AQUA + "/siege admin skip-prep [цель]");
            sender.sendMessage(ChatColor.AQUA + "/siege admin end [цель]");
            sender.sendMessage(ChatColor.AQUA + "/siege admin status");
            return true;
        }
        String sub = args[0].toLowerCase();
        String target = args.length >= 2 ? args[1] : null;

        if (sub.equals("skip-prep") || sub.equals("skip")) {
            plugin.getSiegeManager().skipPreparation(target, sender);
        } else if (sub.equals("end") || sub.equals("stop")) {
            plugin.getSiegeManager().endSiegeAdmin(target, sender);
        } else if (sub.equals("status")) {
            sendAdminStatus(sender);
        }
        return true;
    }

    private void sendAdminStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "══════ Статус Осад ══════");
        Collection<SiegeCamp> sieges = plugin.getSiegeManager().getAllSieges();
        if (sieges.isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Нет активных осад.");
        } else {
            for (SiegeCamp c : sieges) {
                sender.sendMessage(ChatColor.YELLOW + "• " + c.getAttackingTown() + " ➔ " + c.getDefendingTown() + " [" + c.getStatus() + "]");
            }
        }
    }

    private boolean handleCamp(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) return true;
        if (args.length < 1) {
            sender.sendMessage(ChatColor.RED + "/siege camp <Город>");
            return true;
        }
        plugin.getSiegeManager().createSiegeCamp((Player) sender, args[0], ((Player) sender).getLocation());
        return true;
    }

    private boolean handleExpand(CommandSender sender, String[] args) {
        if (sender instanceof Player) plugin.getSiegeManager().expandSiegeCamp((Player) sender, ((Player) sender).getLocation());
        return true;
    }

    private boolean handleUnclaim(CommandSender sender, String[] args) {
        if (sender instanceof Player) plugin.getSiegeManager().unclaimSiegeChunk((Player) sender, ((Player) sender).getLocation());
        return true;
    }

    private boolean handleBanner(CommandSender sender, String[] args) {
        if (!sender.hasPermission("townysieges.admin")) return true;
        Player target = (args.length >= 1) ? Bukkit.getPlayer(args[0]) : (sender instanceof Player ? (Player) sender : null);
        if (target != null) {
            target.getInventory().addItem(plugin.getCaptureManager().getAssaultBannerItem());
            sender.sendMessage(ChatColor.GREEN + "Выдан штурмовой флаг " + target.getName());
        }
        return true;
    }

    private boolean handleCaptureStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "══════ Захваты ══════");
        if (plugin.getCaptureManager().getActiveCaptures().isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Нет захватов.");
        } else {
            for (var cap : plugin.getCaptureManager().getActiveCaptures()) {
                sender.sendMessage(ChatColor.YELLOW + "• " + cap.getAttackingTown() + " | " + cap.getFormattedProgress());
            }
        }
        return true;
    }

    private boolean handleCannon(CommandSender sender, String[] args) {
        if (!sender.hasPermission("townysieges.admin")) return true;
        Player target = (args.length >= 1) ? Bukkit.getPlayer(args[0]) : (sender instanceof Player ? (Player) sender : null);
        if (target != null) {
            target.getInventory().addItem(plugin.getCannonManager().getCannonItem());
            sender.sendMessage(ChatColor.GREEN + "Выдана мортира " + target.getName());
        }
        return true;
    }

    private boolean handleAmmo(CommandSender sender, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("recipes")) {
            sendAmmoRecipes(sender);
            return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("townysieges.admin")) return true;
            boolean isAp = args[1].equalsIgnoreCase("ap");
            int count = (args.length >= 3) ? Integer.parseInt(args[2]) : 1;
            Player target = (args.length >= 4) ? Bukkit.getPlayer(args[3]) : (sender instanceof Player ? (Player) sender : null);
            if (target != null) {
                for (int i=0; i<count; i++) target.getInventory().addItem(plugin.getCannonManager().createAmmoItem(isAp));
                sender.sendMessage(ChatColor.GREEN + "Выдано " + count + " ядер " + target.getName());
            }
            return true;
        }
        return true;
    }

    private void sendAmmoRecipes(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "Рецепты доступны в /siege help");
    }

    private boolean handleNationWar(CommandSender sender, String[] args) {
        if (args.length < 1 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.GOLD + "══════ Войны Наций ══════");
            for (NationWar nw : plugin.getSiegeManager().getAllNationWars()) {
                sender.sendMessage(ChatColor.YELLOW + "• " + nw.getAttackerNation() + " ➔ " + nw.getDefenderNation());
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("declare") && sender instanceof Player && args.length >= 2) {
            plugin.getSiegeManager().declareNationWar((Player) sender, args[1]);
        }
        return true;
    }

    private boolean handleSwitch(CommandSender sender) {
        if (sender instanceof Player) {
            Player p = (Player) sender;
            if (plugin.getCannonManager().isMounted(p)) plugin.getCannonManager().cycleAmmo(p);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "══════ TownySieges ══════");
        sender.sendMessage(ChatColor.YELLOW + "/siege camp <Город>");
        sender.sendMessage(ChatColor.YELLOW + "/siege expand");
        sender.sendMessage(ChatColor.YELLOW + "/disband [Мэр]");
        sender.sendMessage(ChatColor.YELLOW + "/siege admin skip-prep");
        sender.sendMessage(ChatColor.GOLD + "═════════════════════════");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmdName = command.getName().toLowerCase();
        
        // Handle /siege tab completion
        if (cmdName.equals("siege")) {
            if (args.length == 1) {
                return filter(Arrays.asList("camp", "expand", "disband", "unclaim", "banner", "capture", "cannon", "ammo", "nationwar", "admin", "help", "switch"), args[0]);
            }
            if (args.length == 2) {
                String sub = args[0].toLowerCase();
                if (sub.equals("admin")) return filter(Arrays.asList("skip-prep", "end", "status"), args[1]);
                if (sub.equals("nationwar")) return filter(Arrays.asList("declare", "status"), args[1]);
                if (sub.equals("ammo")) return filter(Arrays.asList("give", "recipes"), args[1]);
                if (sub.equals("banner") || sub.equals("cannon")) return filter(Arrays.asList("give"), args[1]);
                if (sub.equals("camp")) return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[1]);
            }
            if (args.length == 3) {
                if (args[0].equalsIgnoreCase("ammo") && args[1].equalsIgnoreCase("give")) return filter(Arrays.asList("regular", "ap"), args[2]);
            }
        }

        // Handle /disband, /cancel tab completion
        if (cmdName.equals("disband") || cmdName.equals("cancel")) {
            if (args.length == 1 && sender.hasPermission("townysieges.admin")) {
                return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[0]);
            }
        }
        
        return new ArrayList<>();
    }

    private List<String> filter(List<String> list, String input) {
        String last = input.toLowerCase();
        return list.stream().filter(s -> s.toLowerCase().startsWith(last)).collect(Collectors.toList());
    }
}
