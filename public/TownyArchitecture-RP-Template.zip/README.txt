Поместите вашу текстуру меню 256x256 в assets/townyarchitecture/textures/gui/menu.png.
Затем активируйте ресурспак в игре и укажите gui.title: '' в config.yml.