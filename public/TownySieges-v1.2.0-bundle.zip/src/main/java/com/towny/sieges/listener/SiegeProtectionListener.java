package com.towny.sieges.listener;

import com.towny.sieges.TownySiegesPlugin;
import com.towny.sieges.cannon.SiegeCannonManager;
import com.towny.sieges.model.ChunkCoord;
import com.towny.sieges.model.SiegeCamp;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.spigotmc.event.entity.EntityDismountEvent;

import java.util.*;

public class SiegeProtectionListener implements Listener {

    private final TownySiegesPlugin plugin;
    private final SiegeCannonManager cannonManager;

    public SiegeProtectionListener(TownySiegesPlugin plugin) {
        this.plugin = plugin;
        this.cannonManager = plugin.getCannonManager();
    }

    public SiegeCannonManager getCannonManager() {
        return cannonManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        ItemStack offHand = player.getInventory().getItemInOffHand();

        if (cannonManager.isCannonItem(hand) || cannonManager.isCannonItem(offHand)) {
            event.setCancelled(true);
            boolean success = cannonManager.deployCannon(player, event.getBlockPlaced().getLocation());
            if (success && player.getGameMode() != GameMode.CREATIVE) {
                if (cannonManager.isCannonItem(hand)) {
                    hand.setAmount(hand.getAmount() - 1);
                } else {
                    offHand.setAmount(offHand.getAmount() - 1);
                }
            }
            return;
        }

        if (player.hasPermission("townysieges.admin")) return;

        ChunkCoord coord = ChunkCoord.fromLocation(event.getBlock().getLocation());
        SiegeCamp camp = plugin.getSiegeManager().getSiegeCampAt(coord);

        if (camp != null) {
            String pTown = plugin.getTownyHook().getPlayerTownName(player);
            if (pTown == null || !pTown.equalsIgnoreCase(camp.getAttackingTown())) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "[TownySieges] Осадный лагерь защищен!");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        Location cannonLoc = cannonManager.getNearbyCannon(b.getLocation());
        if (cannonLoc != null && cannonManager.isCannonAt(cannonLoc)) {
            event.setCancelled(true);
            cannonManager.breakCannon(event.getPlayer(), cannonLoc);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        // 1. If player is seated on a cannon:
        // LMB (Left-click) = Fire cannon
        // RMB (Right-click) = Toggle precision aiming / zoom scope
        if (cannonManager.isMounted(player)) {
            Long mountTime = cannonManager.getLastMountTime(player.getUniqueId());
            if (mountTime != null && System.currentTimeMillis() - mountTime < 600L) {
                event.setCancelled(true);
                return; // Lockout during mount transition
            }

            if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
                event.setCancelled(true);
                cannonManager.fireCannon(player);
                return;
            }
            if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                cannonManager.toggleAiming(player);
                return;
            }
        }

        // 2. Right-click on cannon or adjacent block to mount
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            Block b = event.getClickedBlock();
            Location cannonLoc = cannonManager.getNearbyCannon(b.getLocation());
            if (cannonLoc != null && cannonManager.isCannonAt(cannonLoc)) {
                event.setCancelled(true);
                if (player.isSneaking()) {
                    cannonManager.breakCannon(player, cannonLoc);
                } else {
                    cannonManager.mountGunner(player, cannonLoc);
                }
                return;
            }
        }

        // 3. Left-click on cannon to dismantle
        if (event.getAction() == Action.LEFT_CLICK_BLOCK && event.getClickedBlock() != null) {
            Block b = event.getClickedBlock();
            Location cannonLoc = cannonManager.getNearbyCannon(b.getLocation());
            if (cannonLoc != null && cannonManager.isCannonAt(cannonLoc)) {
                event.setCancelled(true);
                cannonManager.breakCannon(player, cannonLoc);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerAnimation(PlayerAnimationEvent event) {
        Player player = event.getPlayer();
        if (cannonManager.isMounted(player)) {
            // Absolute lockout: prevent mount right-click arm swing packet from firing!
            Long mountTime = cannonManager.getLastMountTime(player.getUniqueId());
            if (mountTime != null && System.currentTimeMillis() - mountTime < 750L) {
                return;
            }
            cannonManager.fireCannon(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent event) {
        handleEntityInteraction(event.getPlayer(), event.getRightClicked(), event);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        handleEntityInteraction(event.getPlayer(), event.getRightClicked(), event);
    }

    private void handleEntityInteraction(Player player, Entity entity, org.bukkit.event.Cancellable event) {
        if (entity == null || player == null) return;
        if (cannonManager.isMounted(player)) {
            event.setCancelled(true);
            Long mountTime = cannonManager.getLastMountTime(player.getUniqueId());
            if (mountTime == null || System.currentTimeMillis() - mountTime >= 600L) {
                cannonManager.toggleAiming(player);
            }
            return;
        }

        Location blockLoc = null;
        if (entity.hasMetadata("siege_cannon_interaction")) {
            blockLoc = (Location) entity.getMetadata("siege_cannon_interaction").get(0).value();
        } else if (entity.hasMetadata("siege_cannon_entity")) {
            blockLoc = (Location) entity.getMetadata("siege_cannon_entity").get(0).value();
        }

        if (blockLoc != null && cannonManager.isCannonAt(blockLoc)) {
            event.setCancelled(true);
            if (player.isSneaking()) {
                cannonManager.breakCannon(player, blockLoc);
            } else {
                cannonManager.mountGunner(player, blockLoc);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        Entity entity = event.getEntity();
        if (event.getDamager() instanceof Player) {
            Player player = (Player) event.getDamager();
            if (cannonManager.isMounted(player)) {
                event.setCancelled(true);
                Long mountTime = cannonManager.getLastMountTime(player.getUniqueId());
                if (mountTime == null || System.currentTimeMillis() - mountTime >= 750L) {
                    cannonManager.fireCannon(player);
                }
                return;
            }
        }

        Location blockLoc = null;
        if (entity.hasMetadata("siege_cannon_interaction")) {
            blockLoc = (Location) entity.getMetadata("siege_cannon_interaction").get(0).value();
        } else if (entity.hasMetadata("siege_cannon_entity")) {
            blockLoc = (Location) entity.getMetadata("siege_cannon_entity").get(0).value();
        }

        if (blockLoc != null && cannonManager.isCannonAt(blockLoc)) {
            event.setCancelled(true);
            if (event.getDamager() instanceof Player) {
                Player player = (Player) event.getDamager();
                cannonManager.breakCannon(player, blockLoc);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if (cannonManager.isMounted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player p = (Player) event.getWhoClicked();
            if (cannonManager.isMounted(p)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        if (cannonManager.isMounted(event.getPlayer())) {
            event.setCancelled(true);
            cannonManager.toggleAiming(event.getPlayer());
        }
    }

    @EventHandler
    public void onPlayerToggleSneak(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && cannonManager.isMounted(event.getPlayer())) {
            cannonManager.unmountGunner(event.getPlayer());
        }
    }

    @EventHandler
    public void onEntityDismount(EntityDismountEvent event) {
        if (event.getEntity() instanceof Player && event.getDismounted().hasMetadata("cannon_seat")) {
            cannonManager.unmountGunner((Player) event.getEntity());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        cannonManager.unmountGunner(event.getPlayer());
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        cannonManager.unmountGunner(event.getEntity());
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (cannonManager.isMounted(event.getPlayer())) {
            cannonManager.unmountGunner(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onEntityExplode(EntityExplodeEvent event) {
        Entity entity = event.getEntity();
        Location loc = event.getLocation();
        boolean isArtillery = isArtilleryWeapon(entity);

        String centerTown = plugin.getTownyHook().getTownNameAt(loc);
        boolean centerInTown = centerTown != null;
        boolean centerUnderSiege = centerInTown && plugin.getSiegeManager().isTownUnderActiveSiege(centerTown);

        if (centerInTown && (!centerUnderSiege || !isArtillery)) {
            event.blockList().clear();
            event.setYield(0.0f);
            event.setCancelled(true);
            return;
        }

        Iterator<Block> it = event.blockList().iterator();
        while (it.hasNext()) {
            Block b = it.next();
            if (b == null) continue;
            String bTown = plugin.getTownyHook().getTownNameAt(b.getLocation());
            if (bTown != null) {
                boolean bUnderSiege = plugin.getSiegeManager().isTownUnderActiveSiege(bTown);
                if (!bUnderSiege || !isArtillery) {
                    it.remove();
                }
            }
        }

        if (event.blockList().isEmpty()) {
            if (centerInTown) {
                event.setCancelled(true);
                event.setYield(0.0f);
            }
        }
    }

    public boolean isArtilleryWeapon(Entity entity) {
        if (entity == null) return true;
        if (entity.hasMetadata("siege_cannon_shell")) return true;
        String name = entity.getType().name();
        if (name.equals("CREEPER") || name.equals("ENDER_CRYSTAL") || name.equals("END_CRYSTAL")) return false;
        return entity instanceof TNTPrimed || entity instanceof FallingBlock;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() >> 4 == event.getTo().getBlockX() >> 4 &&
            event.getFrom().getBlockZ() >> 4 == event.getTo().getBlockZ() >> 4) {
            return;
        }
        ChunkCoord toCoord = ChunkCoord.fromLocation(event.getTo());
        SiegeCamp camp = plugin.getSiegeManager().getSiegeCampAt(toCoord);
        if (camp != null) {
            Player p = event.getPlayer();
            String phaseStr = camp.isActiveSiege() ? "§4[АКТИВНЫЙ ШТУРМ 2Ч]" : "§e[Подготовка 24ч]";
            String msg = "§c⚔ Осадный лагерь §6" + camp.getAttackingTown() + " ➔ §c" + camp.getDefendingTown() + " " + phaseStr;
            try {
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
            } catch (Exception ignored) {}
        }
    }
}
