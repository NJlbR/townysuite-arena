package com.towny.sieges.hook;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.palmergames.bukkit.towny.object.WorldCoord;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

public class TownyHook {

    public boolean isTownyEnabled() {
        return Bukkit.getPluginManager().isPluginEnabled("Towny");
    }

    public Town getTown(String townName) {
        if (!isTownyEnabled() || townName == null) return null;
        try {
            return TownyAPI.getInstance().getTown(townName);
        } catch (Throwable ignored) {
            return null;
        }
    }

    public Town getTownAt(Location loc) {
        if (!isTownyEnabled() || loc == null) return null;
        try {
            TownyAPI api = TownyAPI.getInstance();
            if (api != null) {
                Town town = api.getTown(loc);
                if (town != null) return town;
                TownBlock tb = api.getTownBlock(loc);
                if (tb != null) {
                    return tb.getTownOrNull();
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public String getTownNameAt(Location loc) {
        if (!isTownyEnabled() || loc == null) return null;
        try {
            TownyAPI api = TownyAPI.getInstance();
            if (api != null) {
                String name = api.getTownName(loc);
                if (name != null && !name.isEmpty()) return name;
                Town town = getTownAt(loc);
                if (town != null) return town.getName();
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public String getPlayerTownName(Player player) {
        if (!isTownyEnabled() || player == null) return null;
        try {
            Resident res = TownyAPI.getInstance().getResident(player);
            if (res != null && res.hasTown()) {
                return res.getTown().getName();
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public boolean isMayor(Player player, String townName) {
        if (!isTownyEnabled() || player == null || townName == null) return false;
        try {
            Town town = getTown(townName);
            if (town != null && town.hasMayor()) {
                return town.getMayor().getName().equalsIgnoreCase(player.getName());
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean isResidentOfTown(Player player, String townName) {
        if (!isTownyEnabled() || player == null || townName == null) return false;
        try {
            Resident res = TownyAPI.getInstance().getResident(player);
            if (res != null && res.hasTown()) {
                return res.getTown().getName().equalsIgnoreCase(townName);
            }
        } catch (Throwable ignored) {}
        return false;
    }

    // --- Nation Wars Integration ---

    public Nation getNation(String nationName) {
        if (!isTownyEnabled() || nationName == null) return null;
        try {
            return TownyAPI.getInstance().getNation(nationName);
        } catch (Throwable ignored) {
            return null;
        }
    }

    public String getTownNationName(String townName) {
        if (!isTownyEnabled() || townName == null) return null;
        try {
            Town town = getTown(townName);
            if (town != null && town.hasNation()) {
                Nation n = town.getNationOrNull();
                if (n != null) return n.getName();
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public String getPlayerNationName(Player player) {
        if (!isTownyEnabled() || player == null) return null;
        try {
            String townName = getPlayerTownName(player);
            if (townName != null) {
                return getTownNationName(townName);
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public boolean isNationKing(Player player, String nationName) {
        if (!isTownyEnabled() || player == null || nationName == null) return false;
        try {
            Nation nation = getNation(nationName);
            if (nation != null && nation.getKing() != null) {
                return nation.getKing().getName().equalsIgnoreCase(player.getName());
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public Set<String> getNationTownNames(String nationName) {
        Set<String> towns = new LinkedHashSet<>();
        if (!isTownyEnabled() || nationName == null) return towns;
        try {
            Nation nation = getNation(nationName);
            if (nation != null && nation.getTowns() != null) {
                for (Town t : nation.getTowns()) {
                    if (t != null && t.getName() != null) {
                        towns.add(t.getName());
                    }
                }
            }
        } catch (Throwable ignored) {}
        return towns;
    }

    public double getClosestDistanceInChunks(Location loc, String targetTownName) {
        if (!isTownyEnabled() || loc == null || targetTownName == null) return Double.MAX_VALUE;
        try {
            Town target = getTown(targetTownName);
            if (target == null) return Double.MAX_VALUE;

            Collection<TownBlock> blocks = target.getTownBlocks();
            if (blocks == null || blocks.isEmpty()) return Double.MAX_VALUE;

            int locChunkX = loc.getBlockX() >> 4;
            int locChunkZ = loc.getBlockZ() >> 4;
            String worldName = loc.getWorld().getName();

            double minDistance = Double.MAX_VALUE;
            for (TownBlock tb : blocks) {
                WorldCoord wc = tb.getWorldCoord();
                if (wc.getWorldName().equalsIgnoreCase(worldName)) {
                    double dx = wc.getX() - locChunkX;
                    double dz = wc.getZ() - locChunkZ;
                    double dist = Math.sqrt(dx * dx + dz * dz);
                    if (dist < minDistance) {
                        minDistance = dist;
                    }
                }
            }
            return minDistance;
        } catch (Throwable ignored) {
            return Double.MAX_VALUE;
        }
    }

    public boolean isTownBankHas(String townName, double amount) {
        if (!isTownyEnabled() || townName == null) return true;
        try {
            Town town = getTown(townName);
            if (town != null && town.getAccount() != null) {
                return town.getAccount().canPayFromHoldings(amount);
            }
        } catch (Throwable ignored) {}
        return true;
    }

    public boolean withdrawFromTownBank(String townName, double amount, String reason) {
        if (!isTownyEnabled() || townName == null) return true;
        try {
            Town town = getTown(townName);
            if (town != null && town.getAccount() != null) {
                if (town.getAccount().canPayFromHoldings(amount)) {
                    town.getAccount().withdraw(amount, reason);
                    return true;
                }
                return false;
            }
        } catch (Throwable ignored) {}
        return true;
    }
}
