package com.towny.sieges.manager;

import com.towny.sieges.TownySiegesPlugin;
import com.towny.sieges.model.ChunkCoord;
import com.towny.sieges.model.NationWar;
import com.towny.sieges.model.SiegeCamp;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SiegeManager {

    private final TownySiegesPlugin plugin;
    private final Map<String, SiegeCamp> siegesById = new ConcurrentHashMap<>();
    private final Map<String, SiegeCamp> siegesByDefendingTown = new ConcurrentHashMap<>();
    private final Map<String, SiegeCamp> siegesByAttackingTown = new ConcurrentHashMap<>();
    private final Map<ChunkCoord, SiegeCamp> chunkToCamp = new ConcurrentHashMap<>();

    // Active Nation Wars
    private final Map<String, NationWar> activeNationWars = new ConcurrentHashMap<>();

    private File dataFile;
    private FileConfiguration dataConfig;

    public SiegeManager(TownySiegesPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadData() {
        dataFile = new File(plugin.getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Не удалось создать data.yml: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        siegesById.clear();
        siegesByDefendingTown.clear();
        siegesByAttackingTown.clear();
        chunkToCamp.clear();
        activeNationWars.clear();

        // Load local town sieges
        ConfigurationSection sec = dataConfig.getConfigurationSection("sieges");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(id);
                if (s == null) continue;

                String attacker = s.getString("attacking-town");
                String defender = s.getString("defending-town");
                String mayor = s.getString("mayor");
                String world = s.getString("world", "world");
                String initialCoordStr = s.getString("initial-chunk");
                ChunkCoord initialChunk = ChunkCoord.deserialize(initialCoordStr);

                List<String> chunkList = s.getStringList("claimed-chunks");
                Set<ChunkCoord> claimed = new LinkedHashSet<>();
                for (String cStr : chunkList) {
                    ChunkCoord cc = ChunkCoord.deserialize(cStr);
                    if (cc != null) claimed.add(cc);
                }

                long createdAt = s.getLong("created-at", System.currentTimeMillis());
                long prepEnds = s.getLong("preparation-ends-at", createdAt + 86400000L);
                long activeEnds = s.getLong("active-ends-at", prepEnds + 7200000L);
                String statusStr = s.getString("status", "PREPARATION");
                SiegeCamp.Status status;
                try {
                    status = SiegeCamp.Status.valueOf(statusStr);
                } catch (Exception e) {
                    status = SiegeCamp.Status.PREPARATION;
                }

                SiegeCamp camp = new SiegeCamp(id, attacker, defender, mayor, world, initialChunk, claimed,
                        createdAt, prepEnds, activeEnds, status);

                registerSiege(camp);
            }
        }

        // Load Nation Wars
        ConfigurationSection nwSec = dataConfig.getConfigurationSection("nation-wars");
        if (nwSec != null) {
            for (String warId : nwSec.getKeys(false)) {
                ConfigurationSection ws = nwSec.getConfigurationSection(warId);
                if (ws == null) continue;

                String attackerNat = ws.getString("attacker-nation");
                String defenderNat = ws.getString("defender-nation");
                String leader = ws.getString("declared-by");
                List<String> atTowns = ws.getStringList("attacker-towns");
                List<String> defTowns = ws.getStringList("defender-towns");
                List<String> camps = ws.getStringList("linked-camps");
                long createdAt = ws.getLong("created-at", System.currentTimeMillis());
                long prepEnds = ws.getLong("preparation-ends-at", createdAt + 86400000L);
                long activeEnds = ws.getLong("active-ends-at", prepEnds + 7200000L);
                String stStr = ws.getString("status", "PREPARATION");
                NationWar.Status st;
                try {
                    st = NationWar.Status.valueOf(stStr);
                } catch (Exception e) {
                    st = NationWar.Status.PREPARATION;
                }

                NationWar war = new NationWar(warId, attackerNat, defenderNat, leader,
                        new LinkedHashSet<>(atTowns), new LinkedHashSet<>(defTowns), camps,
                        createdAt, prepEnds, activeEnds, st);

                activeNationWars.put(warId, war);
            }
        }

        plugin.getLogger().info("[TownySieges] Загружено осад: " + siegesById.size() + ", войн наций: " + activeNationWars.size());
    }

    public void saveData() {
        if (dataConfig == null || dataFile == null) return;
        dataConfig.set("sieges", null);
        dataConfig.set("nation-wars", null);

        // Save local sieges
        for (SiegeCamp camp : siegesById.values()) {
            String path = "sieges." + camp.getSiegeId();
            dataConfig.set(path + ".attacking-town", camp.getAttackingTown());
            dataConfig.set(path + ".defending-town", camp.getDefendingTown());
            dataConfig.set(path + ".mayor", camp.getMayorName());
            dataConfig.set(path + ".world", camp.getWorldName());
            dataConfig.set(path + ".initial-chunk", camp.getInitialCampChunk().serialize());

            List<String> chunkList = new ArrayList<>();
            for (ChunkCoord cc : camp.getClaimedChunks()) {
                chunkList.add(cc.serialize());
            }
            dataConfig.set(path + ".claimed-chunks", chunkList);
            dataConfig.set(path + ".created-at", camp.getCreatedAtMillis());
            dataConfig.set(path + ".preparation-ends-at", camp.getPreparationEndsAtMillis());
            dataConfig.set(path + ".active-ends-at", camp.getActiveEndsAtMillis());
            dataConfig.set(path + ".status", camp.getStatus().name());
        }

        // Save Nation Wars
        for (NationWar war : activeNationWars.values()) {
            String path = "nation-wars." + war.getWarId();
            dataConfig.set(path + ".attacker-nation", war.getAttackerNation());
            dataConfig.set(path + ".defender-nation", war.getDefenderNation());
            dataConfig.set(path + ".declared-by", war.getDeclaredByLeader());
            dataConfig.set(path + ".attacker-towns", new ArrayList<>(war.getAttackerTowns()));
            dataConfig.set(path + ".defender-towns", new ArrayList<>(war.getDefenderTowns()));
            dataConfig.set(path + ".linked-camps", war.getLinkedCampIds());
            dataConfig.set(path + ".created-at", war.getCreatedAtMillis());
            dataConfig.set(path + ".preparation-ends-at", war.getPreparationEndsAtMillis());
            dataConfig.set(path + ".active-ends-at", war.getActiveEndsAtMillis());
            dataConfig.set(path + ".status", war.getStatus().name());
        }

        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    private void registerSiege(SiegeCamp camp) {
        siegesById.put(camp.getSiegeId(), camp);
        siegesByDefendingTown.put(camp.getDefendingTown().toLowerCase(), camp);
        siegesByAttackingTown.put(camp.getAttackingTown().toLowerCase(), camp);
        for (ChunkCoord cc : camp.getClaimedChunks()) {
            chunkToCamp.put(cc, camp);
        }
    }

    private void unregisterSiege(SiegeCamp camp) {
        siegesById.remove(camp.getSiegeId());
        siegesByDefendingTown.remove(camp.getDefendingTown().toLowerCase());
        siegesByAttackingTown.remove(camp.getAttackingTown().toLowerCase());
        for (ChunkCoord cc : camp.getClaimedChunks()) {
            chunkToCamp.remove(cc);
        }
    }

    // --- Nation Wars Core Methods ---

    public boolean declareNationWar(Player leader, String targetNationName) {
        if (leader == null || targetNationName == null) return false;

        String playerTown = plugin.getTownyHook().getPlayerTownName(leader);
        if (playerTown == null) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Вы должны состоять в городе, чтобы объявить войну наций!");
            return false;
        }

        String playerNation = plugin.getTownyHook().getTownNationName(playerTown);
        if (playerNation == null) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Ваш город не состоит ни в одной нации!");
            return false;
        }

        if (!plugin.getTownyHook().isNationKing(leader, playerNation) && !leader.hasPermission("townysieges.admin")) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Только Глава (Король) нации может объявлять войну наций!");
            return false;
        }

        if (playerNation.equalsIgnoreCase(targetNationName)) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Вы не можете объявить войну собственной нации!");
            return false;
        }

        if (getActiveNationWar(playerNation) != null) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Ваша нация («" + playerNation + "») уже ведёт войну наций!");
            return false;
        }

        if (getActiveNationWar(targetNationName) != null) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Нация-цель («" + targetNationName + "») уже находится в состоянии войны!");
            return false;
        }

        Set<String> attackerTowns = plugin.getTownyHook().getNationTownNames(playerNation);
        Set<String> defenderTowns = plugin.getTownyHook().getNationTownNames(targetNationName);

        if (attackerTowns.isEmpty()) {
            attackerTowns.add(playerTown);
        }
        if (defenderTowns.isEmpty()) {
            leader.sendMessage(ChatColor.RED + "[TownySieges] Нация-цель «" + targetNationName + "» не найдена или не имеет городов в Towny!");
            return false;
        }

        long prepSeconds = plugin.getConfig().getLong("nationwar.preparation-duration-seconds", 86400L); // 24 hours
        long assaultSeconds = plugin.getConfig().getLong("nationwar.assault-duration-seconds", 7200L);     // 2 hours
        String warId = "war_" + playerNation.toLowerCase() + "_" + targetNationName.toLowerCase() + "_" + System.currentTimeMillis();

        NationWar war = new NationWar(warId, playerNation, targetNationName, leader.getName(),
                attackerTowns, defenderTowns, prepSeconds, assaultSeconds);

        activeNationWars.put(warId, war);
        saveData();

        String prepTimeStr = (prepSeconds / 3600) + " ч.";
        String broadcastMsg = ChatColor.translateAlternateColorCodes('&',
                "&4&l[ВОЙНА НАЦИЙ] &eГлава нации &6" + playerNation + " &e(&f" + leader.getName() +
                "&e) объявил войну нации &c" + targetNationName +
                "&e! ВСЕ города обеих наций переведены в режим подготовки к штурму с единым таймером (" + prepTimeStr + ")!");

        Bukkit.broadcastMessage(broadcastMsg);

        for (Player p : Bukkit.getOnlinePlayers()) {
            String pTown = plugin.getTownyHook().getPlayerTownName(p);
            if (pTown != null) {
                String pNation = plugin.getTownyHook().getTownNationName(pTown);
                if (pNation != null) {
                    if (pNation.equalsIgnoreCase(targetNationName)) {
                        p.sendTitle(ChatColor.DARK_RED + "⚔ ВАШЕЙ НАЦИИ ОБЪЯВЛЕНА ВОЙНА! ⚔",
                                ChatColor.YELLOW + "Враг: " + playerNation + " | Штурм всех городов через: " + prepTimeStr, 10, 100, 20);
                        p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1.8f, 0.7f);
                    } else if (pNation.equalsIgnoreCase(playerNation)) {
                        p.sendTitle(ChatColor.GOLD + "⚔ ВОЙНА НАЦИЙ ОБЪЯВЛЕНА! ⚔",
                                ChatColor.YELLOW + "Цель: " + targetNationName + " | Штурм всех городов через: " + prepTimeStr, 10, 100, 20);
                        p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1.5f, 1.0f);
                    }
                }
            }
        }

        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }

    public NationWar getActiveNationWar(String nationName) {
        if (nationName == null) return null;
        for (NationWar war : activeNationWars.values()) {
            if (war.getAttackerNation().equalsIgnoreCase(nationName) ||
                war.getDefenderNation().equalsIgnoreCase(nationName)) {
                return war;
            }
        }
        return null;
    }

    public NationWar getActiveNationWarForTown(String townName) {
        if (townName == null) return null;
        for (NationWar war : activeNationWars.values()) {
            if (war.isTownParticipating(townName)) {
                return war;
            }
        }
        return null;
    }

    public Collection<NationWar> getAllNationWars() {
        return Collections.unmodifiableCollection(activeNationWars.values());
    }

    public boolean createSiegeCamp(Player mayor, String defendingTownName, Location loc) {
        if (mayor == null || defendingTownName == null || loc == null) return false;

        String attackingTown = plugin.getTownyHook().getPlayerTownName(mayor);
        if (attackingTown == null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Вы должны состоять в городе, чтобы объявить осаду!");
            return false;
        }

        if (!plugin.getTownyHook().isMayor(mayor, attackingTown) && !mayor.hasPermission("townysieges.admin")) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Только Мэр города может ставить осадный лагерь!");
            return false;
        }

        if (attackingTown.equalsIgnoreCase(defendingTownName)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Вы не можете осаждать собственный город!");
            return false;
        }

        if (plugin.getTownyHook().getTown(defendingTownName) == null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Город-цель «" + defendingTownName + "» не найден в базе Towny!");
            return false;
        }

        // Check if current chunk is claimed by Towny
        String townAtLoc = plugin.getTownyHook().getTownNameAt(loc);
        if (townAtLoc != null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Этот чанк уже принадлежит городу «" + townAtLoc + "»! Осадный лагерь ставится на свободной земле.");
            return false;
        }

        ChunkCoord campCoord = ChunkCoord.fromLocation(loc);
        if (chunkToCamp.containsKey(campCoord)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Здесь уже разбит другой осадный лагерь!");
            return false;
        }

        // Check active Nation War between both towns
        NationWar activeWar = getActiveNationWarForTown(attackingTown);
        boolean isPartOfNationWar = activeWar != null && activeWar.isTownParticipating(defendingTownName);

        if (!isPartOfNationWar) {
            // Standard individual siege restrictions
            if (siegesByAttackingTown.containsKey(attackingTown.toLowerCase())) {
                mayor.sendMessage(ChatColor.RED + "[TownySieges] Ваш город уже ведет осаду! Завершите текущую перед началом новой.");
                return false;
            }
            if (siegesByDefendingTown.containsKey(defendingTownName.toLowerCase())) {
                mayor.sendMessage(ChatColor.RED + "[TownySieges] Город «" + defendingTownName + "» уже находится под осадой!");
                return false;
            }
        }

        // Distance Checks
        double minDistance = plugin.getConfig().getDouble("siege.min-distance-chunks", 3.0);
        double maxDistance = plugin.getConfig().getDouble("siege.max-distance-chunks", 10.0);
        double actualDistance = plugin.getTownyHook().getClosestDistanceInChunks(loc, defendingTownName);

        if (actualDistance == Double.MAX_VALUE) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Город-цель «" + defendingTownName + "» не имеет приватов в этом мире!");
            return false;
        }

        if (actualDistance < minDistance) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Слишком близко к городу «" + defendingTownName + "»! Дистанция: " + 
                    String.format("%.1f", actualDistance) + " чанков (минимум: " + minDistance + " ч.).");
            return false;
        }

        if (actualDistance > maxDistance) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Слишком далеко от города «" + defendingTownName + "»! Дистанция: " + 
                    String.format("%.1f", actualDistance) + " чанков (максимум: " + maxDistance + " ч.).");
            return false;
        }

        // Economy Check
        double initialCost = plugin.getConfig().getDouble("siege.economy.initial-camp-cost", 5000.0);
        if (!plugin.getTownyHook().isTownBankHas(attackingTown, initialCost)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] В казне города недостаточно средств! Стоимость установки осадного лагеря: " + 
                    initialCost + " монет.");
            return false;
        }

        if (!plugin.getTownyHook().withdrawFromTownBank(attackingTown, initialCost, "Установка осадного лагеря против " + defendingTownName)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Ошибка списания средств из казны города!");
            return false;
        }

        // Create the Siege
        long prepSeconds = plugin.getConfig().getLong("siege.preparation-duration-seconds", 86400L); // 24 hours
        long activeSeconds = plugin.getConfig().getLong("siege.active-duration-seconds", 7200L);     // 2 hours
        String siegeId = "siege_" + attackingTown.toLowerCase() + "_" + defendingTownName.toLowerCase() + "_" + System.currentTimeMillis();

        SiegeCamp camp = new SiegeCamp(siegeId, attackingTown, defendingTownName, mayor.getName(),
                loc.getWorld().getName(), campCoord, prepSeconds, activeSeconds);

        if (isPartOfNationWar) {
            // NATION WAR SYNCHRONIZATION RULE:
            // "осада между городами не будет начинаться, а будет продолжаться таймер нации"
            camp.setPreparationEndsAtMillis(activeWar.getPreparationEndsAtMillis());
            camp.setActiveEndsAtMillis(activeWar.getActiveEndsAtMillis());
            if (activeWar.isActiveAssault()) {
                camp.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
            } else {
                camp.setStatus(SiegeCamp.Status.PREPARATION);
            }
            activeWar.addLinkedCamp(siegeId);

            registerSiege(camp);
            saveData();

            String warAlert = ChatColor.translateAlternateColorCodes('&',
                    "&c&l[ЛАГЕРЬ ВОЙНЫ НАЦИЙ] &eМэр города &6" + attackingTown + " &eразбил осадный лагерь против города &c" + defendingTownName +
                    "&e в рамках Войны Наций! Единый таймер нации продолжается: &f" + activeWar.getFormattedRemainingTime() + "&e.");
            Bukkit.broadcastMessage(warAlert);
            mayor.sendMessage(ChatColor.GREEN + "[TownySieges] Осадный лагерь привязан к фронту Войны Наций с единым таймером!");
        } else {
            // Standalone town siege
            registerSiege(camp);
            saveData();

            String prepTimeStr = (prepSeconds / 3600) + " ч.";
            String alertMsg = ChatColor.translateAlternateColorCodes('&', 
                    "&c&l[ОСАДА] &eМэр города &6" + attackingTown + " &eразбил осадный лагерь против города &c" + defendingTownName + 
                    "&e! До штурма осталось: &f" + prepTimeStr + ".");
            Bukkit.broadcastMessage(alertMsg);
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            String pTown = plugin.getTownyHook().getPlayerTownName(p);
            if (pTown != null) {
                if (pTown.equalsIgnoreCase(defendingTownName)) {
                    p.sendTitle(ChatColor.RED + "⚔ ВАШ ГОРОД ОСАЖДЁН! ⚔", 
                            ChatColor.YELLOW + "Лагерь врага: " + attackingTown + " | Единый таймер: " + camp.getFormattedRemainingTime(), 10, 80, 20);
                    p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1.5f, 0.8f);
                } else if (pTown.equalsIgnoreCase(attackingTown)) {
                    p.sendTitle(ChatColor.GOLD + "⚔ ОСАДНЫЙ ЛАГЕРЬ РАЗБИТ! ⚔", 
                            ChatColor.YELLOW + "Цель: " + defendingTownName + " | Таймер: " + camp.getFormattedRemainingTime(), 10, 80, 20);
                    p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);
                }
            }
        }

        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }

    public boolean expandSiegeCamp(Player mayor, Location loc) {
        if (mayor == null || loc == null) return false;

        String attackingTown = plugin.getTownyHook().getPlayerTownName(mayor);
        if (attackingTown == null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Вы должны состоять в городе!");
            return false;
        }

        SiegeCamp camp = siegesByAttackingTown.get(attackingTown.toLowerCase());
        if (camp == null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] У вашего города нет активного осадного лагеря!");
            return false;
        }

        if (!plugin.getTownyHook().isMayor(mayor, attackingTown) && !mayor.hasPermission("townysieges.admin")) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Только Мэр города может расширять осадный лагерь!");
            return false;
        }

        ChunkCoord coord = ChunkCoord.fromLocation(loc);
        if (camp.containsChunk(coord)) {
            mayor.sendMessage(ChatColor.YELLOW + "[TownySieges] Этот чанк уже входит в ваш осадный лагерь!");
            return false;
        }

        if (chunkToCamp.containsKey(coord)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Этот чанк занят другим осадным лагерем!");
            return false;
        }

        String townAt = plugin.getTownyHook().getTownNameAt(loc);
        if (townAt != null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Нельзя приватить территорию города «" + townAt + "» под осадный лагерь!");
            return false;
        }

        if (!camp.isAdjacentToCamp(coord)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Расширять осадный лагерь можно только на соседние прилегающие чанки!");
            return false;
        }

        int maxChunks = plugin.getConfig().getInt("siege.max-siege-chunks-per-camp", 8);
        if (camp.getClaimedChunks().size() >= maxChunks) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Достигнут лимит размера осадного лагеря (" + maxChunks + " чанков)!");
            return false;
        }

        double expandCost = plugin.getConfig().getDouble("siege.economy.expand-chunk-cost", 2500.0);
        if (!plugin.getTownyHook().isTownBankHas(attackingTown, expandCost)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] В казне города недостаточно средств! Стоимость расширения чанка: " + 
                    expandCost + " монет.");
            return false;
        }

        if (!plugin.getTownyHook().withdrawFromTownBank(attackingTown, expandCost, "Расширение осадного лагеря против " + camp.getDefendingTown())) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Ошибка списания средств из казны города!");
            return false;
        }

        camp.addClaimedChunk(coord);
        chunkToCamp.put(coord, camp);
        saveData();

        mayor.sendMessage(ChatColor.GREEN + "[TownySieges] ✔ Чанк успешно присоединен к осадному лагерю! Всего чанков лагеря: " + 
                camp.getClaimedChunks().size() + "/" + maxChunks + ".");
        mayor.playSound(loc, Sound.BLOCK_ANVIL_USE, 1.0f, 1.2f);
        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }

    public boolean unclaimSiegeChunk(Player mayor, Location loc) {
        if (mayor == null || loc == null) return false;

        String town = plugin.getTownyHook().getPlayerTownName(mayor);
        if (town == null) return false;

        SiegeCamp camp = siegesByAttackingTown.get(town.toLowerCase());
        if (camp == null) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] У вашего города нет осадного лагеря.");
            return false;
        }

        ChunkCoord coord = ChunkCoord.fromLocation(loc);
        if (!camp.containsChunk(coord)) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Этот чанк не входит в ваш осадный лагерь.");
            return false;
        }

        if (coord.equals(camp.getInitialCampChunk())) {
            mayor.sendMessage(ChatColor.RED + "[TownySieges] Нельзя расприватить центральный форпост осадного лагеря!");
            return false;
        }

        camp.removeClaimedChunk(coord);
        chunkToCamp.remove(coord);
        saveData();

        mayor.sendMessage(ChatColor.YELLOW + "[TownySieges] Чанк осадного лагеря распривачен.");
        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }

    /**
     * CRITICAL API FOR TOWNYEXPLOSIONUNBLOCKER & ARTILLERY:
     * Returns true if the town is currently in active 2-hour assault phase,
     * either via individual town siege OR via Nation War!
     * When true: all explosions, cannons, and block breaks are PERMITTED!
     */
    public boolean isTownUnderActiveSiege(String townName) {
        if (townName == null) return false;
        
        // 1. Direct local siege
        SiegeCamp camp = siegesByDefendingTown.get(townName.toLowerCase());
        if (camp != null && camp.isActiveSiege()) return true;

        // 2. Nation Wars: ALL towns of both nations are vulnerable during 2h active assault!
        for (NationWar war : activeNationWars.values()) {
            if (war.isActiveAssault() && war.isTownParticipating(townName)) {
                return true;
            }
        }

        return false;
    }

    public boolean isLocationUnderActiveSiege(Location loc) {
        if (loc == null) return false;
        String townName = plugin.getTownyHook().getTownNameAt(loc);
        return isTownUnderActiveSiege(townName);
    }

    public SiegeCamp getActiveSiegeForTown(String townName) {
        if (townName == null) return null;
        SiegeCamp def = siegesByDefendingTown.get(townName.toLowerCase());
        if (def != null) return def;
        return siegesByAttackingTown.get(townName.toLowerCase());
    }

    public SiegeCamp getSiegeCampAt(ChunkCoord coord) {
        return chunkToCamp.get(coord);
    }

    public Collection<SiegeCamp> getAllSieges() {
        return Collections.unmodifiableCollection(siegesById.values());
    }

    public void tick() {
        long now = System.currentTimeMillis();
        boolean needsSave = false;

        // 1. Tick Local Town Sieges
        for (SiegeCamp camp : siegesById.values()) {
            if (camp.getStatus() == SiegeCamp.Status.PREPARATION) {
                if (now >= camp.getPreparationEndsAtMillis()) {
                    camp.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
                    needsSave = true;

                    String msg = ChatColor.translateAlternateColorCodes('&', 
                            "&4&l[ШТУРМ] &c24 часа подготовки истекли! Начался активный 2-часовой штурм города &6" + 
                            camp.getDefendingTown() + " &cсилами &6" + camp.getAttackingTown() + "&c! Орудия и взрывы АКТИВИРОВАНЫ!");

                    Bukkit.broadcastMessage(msg);

                    for (Player p : Bukkit.getOnlinePlayers()) {
                        String pTown = plugin.getTownyHook().getPlayerTownName(p);
                        if (pTown != null) {
                            if (pTown.equalsIgnoreCase(camp.getDefendingTown())) {
                                p.sendTitle(ChatColor.DARK_RED + "⚡ ВРАГ ПОШЁЛ НА ШТУРМ! ⚡", 
                                        ChatColor.RED + "Взрывы и орудия активны! Обороняйте Мэрию!", 10, 100, 20);
                                p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.6f);
                            } else if (pTown.equalsIgnoreCase(camp.getAttackingTown())) {
                                p.sendTitle(ChatColor.RED + "⚡ ВРЕМЯ ШТУРМА НАСТАЛО! ⚡", 
                                        ChatColor.GOLD + "Фугасы и осадные орудия готовы к бою!", 10, 100, 20);
                                p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1.5f, 1.0f);
                            }
                        }
                    }
                }
            } else if (camp.getStatus() == SiegeCamp.Status.ACTIVE_SIEGE) {
                if (now >= camp.getActiveEndsAtMillis()) {
                    camp.setStatus(SiegeCamp.Status.COMPLETED);
                    needsSave = true;

                    String msg = ChatColor.translateAlternateColorCodes('&', 
                            "&a&l[ОСАДА ЗАВЕРШЕНА] &e2-часовой активный штурм города &6" + camp.getDefendingTown() + 
                            " &eзавершен! Город перешел в режим защиты и восстановления. Осадные взрывы ОТКЛЮЧЕНЫ.");

                    Bukkit.broadcastMessage(msg);
                }
            }
        }

        // 2. Tick Nation Wars (Unified Global Timer)
        for (NationWar war : activeNationWars.values()) {
            if (war.getStatus() == NationWar.Status.PREPARATION) {
                if (now >= war.getPreparationEndsAtMillis()) {
                    war.setStatus(NationWar.Status.ACTIVE_ASSAULT);
                    // Sync all linked camps to active assault
                    for (String campId : war.getLinkedCampIds()) {
                        SiegeCamp c = siegesById.get(campId);
                        if (c != null) {
                            c.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
                        }
                    }
                    needsSave = true;

                    String msg = ChatColor.translateAlternateColorCodes('&',
                            "&4&l[ШТУРМ НАЦИЙ 2Ч] &c24 часа подготовки истекли! Начался АКТИВНЫЙ 2-ЧАСОВОЙ ШТУРМ между нациями &6" +
                            war.getAttackerNation() + " &cи &6" + war.getDefenderNation() +
                            "&c! ВСЕ города обеих наций становятся УЯЗВИМЫ К ВЗРЫВАМ И ПУШКАМ!");

                    Bukkit.broadcastMessage(msg);

                    for (Player p : Bukkit.getOnlinePlayers()) {
                        String pTown = plugin.getTownyHook().getPlayerTownName(p);
                        if (pTown != null && war.isTownParticipating(pTown)) {
                            p.sendTitle(ChatColor.DARK_RED + "⚡ ШТУРМ НАЦИЙ НАЧАЛСЯ! ⚡",
                                    ChatColor.RED + "ВСЕ города уязвимы к взрывам (2 часа)! К орудиям!", 10, 120, 20);
                            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.8f, 0.6f);
                        }
                    }
                }
            } else if (war.getStatus() == NationWar.Status.ACTIVE_ASSAULT) {
                if (now >= war.getActiveEndsAtMillis()) {
                    war.setStatus(NationWar.Status.COMPLETED);
                    for (String campId : war.getLinkedCampIds()) {
                        SiegeCamp c = siegesById.get(campId);
                        if (c != null) {
                            c.setStatus(SiegeCamp.Status.COMPLETED);
                        }
                    }
                    activeNationWars.remove(war.getWarId());
                    needsSave = true;

                    String msg = ChatColor.translateAlternateColorCodes('&',
                            "&a&l[ВОЙНА НАЦИЙ ЗАВЕРШЕНА] &e2-часовой штурм между &6" + war.getAttackerNation() +
                            " &eи &6" + war.getDefenderNation() + "&e завершён! Все города обеих наций возвращены в мирный режим с защитой от взрывов.");

                    Bukkit.broadcastMessage(msg);

                    for (Player p : Bukkit.getOnlinePlayers()) {
                        String pTown = plugin.getTownyHook().getPlayerTownName(p);
                        if (pTown != null && war.isTownParticipating(pTown)) {
                            p.sendTitle(ChatColor.GREEN + "ВОЙНА НАЦИЙ ОКОНЧЕНА", ChatColor.YELLOW + "Штурм завершён. Восстанавливайте повреждения.", 10, 80, 20);
                            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                        }
                    }
                }
            }
        }

        if (needsSave) {
            saveData();
        }

        plugin.getBossBarManager().updateAllBossBars();
    }

    public void forceStartSiege(String defendingTownName) {
        SiegeCamp camp = siegesByDefendingTown.get(defendingTownName.toLowerCase());
        if (camp != null) {
            camp.setPreparationEndsAtMillis(System.currentTimeMillis() - 1000L);
            camp.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
            saveData();
            plugin.getBossBarManager().updateAllBossBars();
        }
    }

    public boolean forceStartNationAssault(String nationName) {
        NationWar war = getActiveNationWar(nationName);
        if (war != null) {
            war.setPreparationEndsAtMillis(System.currentTimeMillis() - 1000L);
            war.setStatus(NationWar.Status.ACTIVE_ASSAULT);
            for (String campId : war.getLinkedCampIds()) {
                SiegeCamp c = siegesById.get(campId);
                if (c != null) c.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
            }
            saveData();
            plugin.getBossBarManager().updateAllBossBars();
            return true;
        }
        return false;
    }

    public boolean skipNationWarTime(String nationName, long seconds) {
        NationWar war = getActiveNationWar(nationName);
        if (war == null) return false;

        long now = System.currentTimeMillis();
        if (war.getStatus() == NationWar.Status.PREPARATION) {
            long newPrepEnd = war.getPreparationEndsAtMillis() - (seconds * 1000L);
            if (newPrepEnd <= now) {
                war.setPreparationEndsAtMillis(now - 1000L);
                war.setStatus(NationWar.Status.ACTIVE_ASSAULT);
            } else {
                war.setPreparationEndsAtMillis(newPrepEnd);
            }
        } else if (war.getStatus() == NationWar.Status.ACTIVE_ASSAULT) {
            long newActiveEnd = war.getActiveEndsAtMillis() - (seconds * 1000L);
            if (newActiveEnd <= now) {
                war.setActiveEndsAtMillis(now - 1000L);
                war.setStatus(NationWar.Status.COMPLETED);
                activeNationWars.remove(war.getWarId());
            } else {
                war.setActiveEndsAtMillis(newActiveEnd);
            }
        }

        for (String campId : war.getLinkedCampIds()) {
            SiegeCamp c = siegesById.get(campId);
            if (c != null) {
                c.setPreparationEndsAtMillis(war.getPreparationEndsAtMillis());
                c.setActiveEndsAtMillis(war.getActiveEndsAtMillis());
                if (war.isActiveAssault()) c.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
            }
        }

        saveData();
        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }

    public boolean endNationWar(String nationName) {
        NationWar war = getActiveNationWar(nationName);
        if (war != null) {
            war.setStatus(NationWar.Status.COMPLETED);
            for (String campId : war.getLinkedCampIds()) {
                SiegeCamp c = siegesById.get(campId);
                if (c != null) c.setStatus(SiegeCamp.Status.COMPLETED);
            }
            activeNationWars.remove(war.getWarId());
            saveData();
            plugin.getBossBarManager().updateAllBossBars();
            return true;
        }
        return false;
    }

    public boolean skipSiegeTime(String townName, long secondsToSkip) {
        SiegeCamp camp = getActiveSiegeForTown(townName);
        if (camp == null) return false;

        long now = System.currentTimeMillis();
        if (camp.getStatus() == SiegeCamp.Status.PREPARATION) {
            long newPrepEnd = camp.getPreparationEndsAtMillis() - (secondsToSkip * 1000L);
            if (newPrepEnd <= now) {
                camp.setPreparationEndsAtMillis(now - 1000L);
                camp.setStatus(SiegeCamp.Status.ACTIVE_SIEGE);
            } else {
                camp.setPreparationEndsAtMillis(newPrepEnd);
            }
        } else if (camp.getStatus() == SiegeCamp.Status.ACTIVE_SIEGE) {
            long newActiveEnd = camp.getActiveEndsAtMillis() - (secondsToSkip * 1000L);
            if (newActiveEnd <= now) {
                camp.setActiveEndsAtMillis(now - 1000L);
                camp.setStatus(SiegeCamp.Status.COMPLETED);
                unregisterSiege(camp);
            } else {
                camp.setActiveEndsAtMillis(newActiveEnd);
            }
        }
        saveData();
        plugin.getBossBarManager().updateAllBossBars();
        return true;
    }
}
