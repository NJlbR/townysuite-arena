package com.towny.sieges.cannon;

import com.towny.sieges.TownySiegesPlugin;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SiegeCannonManager {

    private final TownySiegesPlugin plugin;
    private final Map<UUID, Location> mountedGunners = new ConcurrentHashMap<>();
    private final Map<UUID, ArmorStand> gunnerSeats = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastShotTime = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastMountTime = new ConcurrentHashMap<>();
    private final Map<UUID, ItemStack> savedHandItems = new ConcurrentHashMap<>();
    private final Set<UUID> aimingGunners = ConcurrentHashMap.newKeySet();
    private final Map<Location, String> deployedCannons = new ConcurrentHashMap<>();
    private final Map<Location, Float> cannonInitialYaw = new ConcurrentHashMap<>();

    public static final long SHOT_COOLDOWN_MS = 4000L; // 4 seconds reload delay

    public SiegeCannonManager(TownySiegesPlugin plugin) {
        this.plugin = plugin;
    }

    public ItemStack getCannonItem() {
        ItemStack item = new ItemStack(Material.DISPENSER, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + "⚔ Осадная Пушка (Nexo/Oraxen Model)");
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Тяжелое осадное артиллерийское орудие.");
            lore.add(ChatColor.GRAY + "Установите на твердую поверхность для развертывания.");
            lore.add(ChatColor.YELLOW + "Ограничение поворота: ±45° | Дуговая баллистика");
            lore.add(ChatColor.YELLOW + "Перезарядка: 4 сек (с таймером в Action Bar)");
            lore.add(ChatColor.AQUA + "ПКМ по пушке: занять место наводчика сверху.");
            lore.add(ChatColor.AQUA + "ПКМ в седле: оптический прицел (зум и плавная наводка).");
            lore.add(ChatColor.GOLD + "ЛКМ в седле: произвести выстрел из орудия.");
            lore.add(ChatColor.RED + "Shift: слезть | Shift+ЛКМ/ПКМ: демонтировать.");
            meta.setLore(lore);
            meta.setCustomModelData(7001);
            item.setItemMeta(meta);
        }
        return item;
    }

    public ItemStack getAimingTool() {
        ItemStack item = new ItemStack(Material.WARPED_FUNGUS_ON_A_STICK, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + "⚔ Оптический Прицел Орудия");
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.AQUA + "• ПКМ: Включить/выключить приближение (зум и плавность)");
            lore.add(ChatColor.GOLD + "• ЛКМ: Произвести выстрел из орудия по дуге");
            lore.add(ChatColor.YELLOW + "• F (Смена рук): Быстрое переключение зума");
            lore.add(ChatColor.GRAY + "• Shift: Слезть с пушки (вернет ваш предмет)");
            meta.setLore(lore);
            meta.setCustomModelData(7002);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isCannonItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta.hasDisplayName() && meta.getDisplayName().contains("Осадная Пушка")) return true;
        if (meta.hasCustomModelData()) {
            int cmd = meta.getCustomModelData();
            return cmd == 7001 || cmd == 99201;
        }
        return false;
    }

    public boolean deployCannon(Player player, Location loc) {
        if (player == null || loc == null) return false;

        String town = plugin.getTownyHook().getPlayerTownName(player);
        if (town == null && !player.hasPermission("townysieges.admin")) {
            player.sendMessage(ChatColor.RED + "[TownySieges] Вы должны состоять в городе для установки осадной пушки!");
            return false;
        }

        Location blockLoc = loc.getBlock().getLocation();
        if (deployedCannons.containsKey(blockLoc)) {
            player.sendMessage(ChatColor.RED + "[TownySieges] Здесь уже установлена осадная пушка!");
            return false;
        }

        // Solid barrier block occupies ONLY blockLoc (from Y to Y+1) - players can stand on it
        Block b = blockLoc.getBlock();
        b.setType(Material.BARRIER);
        b.setMetadata("siege_cannon", new FixedMetadataValue(plugin, town != null ? town : "Admin"));
        deployedCannons.put(blockLoc, town != null ? town : "Admin");

        float initialYaw = player.getLocation().getYaw();
        cannonInitialYaw.put(blockLoc, initialYaw);

        // 3D Visuals & Interaction entity (NO floating carrot on a stick!)
        spawnCannonVisuals(blockLoc, initialYaw);

        // Hologram Name Tag above the cannon and seated gunner (Y+1.85)
        Location holoLoc = blockLoc.clone().add(0.5, 1.85, 0.5);
        loc.getWorld().spawn(holoLoc, ArmorStand.class, (as) -> {
            as.setVisible(false);
            as.setMarker(true);
            as.setGravity(false);
            as.setCustomName(ChatColor.GOLD + "⚔ Осадная Пушка [" + (town != null ? town : "Армия") + "]");
            as.setCustomNameVisible(true);
            as.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
        });

        player.sendMessage(ChatColor.GREEN + "[TownySieges] ✔ Осадное орудие развернуто! ПКМ по пушке, чтобы сесть наводчиком сверху.");
        loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_PLACE, 1.2f, 0.7f);
        return true;
    }

    private void spawnCannonVisuals(Location blockLoc, float yaw) {
        World world = blockLoc.getWorld();
        if (world == null) return;

        Location center = blockLoc.clone().add(0.5, 0.0, 0.5);
        center.setYaw(yaw);
        center.setPitch(0f);

        // Native 3D BlockDisplay model (Carriage, Wheels, Cannon Barrel Tube, Muzzle Rim)
        try {
            // Carriage Frame (Dark Oak) - lower portion of blockLoc
            world.spawn(center, BlockDisplay.class, bd -> {
                bd.setBlock(Bukkit.createBlockData(Material.DARK_OAK_PLANKS));
                bd.setTransformation(new Transformation(
                    new Vector3f(-0.35f, 0.05f, -0.45f),
                    new AxisAngle4f(0, 0, 1, 0),
                    new Vector3f(0.7f, 0.3f, 0.9f),
                    new AxisAngle4f(0, 0, 1, 0)
                ));
                bd.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });

            // Left Wheel (Grindstone)
            world.spawn(center, BlockDisplay.class, bd -> {
                bd.setBlock(Bukkit.createBlockData(Material.GRINDSTONE));
                bd.setTransformation(new Transformation(
                    new Vector3f(-0.48f, 0.02f, -0.25f),
                    new AxisAngle4f(0, 0, 1, 0),
                    new Vector3f(0.18f, 0.48f, 0.5f),
                    new AxisAngle4f(0, 0, 1, 0)
                ));
                bd.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });

            // Right Wheel (Grindstone)
            world.spawn(center, BlockDisplay.class, bd -> {
                bd.setBlock(Bukkit.createBlockData(Material.GRINDSTONE));
                bd.setTransformation(new Transformation(
                    new Vector3f(0.30f, 0.02f, -0.25f),
                    new AxisAngle4f(0, 0, 1, 0),
                    new Vector3f(0.18f, 0.48f, 0.5f),
                    new AxisAngle4f(0, 0, 1, 0)
                ));
                bd.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });

            // Heavy Gun Barrel / Cannon Tube (Polished Basalt) - tilted up 12°
            world.spawn(center, BlockDisplay.class, bd -> {
                bd.setBlock(Bukkit.createBlockData(Material.POLISHED_BASALT));
                bd.setTransformation(new Transformation(
                    new Vector3f(-0.2f, 0.22f, -0.55f),
                    new AxisAngle4f((float) Math.toRadians(-12), 1, 0, 0),
                    new Vector3f(0.4f, 0.4f, 1.15f),
                    new AxisAngle4f(0, 0, 1, 0)
                ));
                bd.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });

            // Cannon Muzzle Rim (Anvil / Heavy Iron Core) at the front of the barrel
            world.spawn(center, BlockDisplay.class, bd -> {
                bd.setBlock(Bukkit.createBlockData(Material.ANVIL));
                bd.setTransformation(new Transformation(
                    new Vector3f(-0.18f, 0.32f, 0.45f),
                    new AxisAngle4f((float) Math.toRadians(-12), 1, 0, 0),
                    new Vector3f(0.36f, 0.36f, 0.25f),
                    new AxisAngle4f(0, 0, 1, 0)
                ));
                bd.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });
        } catch (Throwable t) {
            plugin.getLogger().warning("Display entity spawn error: " + t.getMessage());
        }

        // Responsive Interaction entity so right-click is detected 100% reliably in survival
        try {
            world.spawn(blockLoc.clone().add(0.5, 0.0, 0.5), Interaction.class, it -> {
                it.setInteractionWidth(1.2f);
                it.setInteractionHeight(1.2f);
                it.setResponsive(true);
                it.setMetadata("siege_cannon_interaction", new FixedMetadataValue(plugin, blockLoc));
                it.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });
        } catch (Throwable t) {
            Location standLoc = blockLoc.clone().add(0.5, 0.0, 0.5);
            standLoc.setYaw(yaw);
            world.spawn(standLoc, ArmorStand.class, as -> {
                as.setVisible(false);
                as.setGravity(false);
                as.setSmall(true);
                as.setBasePlate(false);
                as.setMetadata("siege_cannon_interaction", new FixedMetadataValue(plugin, blockLoc));
                as.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
            });
        }
    }

    public boolean isCannonAt(Location loc) {
        if (loc == null) return false;
        return deployedCannons.containsKey(loc.getBlock().getLocation());
    }

    public Location getNearbyCannon(Location loc) {
        if (loc == null) return null;
        Location bLoc = loc.getBlock().getLocation();
        if (deployedCannons.containsKey(bLoc)) return bLoc;
        Location above = bLoc.clone().add(0, 1, 0);
        if (deployedCannons.containsKey(above)) return above;
        Location below = bLoc.clone().add(0, -1, 0);
        if (deployedCannons.containsKey(below)) return below;
        return null;
    }

    public void mountGunner(Player player, Location cannonLoc) {
        if (player == null || cannonLoc == null) return;
        Location blockLoc = cannonLoc.getBlock().getLocation();

        // If already mounted on this cannon, do nothing
        if (blockLoc.equals(mountedGunners.get(player.getUniqueId()))) {
            return;
        }

        // Check if cannon is already occupied by another player
        for (Map.Entry<UUID, Location> entry : mountedGunners.entrySet()) {
            if (blockLoc.equals(entry.getValue()) && !entry.getKey().equals(player.getUniqueId())) {
                Player other = Bukkit.getPlayer(entry.getKey());
                if (other != null && other.isOnline()) {
                    player.sendMessage(ChatColor.RED + "[TownySieges] Это орудие уже занято другим наводчиком (" + other.getName() + ")!");
                    return;
                }
            }
        }

        unmountGunner(player);

        Float initYawObj = cannonInitialYaw.get(blockLoc);
        float initYaw = initYawObj != null ? initYawObj : player.getLocation().getYaw();
        double rad = Math.toRadians(initYaw);

        // SEAT POSITIONED PRECISELY ON THE CANNON (Y + 0.62):
        // Neither buried inside nor floating in the air!
        double seatX = blockLoc.getX() + 0.5 + 0.12 * Math.sin(rad);
        double seatZ = blockLoc.getZ() + 0.5 - 0.12 * Math.cos(rad);
        Location seatLoc = new Location(blockLoc.getWorld(), seatX, blockLoc.getY() + 0.62, seatZ, initYaw, 0f);

        ArmorStand seat = blockLoc.getWorld().spawn(seatLoc, ArmorStand.class, as -> {
            as.setVisible(false);
            as.setMarker(true);
            as.setGravity(false);
            as.setBasePlate(false);
            as.setArms(false);
            as.setMetadata("cannon_seat", new FixedMetadataValue(plugin, blockLoc));
            as.setMetadata("siege_cannon_entity", new FixedMetadataValue(plugin, blockLoc));
        });

        seat.addPassenger(player);
        gunnerSeats.put(player.getUniqueId(), seat);
        mountedGunners.put(player.getUniqueId(), blockLoc);
        lastMountTime.put(player.getUniqueId(), System.currentTimeMillis());
        aimingGunners.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.SLOW);

        // Save original hand item and provide Gunner Sighting Tool
        ItemStack currentHand = player.getInventory().getItemInMainHand();
        savedHandItems.put(player.getUniqueId(), currentHand != null ? currentHand.clone() : new ItemStack(Material.AIR));
        player.getInventory().setItemInMainHand(getAimingTool());

        player.sendMessage(ChatColor.GOLD + "══════════ Место Наводчика Орудия ══════════");
        player.sendMessage(ChatColor.YELLOW + "• Вы зафиксированы на пушке! Вражеские лучники могут вести по вам прицельный огонь.");
        player.sendMessage(ChatColor.YELLOW + "• Прицеливание: ПКМ (приближение зума и плавная наводка).");
        player.sendMessage(ChatColor.YELLOW + "• Выстрел: ЛКМ (сектор огня ±45°, перезарядка 4 сек).");
        player.sendMessage(ChatColor.YELLOW + "• Покинуть орудие: нажмите Shift (приседание).");
        player.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════════");
        player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_IRON, 1.0f, 0.7f);
    }

    public void toggleAiming(Player player) {
        if (player == null || !isMounted(player)) return;
        UUID uuid = player.getUniqueId();
        Long mountTime = lastMountTime.get(uuid);
        if (mountTime != null && System.currentTimeMillis() - mountTime < 500L) {
            return; // Ignore mounting click bounce
        }

        if (aimingGunners.contains(uuid)) {
            // Turn OFF aiming
            aimingGunners.remove(uuid);
            player.removePotionEffect(PotionEffectType.SLOW);
            player.playSound(player.getLocation(), Sound.ITEM_SPYGLASS_STOP_USING, 1.0f, 1.1f);
            try {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    new TextComponent(ChatColor.GRAY + "🎯 Прицел выключен | ПКМ: Прицеливание | ЛКМ: Выстрел"));
            } catch (Exception ignored) {}
        } else {
            // Turn ON aiming (Zoom + smooth lower rotation sensitivity via Slowness III)
            aimingGunners.add(uuid);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 72000, 3, false, false, false));
            player.playSound(player.getLocation(), Sound.ITEM_SPYGLASS_USE, 1.2f, 1.0f);
            try {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    new TextComponent(ChatColor.AQUA + "🎯 [ПРИЦЕЛ ВКЛ] Зум x2.0 | Плавная наводка | ЛКМ: Выстрел"));
            } catch (Exception ignored) {}
        }
    }

    public boolean isAiming(Player player) {
        return player != null && aimingGunners.contains(player.getUniqueId());
    }

    public Long getLastMountTime(UUID uuid) {
        return lastMountTime.get(uuid);
    }

    public void unmountGunner(Player player) {
        if (player == null) return;
        UUID uuid = player.getUniqueId();
        aimingGunners.remove(uuid);
        lastMountTime.remove(uuid);
        player.removePotionEffect(PotionEffectType.SLOW);

        // Restore player hand item
        ItemStack saved = savedHandItems.remove(uuid);
        if (saved != null) {
            player.getInventory().setItemInMainHand(saved);
        }

        ArmorStand seat = gunnerSeats.remove(uuid);
        if (seat != null && !seat.isDead()) {
            seat.removePassenger(player);
            seat.remove();
        }
        Location cannonLoc = mountedGunners.remove(uuid);
        if (cannonLoc != null) {
            Float initYawObj = cannonInitialYaw.get(cannonLoc.getBlock().getLocation());
            float initYaw = initYawObj != null ? initYawObj : player.getLocation().getYaw();
            double rad = Math.toRadians(initYaw);
            // Place player behind the cannon upon dismounting
            Location exitLoc = cannonLoc.getBlock().getLocation().clone().add(0.5 + 0.8 * Math.sin(rad), 0.1, 0.5 - 0.8 * Math.cos(rad));
            exitLoc.setYaw(player.getLocation().getYaw());
            exitLoc.setPitch(player.getLocation().getPitch());
            player.teleport(exitLoc);
            player.sendMessage(ChatColor.GRAY + "[TownySieges] Вы покинули место наводчика осадной пушки.");
        }
    }

    public boolean isMounted(Player player) {
        return player != null && mountedGunners.containsKey(player.getUniqueId());
    }

    public Location getMountedCannon(Player player) {
        return player != null ? mountedGunners.get(player.getUniqueId()) : null;
    }

    public boolean fireCannon(Player player) {
        if (player == null) return false;
        if (!isMounted(player) || player.getVehicle() == null) {
            player.sendMessage(ChatColor.RED + "[TownySieges] Вы должны занять место наводчика на пушке (ПКМ), чтобы стрелять!");
            return false;
        }

        long now = System.currentTimeMillis();
        Long mountTime = lastMountTime.get(player.getUniqueId());
        if (mountTime != null && now - mountTime < 750L) {
            // Absolute lockout: prevents mounting right-click packet from firing the cannon!
            return false;
        }

        Location cannonLoc = getMountedCannon(player);
        if (cannonLoc == null) return false;

        // 1. Check reload cooldown (4 seconds)
        Long last = lastShotTime.get(player.getUniqueId());
        if (last != null && now - last < SHOT_COOLDOWN_MS) {
            double remaining = (SHOT_COOLDOWN_MS - (now - last)) / 1000.0;
            try {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    new TextComponent(ChatColor.RED + "⌛ Перезарядка пушки... " + String.format(Locale.US, "%.1f", remaining) + " сек."));
            } catch (Exception e) {
                player.sendMessage(ChatColor.RED + "⌛ Перезарядка пушки... " + String.format(Locale.US, "%.1f", remaining) + " сек.");
            }
            player.playSound(player.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.8f, 1.4f);
            return false;
        }

        // 2. Check horizontal +-45 degree sector constraint from initial cannon placement angle
        Float initYawObj = cannonInitialYaw.get(cannonLoc.getBlock().getLocation());
        float initYaw = initYawObj != null ? initYawObj : 0f;
        float playerYaw = player.getLocation().getYaw();
        float diffYaw = playerYaw - initYaw;
        while (diffYaw < -180f) diffYaw += 360f;
        while (diffYaw > 180f) diffYaw -= 360f;

        if (Math.abs(diffYaw) > 45.0f) {
            player.sendMessage(ChatColor.RED + "[TownySieges] ❌ Превышен угол поворота пушки! Максимальный сектор обстрела: ±45° (текущее отклонение: " + String.format(Locale.US, "%.1f", Math.abs(diffYaw)) + "°).");
            try {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    new TextComponent(ChatColor.RED + "❌ Вне сектора обстрела (±45°)! Поверните орудие к цели."));
            } catch (Exception ignored) {}
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
            return false;
        }

        // 3. Mark cooldown
        lastShotTime.put(player.getUniqueId(), now);

        // 4. Ballistics along player aim direction
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        double power = 1.35; // Authentic heavy siege ballistics speed
        Vector velocity = dir.multiply(power);
        velocity.setY(velocity.getY() + 0.26); // Graceful ballistic siege arc

        Location muzzle = cannonLoc.clone().add(0.5, 0.65, 0.5).add(dir.clone().multiply(0.85));

        // Visual and audio shot effects
        World world = cannonLoc.getWorld();
        if (world != null) {
            world.spawnParticle(Particle.EXPLOSION_LARGE, muzzle, 2, 0.1, 0.1, 0.1, 0.05);
            world.spawnParticle(Particle.FLAME, muzzle, 25, 0.2, 0.2, 0.2, 0.08);
            world.spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, muzzle, 30, 0.2, 0.3, 0.2, 0.05);
            world.playSound(cannonLoc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.6f);
            world.playSound(cannonLoc, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.5f, 0.5f);

            TNTPrimed shell = world.spawn(muzzle, TNTPrimed.class, (tnt) -> {
                tnt.setFuseTicks(65);
                tnt.setIsIncendiary(true);
                tnt.setVelocity(velocity);
                tnt.setMetadata("siege_cannon_shell", new FixedMetadataValue(plugin, true));
                tnt.setCustomName(ChatColor.RED + "Осадный Снаряд");
                tnt.setCustomNameVisible(true);
            });
        }

        player.sendMessage(ChatColor.RED + "🔥 ЗАЛП ОРУДИЯ! Снаряд выпущен по баллистической дуге (Угол: " + String.format(Locale.US, "%.1f", diffYaw) + "°)");

        // 5. Dynamic Action Bar reload countdown and sound effects (4 seconds = 80 ticks)
        final long shotTimestamp = now;
        new BukkitRunnable() {
            int step = 0;
            @Override
            public void run() {
                if (!isMounted(player)) {
                    cancel();
                    return;
                }
                long elapsed = System.currentTimeMillis() - shotTimestamp;
                double remaining = Math.max(0.0, (SHOT_COOLDOWN_MS - elapsed) / 1000.0);

                if (elapsed >= SHOT_COOLDOWN_MS) {
                    // Reload completed
                    try {
                        String aimPrefix = isAiming(player) ? ChatColor.AQUA + "🎯 [ПРИЦЕЛ] " : "";
                        player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                            new TextComponent(aimPrefix + ChatColor.GREEN + "✔ Пушка перезаряжена! ЛКМ: Залп [██████████]"));
                    } catch (Exception ignored) {}
                    player.playSound(player.getLocation(), Sound.BLOCK_IRON_DOOR_OPEN, 0.8f, 1.4f);
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);
                    cancel();
                    return;
                }

                // Middle reload click at ~2.0s
                if (step == 10) {
                    player.playSound(player.getLocation(), Sound.BLOCK_IRON_TRAPDOOR_CLOSE, 0.6f, 1.2f);
                }

                // Render dynamic progress bar (10 segments)
                int filled = (int) Math.min(10, (elapsed * 10) / SHOT_COOLDOWN_MS);
                StringBuilder bar = new StringBuilder();
                for (int i = 0; i < 10; i++) {
                    if (i < filled) bar.append("█");
                    else bar.append("░");
                }

                try {
                    String aimPrefix = isAiming(player) ? ChatColor.AQUA + "🎯 " : "";
                    player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                        new TextComponent(aimPrefix + ChatColor.GOLD + "🔥 ЗАЛП! " + ChatColor.YELLOW + "⌛ Перезарядка: " +
                            String.format(Locale.US, "%.1f", remaining) + " сек " +
                            ChatColor.DARK_GRAY + "[" + ChatColor.GREEN + bar + ChatColor.DARK_GRAY + "]"));
                } catch (Exception ignored) {}

                step++;
            }
        }.runTaskTimer(plugin, 1L, 4L); // Runs every 4 ticks (0.2s) for 20 steps = 4.0s

        return true;
    }

    public void breakCannon(Player player, Location cannonLoc) {
        if (cannonLoc == null) return;
        Location blockLoc = cannonLoc.getBlock().getLocation();

        // Dismount anyone on this cannon
        for (Map.Entry<UUID, Location> entry : mountedGunners.entrySet()) {
            if (entry.getValue().getBlock().getLocation().equals(blockLoc)) {
                Player p = Bukkit.getPlayer(entry.getKey());
                if (p != null) unmountGunner(p);
            }
        }

        blockLoc.getBlock().setType(Material.AIR);
        blockLoc.getBlock().removeMetadata("siege_cannon", plugin);
        deployedCannons.remove(blockLoc);
        cannonInitialYaw.remove(blockLoc);

        World world = blockLoc.getWorld();
        if (world != null) {
            for (Entity entity : world.getNearbyEntities(blockLoc.clone().add(0.5, 0.5, 0.5), 2.5, 2.5, 2.5)) {
                if (entity.hasMetadata("siege_cannon_entity") ||
                    entity.hasMetadata("siege_cannon_interaction") ||
                    entity.hasMetadata("cannon_seat")) {
                    entity.remove();
                }
            }
            world.dropItemNaturally(blockLoc.clone().add(0.5, 0.5, 0.5), getCannonItem());
        }

        if (player != null) {
            player.sendMessage(ChatColor.YELLOW + "[TownySieges] Осадная пушка демонтирована и возвращена в инвентарь.");
            player.playSound(blockLoc, Sound.BLOCK_ANVIL_BREAK, 1.0f, 1.0f);
        }
    }

    public void clearAll() {
        for (UUID uuid : new ArrayList<>(mountedGunners.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) unmountGunner(p);
        }
        for (ArmorStand seat : gunnerSeats.values()) {
            if (seat != null && !seat.isDead()) seat.remove();
        }
        gunnerSeats.clear();
        mountedGunners.clear();
        lastShotTime.clear();
        lastMountTime.clear();
        aimingGunners.clear();
        savedHandItems.clear();
    }
}
