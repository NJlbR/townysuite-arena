TownyArchitecture v2.8.9
========================
Release: Air-Contact Layer Edge Highlighting & Zero Depth Seams (v2.8.9)

Installation:
1. Put TownyArchitecture-2.8.9.jar into your server's plugins/ directory.
2. Make sure Towny (0.98+) is installed.
3. Restart or reload your server.
4. Run /builds to open the architectural blueprints catalog.

Fixes in v2.8.9:
- Layer edge highlighting strictly on contact with AIR (hasAir == true).
- Eliminated all wireframe / edge highlights buried in the depth of the layer.
- Distinct color-coded contours: Cyan for blueprint holograms, Vivid Red for obstacles/foreign blocks.
- Self-healing watchdog and BlockDisplay entities with Glow outlines.
- 0 particles mode and full interactive visualizer.
