package com.towny.sieges.command;

import com.towny.sieges.TownySiegesPlugin;
import com.towny.sieges.cannon.SiegeCannonManager;
import com.towny.sieges.model.NationWar;
import com.towny.sieges.model.SiegeCamp;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SiegeCommand implements CommandExecutor, TabCompleter {

    private final TownySiegesPlugin plugin;

    public SiegeCommand(TownySiegesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "══════ TownySieges v" + plugin.getDescription().getVersion() + " ══════");
            sender.sendMessage(ChatColor.YELLOW + "/siege camp <Город> " + ChatColor.GRAY + "- Поставить осадный лагерь");
            sender.sendMessage(ChatColor.YELLOW + "/siege expand " + ChatColor.GRAY + "- Расширить осадный лагерь на соседний чанк");
            sender.sendMessage(ChatColor.YELLOW + "/siege unclaim " + ChatColor.GRAY + "- Расприватить чанк лагеря");
            sender.sendMessage(ChatColor.YELLOW + "/siege cannon give [игрок] " + ChatColor.GRAY + "- Выдать осадную мортиру");
            sender.sendMessage(ChatColor.YELLOW + "/siege ammo give <regular|ap> [кол-во] [игрок] " + ChatColor.GRAY + "- Выдать ядра");
            sender.sendMessage(ChatColor.YELLOW + "/siege ammo recipes " + ChatColor.GRAY + "- Посмотреть кастомные рецепты крафта");
            sender.sendMessage(ChatColor.YELLOW + "/siege nationwar declare <Нация> " + ChatColor.GRAY + "- Объявить войну нации");
            sender.sendMessage(ChatColor.YELLOW + "/siege nationwar status " + ChatColor.GRAY + "- Статус войн наций и таймеров");
            sender.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════");
            return true;
        }

        // /siege cannon [give] [player]
        if (args[0].equalsIgnoreCase("cannon") || args[0].equalsIgnoreCase("pushka") || args[0].equalsIgnoreCase("getcannon") || args[0].equalsIgnoreCase("mortar")) {
            if (!sender.hasPermission("townysieges.admin")) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав администратора для выдачи осадных орудий!");
                return true;
            }
            Player target = sender instanceof Player ? (Player) sender : null;
            if (args.length >= 2 && !args[1].equalsIgnoreCase("give")) {
                target = Bukkit.getPlayer(args[1]);
            } else if (args.length >= 3) {
                target = Bukkit.getPlayer(args[2]);
            }
            if (target == null || !target.isOnline()) {
                sender.sendMessage(ChatColor.RED + "[TownySieges] Игрок не найден или не в сети!");
                return true;
            }
            target.getInventory().addItem(plugin.getCannonManager().getCannonItem());
            target.sendMessage(ChatColor.GREEN + "[TownySieges] Вам выдана кастомная осадная мортира (Nexo/Oraxen Model)!");
            target.sendMessage(ChatColor.YELLOW + "Разместите орудие на землю правой кнопкой мыши. Нажмите ПКМ по мортире, чтобы сесть наводчиком.");
            if (sender != target) {
                sender.sendMessage(ChatColor.GREEN + "[TownySieges] Мортира успешно выдана игроку " + target.getName() + ".");
            }
            return true;
        }

        // /siege ammo [give/recipes] ...
        if (args[0].equalsIgnoreCase("ammo") || args[0].equalsIgnoreCase("yadra") || args[0].equalsIgnoreCase("снаряды")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("recipes")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Рецепты Осадного Вооружения (TownySieges) ══════");
                sender.sendMessage(ChatColor.YELLOW + "1. Осадная Мортира (Верстак 3x3):");
                sender.sendMessage(ChatColor.WHITE + "   [Блок железа] [Раздатчик]   [Блок железа]");
                sender.sendMessage(ChatColor.WHITE + "   [Гладкий камень] [Котёл]    [Гладкий камень]");
                sender.sendMessage(ChatColor.WHITE + "   [Бревно дуба] [Бревно дуба] [Бревно дуба]");
                sender.sendMessage(ChatColor.GRAY + "   -> Нестакаемое орудие на лафете с колесами.");
                sender.sendMessage("");
                sender.sendMessage(ChatColor.YELLOW + "2. ⚪ Обычное Осадное Ядро:");
                sender.sendMessage(ChatColor.WHITE + "   [Железо] [Железо]  [Железо]");
                sender.sendMessage(ChatColor.WHITE + "   [Железо] [Порох]   [Железо]");
                sender.sendMessage(ChatColor.WHITE + "   [Уголь]  [Порох]   [Уголь]");
                sender.sendMessage(ChatColor.GRAY + "   -> Нестакаемый снаряд. Разрушает стандартные стены городов.");
                sender.sendMessage("");
                sender.sendMessage(ChatColor.LIGHT_PURPLE + "3. 🟣 Бронебойное Ядро (Пробитие Обсидиана):");
                sender.sendMessage(ChatColor.WHITE + "   [Алмаз]    [Обсидиан] [Алмаз]");
                sender.sendMessage(ChatColor.WHITE + "   [Незерит]  [ТНТ]      [Обсидиан]");
                sender.sendMessage(ChatColor.WHITE + "   [Алмаз]    [Порох]    [Алмаз]");
                sender.sendMessage(ChatColor.GOLD + "   -> Нестакаемый снаряд. ПРОБИВАЕТ ОБСИДИАН при штурме!");
                sender.sendMessage(ChatColor.GOLD + "═════════════════════════════════════════════════════════");
                return true;
            }

            if (args.length >= 2 && args[1].equalsIgnoreCase("give")) {
                if (!sender.hasPermission("townysieges.admin")) {
                    sender.sendMessage(ChatColor.RED + "[TownySieges] У вас нет прав для выдачи боеприпасов!");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /siege ammo give <regular|ap> [кол-во] [игрок]");
                    return true;
                }
                String typeStr = args[2].toLowerCase();
                int count = 1;
                if (args.length >= 4) {
                    try {
                        count = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
                    } catch (NumberFormatException ignored) {}
                }
                Player target = sender instanceof Player ? (Player) sender : null;
                if (args.length >= 5) {
                    target = Bukkit.getPlayer(args[4]);
                }
                if (target == null || !target.isOnline()) {
                    sender.sendMessage(ChatColor.RED + "[TownySieges] Игрок не найден или не в сети!");
                    return true;
                }

                boolean isAp = typeStr.contains("ap") || typeStr.contains("броне") || typeStr.contains("purple");
                for (int i = 0; i < count; i++) {
                    ItemStack ammo = isAp ?
                        plugin.getCannonManager().getArmorPiercingAmmoItem() :
                        plugin.getCannonManager().getRegularAmmoItem();
                    target.getInventory().addItem(ammo);
                }

                String typeName = isAp ? "🟣 Бронебойные ядра [Обсидиан]" : "⚪ Обычные осадные ядра";
                target.sendMessage(ChatColor.GREEN + "[TownySieges] Вы получили: " + typeName + " (" + count + " шт., нестакаемые).");
                if (sender != target) {
                    sender.sendMessage(ChatColor.GREEN + "[TownySieges] Выдано " + count + " шт. боеприпасов игроку " + target.getName() + ".");
                }
                return true;
            }

            if (args.length >= 2 && (args[1].equalsIgnoreCase("switch") || args[1].equalsIgnoreCase("toggle"))) {
                if (sender instanceof Player) {
                    Player p = (Player) sender;
                    if (plugin.getCannonManager().isMounted(p)) {
                        plugin.getCannonManager().cycleAmmo(p);
                        return true;
                    }
                }
                sender.sendMessage(ChatColor.GOLD + "[TownySieges] Смена боеприпасов: нажмите клавишу смены руки [F] сидя за орудием!");
                return true;
            }

            sender.sendMessage(ChatColor.YELLOW + "Использование: /siege ammo <recipes|give <regular|ap> [кол-во] [игрок]>");
            return true;
        }

        if (args[0].equalsIgnoreCase("switch") || args[0].equalsIgnoreCase("toggle")) {
            if (sender instanceof Player) {
                Player p = (Player) sender;
                if (plugin.getCannonManager().isMounted(p)) {
                    plugin.getCannonManager().cycleAmmo(p);
                    return true;
                }
            }
            sender.sendMessage(ChatColor.GOLD + "[TownySieges] Смена боеприпасов: нажмите клавишу смены руки [F] сидя за орудием!");
            return true;
        }

        // /siege camp <DefendingTown>
        if (args[0].equalsIgnoreCase("camp") || args[0].equalsIgnoreCase("lager")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Только игрок может ставить осадный лагерь!");
                return true;
            }
            Player player = (Player) sender;
            if (args.length < 2) {
                player.sendMessage(ChatColor.RED + "Использование: /siege camp <Город-цель>");
                return true;
            }
            String defendingTown = args[1];
            plugin.getSiegeManager().createSiegeCamp(player, defendingTown, player.getLocation());
            return true;
        }

        // /siege expand
        if (args[0].equalsIgnoreCase("expand") || args[0].equalsIgnoreCase("rasshirit")) {
            if (!(sender instanceof Player)) return true;
            Player player = (Player) sender;
            plugin.getSiegeManager().expandSiegeCamp(player, player.getLocation());
            return true;
        }

        // /siege unclaim
        if (args[0].equalsIgnoreCase("unclaim") || args[0].equalsIgnoreCase("udalit")) {
            if (!(sender instanceof Player)) return true;
            Player player = (Player) sender;
            plugin.getSiegeManager().unclaimSiegeChunk(player, player.getLocation());
            return true;
        }

        // /siege nationwar / war
        if (args[0].equalsIgnoreCase("nationwar") || args[0].equalsIgnoreCase("war") || args[0].equalsIgnoreCase("война")) {
            if (args.length < 2 || args[1].equalsIgnoreCase("status")) {
                sender.sendMessage(ChatColor.GOLD + "══════ Активные Войны Наций ══════");
                if (plugin.getSiegeManager().getAllNationWars().isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "В данный момент нет активных войн наций.");
                } else {
                    for (NationWar nw : plugin.getSiegeManager().getAllNationWars()) {
                        sender.sendMessage(ChatColor.YELLOW + "• " + nw.getAttackerNation() + " ➔ " + nw.getDefenderNation() +
                                " [" + nw.getStatus() + "] Осталось: " + nw.getFormattedRemainingTime());
                    }
                }
                sender.sendMessage(ChatColor.GOLD + "══════════════════════════════════");
                return true;
            }

            if (args[1].equalsIgnoreCase("declare")) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Только глава нации может объявить войну.");
                    return true;
                }
                Player player = (Player) sender;
                if (args.length < 3) {
                    player.sendMessage(ChatColor.RED + "Использование: /siege nationwar declare <Нация-Цель>");
                    return true;
                }
                String targetNat = args[2];
                plugin.getSiegeManager().declareNationWar(player, targetNat);
                return true;
            }

            if (args[1].equalsIgnoreCase("assault") && sender.hasPermission("townysieges.admin")) {
                if (args.length < 3) {
                    sender.sendMessage("Использование: /siege nationwar assault <Нация>");
                    return true;
                }
                NationWar nw = plugin.getSiegeManager().getActiveNationWar(args[2]);
                if (nw != null) {
                    nw.setStatus(NationWar.Status.ACTIVE_ASSAULT);
                    nw.setActiveEndsAtMillis(System.currentTimeMillis() + 7200000L);
                    plugin.getSiegeManager().saveData();
                    sender.sendMessage(ChatColor.GREEN + "Война нации переведена в фазу АКТИВНОГО ШТУРМА (2ч)!");
                } else {
                    sender.sendMessage(ChatColor.RED + "Война для указанной нации не найдена.");
                }
                return true;
            }
        }

        sender.sendMessage(ChatColor.RED + "Неизвестная команда. Введите /siege help");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = Arrays.asList("camp", "expand", "unclaim", "cannon", "ammo", "switch", "nationwar", "help");
            String input = args[0].toLowerCase();
            for (String s : subs) {
                if (s.startsWith(input)) completions.add(s);
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("nationwar") || args[0].equalsIgnoreCase("war")) {
                List<String> subs = Arrays.asList("declare", "status", "assault");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("cannon")) {
                List<String> subs = Arrays.asList("give");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            } else if (args[0].equalsIgnoreCase("ammo")) {
                List<String> subs = Arrays.asList("recipes", "switch", "give");
                String input = args[1].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            }
        } else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("ammo") && args[1].equalsIgnoreCase("give")) {
                List<String> subs = Arrays.asList("regular", "ap");
                String input = args[2].toLowerCase();
                for (String s : subs) {
                    if (s.startsWith(input)) completions.add(s);
                }
            }
        }
        return completions;
    }
}
