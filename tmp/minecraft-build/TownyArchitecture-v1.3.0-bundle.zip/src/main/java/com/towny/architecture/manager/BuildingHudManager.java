package com.towny.architecture.manager;

import com.towny.architecture.TownyArchitecturePlugin;
import com.towny.architecture.model.ActiveBuilding;
import com.towny.architecture.model.BuildingBlueprint;
import com.towny.architecture.model.ChunkCoord;
import com.towny.architecture.util.RussianTranslator;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.util.*;

public class BuildingHudManager {
    private final TownyArchitecturePlugin plugin;
    private final Map<UUID, BossBar> playerBossBars = new HashMap<>();
    private final Map<UUID, Integer> playerCycleIndex = new HashMap<>();
    private final Map<UUID, Integer> playerTicksHeld = new HashMap<>();
    private final Set<UUID> playersWithParticles = new HashSet<>();

    public BuildingHudManager(TownyArchitecturePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean hasParticlesEnabled(Player player) {
        return player != null && playersWithParticles.contains(player.getUniqueId());
    }

    public boolean toggleParticles(Player player) {
        if (player == null) return false;
        if (playersWithParticles.contains(player.getUniqueId())) {
            playersWithParticles.remove(player.getUniqueId());
            return false;
        } else {
            playersWithParticles.add(player.getUniqueId());
            return true;
        }
    }

    public void setParticlesEnabled(Player player, boolean enabled) {
        if (player == null) return;
        if (enabled) {
            playersWithParticles.add(player.getUniqueId());
        } else {
            playersWithParticles.remove(player.getUniqueId());
        }
    }

    public void renderParticles() {
        if (playersWithParticles.isEmpty()) return;

        int radiusChunks = plugin.getConfig().getInt("settings.buff-1x1-chunk-radius", 5);
        double radius = radiusChunks * 16.0; // 5 chunks = 80 blocks

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!playersWithParticles.contains(player.getUniqueId())) continue;

            Location pLoc = player.getLocation();
            World pWorld = pLoc.getWorld();
            if (pWorld == null) continue;

            for (ActiveBuilding bld : plugin.getBuildingManager().getActiveBuildings()) {
                if (!bld.getWorldName().equals(pWorld.getName())) continue;

                BuildingBlueprint bp = plugin.getBuildingManager().getBlueprint(bld.getBlueprintId());
                if (bp == null) continue;
                if (bp.getChunkWidth() != 1 || bp.getChunkLength() != 1) continue;
                if (bld.getAssignedChunks().isEmpty()) continue;

                ChunkCoord chunk = bld.getAssignedChunks().iterator().next();
                double centerX = (chunk.getX() << 4) + 8.0;
                double centerZ = (chunk.getZ() << 4) + 8.0;

                double dx = pLoc.getX() - centerX;
                double dz = pLoc.getZ() - centerZ;
                double distCenter = Math.sqrt(dx * dx + dz * dz);
                // Skip if player is too far from this building's zone to see any particles
                if (distCenter > radius + 64.0) continue;

                Color color = parseColor(bp.getParticleColorHex());
                Particle.DustOptions dust = new Particle.DustOptions(color, 1.25f);

                // 1. Circle boundary: perimeter = 2 * pi * radius (~500 blocks for 80 block radius)
                double angleStep = 2.5 / radius;
                for (double angle = 0; angle < 2 * Math.PI; angle += angleStep) {
                    double x = centerX + radius * Math.cos(angle);
                    double z = centerZ + radius * Math.sin(angle);

                    double pDistSq = (x - pLoc.getX()) * (x - pLoc.getX()) + (z - pLoc.getZ()) * (z - pLoc.getZ());
                    if (pDistSq > 56.0 * 56.0) continue; // within player view distance

                    spawnGroundParticle(player, pWorld, x, z, dust);
                }

                // 2. Intersecting diameters passing through the center of the chunk
                // 4 diameters: 0°, 45°, 90°, 135° (8 radial spokes forming complete lines)
                double[] angles = new double[]{0.0, Math.PI / 4.0, Math.PI / 2.0, 3.0 * Math.PI / 4.0};
                for (double angle : angles) {
                    double cos = Math.cos(angle);
                    double sin = Math.sin(angle);

                    for (double d = -radius; d <= radius; d += 2.5) {
                        double x = centerX + d * cos;
                        double z = centerZ + d * sin;

                        double pDistSq = (x - pLoc.getX()) * (x - pLoc.getX()) + (z - pLoc.getZ()) * (z - pLoc.getZ());
                        if (pDistSq > 56.0 * 56.0) continue;

                        spawnGroundParticle(player, pWorld, x, z, dust);
                    }
                }
            }
        }
    }

    private void spawnGroundParticle(Player player, World world, double x, double z, Particle.DustOptions dust) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) return;

        int groundY = world.getHighestBlockYAt(bx, bz);
        Location particleLoc = new Location(world, x, groundY + 1.05, z);
        // player.spawnParticle ensures ONLY this player sees the particles
        player.spawnParticle(Particle.REDSTONE, particleLoc, 1, 0.0, 0.0, 0.0, 0.0, dust);
    }

    private Color parseColor(String hex) {
        if (hex == null || hex.isEmpty()) return Color.YELLOW;
        if (hex.startsWith("#")) hex = hex.substring(1);
        try {
            int rgb = Integer.parseInt(hex, 16);
            return Color.fromRGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
        } catch (Exception e) {
            return Color.YELLOW;
        }
    }

    public void updateHud() {
        int cycleIntervalSeconds = plugin.getConfig().getInt("settings.hud-material-cycle-interval-seconds", 5);
        if (cycleIntervalSeconds < 1) cycleIntervalSeconds = 5;

        for (Player player : Bukkit.getOnlinePlayers()) {
            ActiveBuilding building = plugin.getBuildingManager().getBuildingAt(player.getLocation());
            if (building != null && !building.isFullyBuilt()) {
                BuildingBlueprint bp = plugin.getBuildingManager().getBlueprint(building.getBlueprintId());
                String bpName = bp != null ? bp.getNameRu() : building.getBlueprintId();
                int percent = building.getProgressPercent();

                BossBar bar = playerBossBars.computeIfAbsent(player.getUniqueId(), k -> {
                    BossBar b = Bukkit.createBossBar(
                            "",
                            BarColor.YELLOW,
                            BarStyle.SEGMENTED_10
                    );
                    b.addPlayer(player);
                    return b;
                });
                bar.setProgress(Math.max(0.0, Math.min(1.0, percent / 100.0)));
                bar.setVisible(true);

                StringBuilder reqStr = new StringBuilder();
                Map<Material, Integer> required = building.getRequiredMaterials();
                
                List<Map.Entry<Material, Integer>> uncompleted = new ArrayList<>();
                List<Map.Entry<Material, Integer>> completed = new ArrayList<>();
                for (Map.Entry<Material, Integer> entry : required.entrySet()) {
                    int placed = building.getPlacedCount(entry.getKey());
                    int need = entry.getValue();
                    if (placed < need) {
                        uncompleted.add(entry);
                    } else {
                        completed.add(entry);
                    }
                }
                
                List<Map.Entry<Material, Integer>> sortedList = new ArrayList<>(uncompleted);
                sortedList.addAll(completed);

                if (!sortedList.isEmpty()) {
                    int currentCycle = playerCycleIndex.getOrDefault(player.getUniqueId(), 0);
                    int ticksHeld = playerTicksHeld.getOrDefault(player.getUniqueId(), 0) + 1;
                    
                    if (ticksHeld >= cycleIntervalSeconds) {
                        ticksHeld = 0;
                        currentCycle = (currentCycle + 1) % sortedList.size();
                        playerCycleIndex.put(player.getUniqueId(), currentCycle);
                    }
                    playerTicksHeld.put(player.getUniqueId(), ticksHeld);
                    
                    int idx1 = currentCycle % sortedList.size();
                    Map.Entry<Material, Integer> e1 = sortedList.get(idx1);
                    int placed1 = building.getPlacedCount(e1.getKey());
                    int need1 = e1.getValue();
                    boolean done1 = placed1 >= need1;
                    
                    reqStr.append(done1 ? "§a✔ " : "§e■ ")
                          .append("§f").append(RussianTranslator.getShortMaterialRu(e1.getKey())).append(": ")
                          .append(done1 ? "§a" : "§e").append(placed1).append("§7/§a").append(need1);
                          
                    if (sortedList.size() > 1) {
                        int idx2 = (idx1 + 1) % sortedList.size();
                        Map.Entry<Material, Integer> e2 = sortedList.get(idx2);
                        int placed2 = building.getPlacedCount(e2.getKey());
                        int need2 = e2.getValue();
                        boolean done2 = placed2 >= need2;
                        
                        reqStr.append(" §8| ")
                              .append(done2 ? "§a✔ " : "§e■ ")
                              .append("§f").append(RussianTranslator.getShortMaterialRu(e2.getKey())).append(": ")
                              .append(done2 ? "§a" : "§e").append(placed2).append("§7/§a").append(need2);
                    }
                }

                String prefix = ChatColor.GOLD + "⚡ [" + building.getTownName() + "] " + ChatColor.YELLOW + bpName + ChatColor.DARK_GRAY + " | ";
                if (reqStr.length() > 0) {
                    bar.setTitle(prefix + reqStr.toString() + " §8| §a" + percent + "%");
                } else {
                    bar.setTitle(prefix + "§a" + percent + "%");
                }
            } else {
                BossBar bar = playerBossBars.remove(player.getUniqueId());
                if (bar != null) {
                    bar.removePlayer(player);
                    bar.setVisible(false);
                }
                playerTicksHeld.remove(player.getUniqueId());
            }
        }
    }

    public void removePlayer(Player player) {
        BossBar bar = playerBossBars.remove(player.getUniqueId());
        if (bar != null) {
            bar.removePlayer(player);
            bar.setVisible(false);
        }
        playerCycleIndex.remove(player.getUniqueId());
        playerTicksHeld.remove(player.getUniqueId());
        playersWithParticles.remove(player.getUniqueId());
    }

    public void clearAll() {
        for (BossBar bar : playerBossBars.values()) {
            bar.removeAll();
            bar.setVisible(false);
        }
        playerBossBars.clear();
        playerCycleIndex.clear();
        playerTicksHeld.clear();
        playersWithParticles.clear();
    }
}
