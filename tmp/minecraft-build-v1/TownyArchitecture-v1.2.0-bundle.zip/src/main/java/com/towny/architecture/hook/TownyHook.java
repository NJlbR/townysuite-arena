package com.towny.architecture.hook;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import com.towny.architecture.model.ChunkCoord;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Town;
import com.palmergames.bukkit.towny.object.TownBlock;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;

public class TownyHook {

    public String getPlayerTownName(Player player) {
        return getPlayerTown(player);
    }
    
    public boolean isPlayerMayorOrAssistant(Player player) {
        if (!isTownyEnabled) return true;
        try {
            var res = TownyAPI.getInstance().getResident(player.getUniqueId());
            if (res != null && res.hasTown()) {
                Town town = res.getTown();
                return town.getMayor().getUUID().equals(player.getUniqueId()) || 
                       res.hasTownRank("assistant");
            }
        } catch (Exception e) {}
        return false;
    }

    public boolean hasBuilderPermission(Player player, String townName) {
        if (!isTownyEnabled) return true;
        try {
            var res = TownyAPI.getInstance().getResident(player.getUniqueId());
            if (res != null && res.hasTown() && res.getTown().getName().equalsIgnoreCase(townName)) {
                Town town = res.getTown();
                return town.getMayor().getUUID().equals(player.getUniqueId()) || 
                       res.hasTownRank("assistant") ||
                       res.hasTownRank("builder");
            }
        } catch (Exception e) {}
        return false;
    }

    public boolean isLocationInTown(Location loc, String townName) {
        if (!isTownyEnabled) return true;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            if (tb != null && tb.hasTown()) {
                return tb.getTown().getName().equalsIgnoreCase(townName);
            }
        } catch (Exception e) {}
        return false;
    }
    
    public boolean isLocationInPlayerTown(Location loc, Player player) {
        String pTown = getPlayerTownName(player);
        if (pTown == null) return false;
        return isLocationInTown(loc, pTown);
    }
    
    public boolean tagPlotAsBuild(Location loc, String name) {
        // Fallback for older method signature without Player
        if (!isTownyEnabled) return true;
        try {
            TownBlock townBlock = TownyAPI.getInstance().getTownBlock(loc);
            if (townBlock != null && townBlock.hasTown()) {
                java.lang.reflect.Method setTypeMethod = townBlock.getClass().getMethod("setType", int.class);
                setTypeMethod.invoke(townBlock, 0);

                java.lang.reflect.Method getPermissionsMethod = townBlock.getClass().getMethod("getPermissions");
                Object perms = getPermissionsMethod.invoke(townBlock);
                if (perms != null) {
                    try {
                        perms.getClass().getField("pvp").set(perms, false);
                    } catch (Exception e1) {
                        try {
                            perms.getClass().getMethod("setPvP", boolean.class).invoke(perms, false);
                        } catch (Exception e2) {}
                    }
                }
                
                try {
                    java.lang.reflect.Method saveMethod = townBlock.getClass().getMethod("save");
                    saveMethod.invoke(townBlock);
                } catch (Exception ignored) {}
                
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    private boolean isTownyEnabled;

    public TownyHook() {
        this.isTownyEnabled = Bukkit.getPluginManager().getPlugin("Towny") != null;
    }

    public boolean isTownyEnabled() {
        return isTownyEnabled;
    }

    public String getTownName(Chunk chunk) {
        if (!isTownyEnabled) return null;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(new Location(chunk.getWorld(), chunk.getX() * 16, 0, chunk.getZ() * 16));
            if (tb != null && tb.hasTown()) {
                return tb.getTown().getName();
            }
        } catch (Exception e) {}
        return null;
    }
    
    public String getTownName(Location loc) {
        if (!isTownyEnabled) return null;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            if (tb != null && tb.hasTown()) {
                return tb.getTown().getName();
            }
        } catch (Exception e) {}
        return null;
    }

    public boolean isResidentOfTownAt(Player player, Location loc) {
        if (!isTownyEnabled) return false;
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            if (tb != null && tb.hasTown()) {
                return tb.getTown().hasResident(player.getName()) || tb.getTown().hasResident(player.getUniqueId());
            }
        } catch (Exception e) {}
        return false;
    }

    public boolean hasBuildRights(Player player, Location loc) {
        if (!isTownyEnabled) return true; // Standalone mode -> always allow
        try {
            TownBlock tb = TownyAPI.getInstance().getTownBlock(loc);
            if (tb != null && tb.hasTown()) {
                Town town = tb.getTown();
                boolean isMayor = town.getMayor().getUUID().equals(player.getUniqueId());
                boolean isAssistant = TownyAPI.getInstance().getResident(player).hasTownRank("assistant");
                boolean isBuilder = TownyAPI.getInstance().getResident(player).hasTownRank("builder");
                return isMayor || isAssistant || isBuilder;
            }
        } catch (Exception e) {}
        return false;
    }
    
    public String getPlayerTown(Player player) {
        if (!isTownyEnabled) return null;
        try {
            var res = TownyAPI.getInstance().getResident(player.getUniqueId());
            if (res != null && res.hasTown()) {
                return res.getTown().getName();
            }
        } catch (Exception e) {}
        return null;
    }

    public boolean tagPlotAsBuild(Player player, Location loc) {
        if (!isTownyEnabled) return true;
        if (!hasBuildRights(player, loc)) return false;
        
        try {
            TownBlock townBlock = TownyAPI.getInstance().getTownBlock(loc);
            if (townBlock != null && townBlock.hasTown()) {
                // Clear specialized types back to default
                Method setTypeMethod = townBlock.getClass().getMethod("setType", int.class);
                setTypeMethod.invoke(townBlock, 0);

                // Disable PvP
                Method getPermissionsMethod = townBlock.getClass().getMethod("getPermissions");
                Object perms = getPermissionsMethod.invoke(townBlock);
                if (perms != null) {
                    try {
                        perms.getClass().getField("pvp").set(perms, false);
                    } catch (Exception e_ignored1) {
                        try {
                            perms.getClass().getMethod("setPvP", boolean.class).invoke(perms, false);
                        } catch (Exception e_ignored2) {}
                    }
                }
                
                try {
                    Method saveMethod = townBlock.getClass().getMethod("save");
                    saveMethod.invoke(townBlock);
                } catch (Exception ignored) {}
                
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
