package com.towny.architecture;

import com.towny.architecture.command.BuildCommand;
import com.towny.architecture.gui.BuildsMenuGui;
import com.towny.architecture.hook.TownyHook;
import com.towny.architecture.manager.*;
import com.towny.architecture.model.ChunkCoord;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;

public class TownyArchitecturePlugin extends JavaPlugin implements Listener {

    private static TownyArchitecturePlugin instance;

    private TownyHook townyHook;

    private BuildingManager buildingManager;
    private BuffManager buffManager;
    private SiegeDamageManager siegeDamageManager;
    private BuildingHudManager buildingHudManager;
    private ArchitectManager architectManager;

    private BuildsMenuGui buildsMenuGui;
    private BuildCommand buildCommand;

    private File buildingsFile;
    private FileConfiguration buildingsConfig;

    private BukkitTask buffTask;
    private BukkitTask hudTask;
    private BukkitTask integrityTask;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveResourceIfNotExists("buildings.yml");

        townyHook = new TownyHook();

        architectManager = new ArchitectManager(this);
        buildingManager = new BuildingManager(this);
        buffManager = new BuffManager(this);
        siegeDamageManager = new SiegeDamageManager(this);
        buildingHudManager = new BuildingHudManager(this);
        buildsMenuGui = new BuildsMenuGui(this);

        loadBuildingsConfig();
        buildingManager.loadBlueprints(buildingsConfig);
        buildingManager.loadData();

        buildCommand = new BuildCommand(this);
        if (getCommand("builds") != null) {
            getCommand("builds").setExecutor(buildCommand);
            getCommand("builds").setTabCompleter(buildCommand);
        }

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(buildsMenuGui, this);
        getServer().getPluginManager().registerEvents(siegeDamageManager, this);

        int intervalSeconds = getConfig().getInt("settings.buff-check-interval-seconds", 5);
        buffTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            buffManager.applyBuffs();
        }, 40L, intervalSeconds * 20L);

        hudTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            buildingHudManager.updateHud();
        }, 20L, 20L);

        integrityTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            buildingManager.performPeriodicIntegrityCheck();
        }, 600L, 1200L);

        getLogger().info("=================================================");
        getLogger().info(" TownyArchitecture v" + getDescription().getVersion() + " успешно активирован!");
        getLogger().info(" Towny Hook: " + (townyHook.isTownyEnabled() ? "Подключен" : "Отсутствует (Автономия)"));
        getLogger().info(" Встроенная система прокачки Архитектора: АКТИВНА");
        getLogger().info(" Чанковая система построек: АКТИВНА (/plot set build)");
        getLogger().info(" Загружено чертежей зданий: " + buildingManager.getBlueprints().size());
        getLogger().info(" Периодический аудит блоков: АКТИВЕН (каждые 60 сек)");
        getLogger().info("=================================================");
    }

    @Override
    public void onDisable() {
        if (buffTask != null) buffTask.cancel();
        if (hudTask != null) hudTask.cancel();
        if (integrityTask != null) integrityTask.cancel();
        
        if (buildingHudManager != null) buildingHudManager.clearAll();
        if (buildingManager != null) buildingManager.saveData();
        if (architectManager != null) architectManager.save();
        
        getLogger().info("TownyArchitecture выключен. Данные сохранены.");
    }

    private void saveResourceIfNotExists(String resourcePath) {
        File file = new File(getDataFolder(), resourcePath);
        if (!file.exists()) {
            saveResource(resourcePath, false);
        }
    }

    public void loadBuildingsConfig() {
        buildingsFile = new File(getDataFolder(), "buildings.yml");
        if (!buildingsFile.exists()) {
            saveResource("buildings.yml", false);
        }
        buildingsConfig = YamlConfiguration.loadConfiguration(buildingsFile);
    }

    public void reloadPluginConfig() {
        reloadConfig();
        loadBuildingsConfig();
        buildingManager.loadBlueprints(buildingsConfig);
        buildingManager.loadData();
    }

    public String getMsg(String path) {
        return getConfig().getString("messages." + path, "");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        boolean allow = buildingManager.handleBlockPlaced(
                event.getPlayer(), 
                event.getBlock().getLocation(), 
                event.getBlock().getType()
        );
        if (!allow) {
            event.setCancelled(true);
            return;
        }
        
        if (townyHook.isResidentOfTownAt(event.getPlayer(), event.getBlock().getLocation())) {
            architectManager.handleTownBlockPlace(event.getPlayer(), event.getBlock().getType());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        boolean allow = buildingManager.handleBlockBroken(
                event.getPlayer(),
                event.getBlock().getLocation(),
                event.getBlock().getType()
        );
        if (!allow) {
            event.setCancelled(true);
            return;
        }
        
        if (townyHook.isResidentOfTownAt(event.getPlayer(), event.getBlock().getLocation())) {
            architectManager.handleTownBlockBreak(event.getPlayer(), event.getBlock().getType());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBurn(BlockBurnEvent event) {
        buildingManager.handleBlockBroken(
                null,
                event.getBlock().getLocation(),
                event.getBlock().getType()
        );
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String msg = event.getMessage().trim().toLowerCase();
        
        if (msg.equals("/plot set build") || msg.equals("/plot set building") || 
            msg.equals("/plot set стройка") || msg.startsWith("/plot set build ")) {
            event.setCancelled(true);
            buildCommand.processPlotSetBuild(event.getPlayer());
        } else if (msg.startsWith("/plot set ")) {
            Player player = event.getPlayer();
            String town = townyHook.getPlayerTown(player);
            if (town != null && townyHook.hasBuildRights(player, player.getLocation())) {
                ChunkCoord cc = ChunkCoord.fromLocation(player.getLocation());
                if (buildingManager.getTownBuildPlots(town).contains(cc)) {
                    buildingManager.removeTownBuildPlot(town, cc);
                    player.sendMessage(org.bukkit.ChatColor.YELLOW + "[TownyArchitecture] Статус участка «Стройка» снят с этого чанка, так как вы изменили его тип.");
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onTabComplete(org.bukkit.event.server.TabCompleteEvent event) {
        String buffer = event.getBuffer();
        String[] args = buffer.split(" ", -1);
        if (args.length == 3 && args[0].equalsIgnoreCase("/plot") && args[1].equalsIgnoreCase("set")) {
            if ("build".startsWith(args[2].toLowerCase())) {
                java.util.List<String> completions = new java.util.ArrayList<>(event.getCompletions());
                if (!completions.contains("build")) {
                    completions.add("build");
                    event.setCompletions(completions);
                }
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (buildingHudManager != null) {
            buildingHudManager.removePlayer(event.getPlayer());
        }
        if (architectManager != null) {
            architectManager.removeBossBar(event.getPlayer());
        }
    }

    public static TownyArchitecturePlugin getInstance() { return instance; }
    public TownyHook getTownyHook() { return townyHook; }
    public ArchitectManager getArchitectManager() { return architectManager; }
    public BuildingManager getBuildingManager() { return buildingManager; }
    public BuffManager getBuffManager() { return buffManager; }
    public SiegeDamageManager getSiegeDamageManager() { return siegeDamageManager; }
    public BuildingHudManager getBuildingHudManager() { return buildingHudManager; }
    public BuildsMenuGui getBuildsMenuGui() { return buildsMenuGui; }
    public BuildCommand getBuildCommand() { return buildCommand; }
    public FileConfiguration getBuildingsConfig() { return buildingsConfig; }
}
